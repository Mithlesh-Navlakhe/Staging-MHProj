-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 11, 2017 at 08:56 AM
-- Server version: 5.7.17-0ubuntu0.16.04.1
-- PHP Version: 7.0.15-0ubuntu0.16.04.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `time_tracking`
--

-- --------------------------------------------------------

--
-- Table structure for table `Clients`
--

CREATE TABLE `Clients` (
  `id` int(10) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `company_address` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `contact_person` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(255) NOT NULL,
  `updated_at` date NOT NULL,
  `created_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Clients`
--

INSERT INTO `Clients` (`id`, `company_name`, `company_address`, `website`, `contact_person`, `email`, `phone_number`, `updated_at`, `created_at`) VALUES
(14, 'spintouch', '160 Newport Center Dr. STE 100  |  Newport Beach, CA 92660', 'http://myShowcase App', 'Paul Hashemi', 'paulh@spintouch.com', '9493957227', '2017-01-19', '2017-01-19'),
(15, 'Ignatiuz', 'Indore', 'http://myHub', 'Deepesh Verma', 'Deepesh.Verma@ignatiuz.com', '', '2017-01-20', '2017-01-20'),
(16, 'Test studio', '', 'http://Test studio', 'Anish', 'anish.lokre@ignatiuz.com', '', '2017-01-20', '2017-01-20'),
(17, 'Computer Decisions', '', 'http://gnemsdc.org/', 'Clifton E. Clark III', 'clark@computerdecisions.net', '', '2017-01-21', '2017-01-21'),
(18, 'TIFF', 'The Investment Fund for Foundations 170 N Radnor Chester Road, Suite 300 Radnor, PA 19087', 'http://tiff.org', 'Joseph D. Polimeni', 'JPolimeni@tiff.org', '', '2017-01-21', '2017-01-21'),
(19, 'A&A Events', '', '', 'A&A Events', '', '', '2017-01-21', '2017-01-21'),
(20, 'WeNet Consulting', '', 'http://www.weNet4u.com', 'Clifton E. Clark III', '', '', '2017-01-24', '2017-01-24'),
(21, 'OpenVine Solutions', 'OpenVine Solutions, Inc. ', 'http://www.barnstable.ignatiuz.com', 'Bill Germino', 'bill@openvine.com', '781.440.9080', '2017-01-24', '2017-01-24'),
(22, 'Ignatiuz', '', '', 'ignatiuz client', '', '', '2017-01-25', '2017-01-25'),
(25, 'LiveTechnology', '', '', 'Wayne Reuvers', '', '', '2017-03-03', '2017-03-03'),
(26, 'German Indian Business Forum', '', '', 'Amit Wadhwani', '', '', '2017-03-03', '2017-03-03'),
(27, 'Old Bridge', '', '', 'Himanshu Shah', '', '', '2017-03-14', '2017-03-14'),
(28, 'Borough of Point Pleasant', '', '', 'Himanshu Shah', '', '', '2017-03-16', '2017-03-16'),
(30, 'Bridgewater', 'The Township of Bridgewater 100 Commons Way Bridgewater NJ 08807', 'http://bridgewaterstg.ignatiuz.com/', 'Rose Witt', 'rwitt@bridgewaternj.gov', '', '2017-03-20', '2017-03-20'),
(31, 'Cobble Stone Consulting', '', 'http://www.cobblestoneconsulting.com', 'Laurie Bacopoulos', 'laurieb@cobblestoneconsulting.com', '', '2017-03-31', '2017-03-31'),
(32, 'UCSF', '', '', 'Andy', '', '', '2017-04-07', '2017-04-07'),
(33, 'InterSoft Technologies International, LLC', '', 'http://www.itillc.com/', 'Amit Wadhwani', '', '', '2017-04-10', '2017-04-10');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Project`
--

CREATE TABLE `Project` (
  `id` int(10) NOT NULL,
  `client_id` int(10) NOT NULL,
  `lead_id` int(10) NOT NULL,
  `project_name` varchar(255) NOT NULL,
  `hourly_rate` decimal(5,2) NOT NULL DEFAULT '0.00',
  `notes` text NOT NULL,
  `updated_at` datetime NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Project`
--

INSERT INTO `Project` (`id`, `client_id`, `lead_id`, `project_name`, `hourly_rate`, `notes`, `updated_at`, `created_at`) VALUES
(27, 14, 86, 'Testing of myShowcase app', '0.00', '', '2017-01-21 10:13:45', '2017-01-19 08:53:38'),
(28, 14, 86, 'Automation of myShowcase app', '0.00', '', '2017-01-21 10:13:34', '2017-01-19 08:53:58'),
(30, 16, 85, 'RND of Test studio', '10.00', '', '2017-01-25 07:45:08', '2017-01-20 05:49:12'),
(32, 17, 85, 'HMSDC.org', '0.00', '', '2017-01-21 06:17:03', '2017-01-21 06:17:03'),
(33, 17, 85, 'http://gnemsdc.org/', '0.00', '', '2017-01-21 06:17:44', '2017-01-21 06:17:44'),
(34, 18, 86, 'Automation of TIFF', '0.00', '', '2017-01-21 07:23:51', '2017-01-21 07:23:51'),
(35, 18, 89, 'Project Parachute -Links', '0.00', '', '2017-01-21 07:24:05', '2017-01-21 07:24:05'),
(36, 18, 89, 'RFP Project Plan Options', '0.00', '', '2017-01-21 07:24:15', '2017-01-21 07:24:15'),
(37, 18, 89, 'New Weekly Timesheet Report', '0.00', '', '2017-01-21 07:25:04', '2017-01-21 07:25:04'),
(38, 18, 89, 'PI Project Calendar', '0.00', '', '2017-01-21 07:28:37', '2017-01-21 07:28:37'),
(39, 19, 85, 'http://www.aaemllc.com/ ', '0.00', '', '2017-01-21 07:36:20', '2017-01-21 07:36:20'),
(40, 19, 85, 'http://aa-q.de/home/', '0.00', '', '2017-01-21 07:36:31', '2017-01-21 07:36:31'),
(42, 19, 85, 'http://aa-gt.com/', '0.00', '', '2017-01-21 07:37:52', '2017-01-21 07:37:52'),
(43, 19, 85, 'http://gmitrading.com/', '0.00', '', '2017-01-21 07:38:04', '2017-01-21 07:38:04'),
(44, 20, 87, 'HMSDC', '0.00', '', '2017-01-24 05:38:18', '2017-01-24 05:38:18'),
(45, 21, 87, 'Barnstable', '0.00', '', '2017-01-24 05:55:10', '2017-01-24 05:55:10'),
(46, 15, 85, 'Marketing Material', '0.00', '', '2017-01-25 05:12:42', '2017-01-25 05:12:42'),
(50, 18, 85, 'MockUp', '0.00', '', '2017-02-02 06:36:23', '2017-02-02 06:36:23'),
(51, 15, 87, 'Testdeveloper', '0.00', '', '2017-02-14 08:28:32', '2017-02-14 05:45:52'),
(52, 26, 85, 'GDIZ', '0.00', '', '2017-03-03 07:23:51', '2017-03-03 07:23:51'),
(53, 21, 85, 'ESM Design', '0.00', '', '2017-03-03 07:24:48', '2017-03-03 07:24:48'),
(54, 25, 110, 'LiveStuff Browser Add on - Add to it  ', '0.00', '', '2017-03-08 06:46:40', '2017-03-08 06:46:40'),
(55, 27, 85, 'GIS Mockup', '0.00', '', '2017-03-14 12:23:08', '2017-03-14 12:23:08'),
(56, 27, 85, 'Food & Beverages Mockup', '0.00', '', '2017-03-14 12:23:41', '2017-03-14 12:23:41'),
(57, 28, 87, 'Budget Sheet Web Application', '0.00', '', '2017-03-16 08:29:44', '2017-03-16 08:29:44'),
(58, 27, 87, 'Food and Beverage', '0.00', '', '2017-03-16 08:31:17', '2017-03-16 08:31:17'),
(59, 30, 87, 'Township of BridgeWater', '0.00', '(Development)', '2017-04-05 05:42:44', '2017-03-20 05:00:15'),
(60, 27, 87, 'GIS Web Development', '0.00', '', '2017-03-21 05:00:15', '2017-03-21 05:00:15'),
(61, 15, 85, 'Socutfoto Design', '0.00', '', '2017-03-23 12:36:35', '2017-03-23 12:36:35'),
(62, 15, 115, 'Biz Dev', '0.00', '', '2017-03-24 05:50:26', '2017-03-24 05:50:26'),
(63, 15, 70, 'Network Support', '0.00', '', '2017-03-24 06:01:14', '2017-03-24 06:01:14'),
(64, 27, 70, 'Old Bridge Support', '0.00', '', '2017-03-24 06:01:39', '2017-03-24 06:01:39'),
(65, 20, 70, 'WeNet Support', '0.00', '', '2017-03-24 06:02:15', '2017-03-24 06:02:15'),
(66, 28, 70, 'PT Boro Support', '0.00', '', '2017-03-24 06:02:55', '2017-03-24 06:02:55'),
(68, 15, 113, 'myHub', '0.00', '', '2017-04-03 08:07:58', '2017-03-27 12:52:57'),
(69, 21, 87, 'ESM', '0.00', '', '2017-03-30 09:50:01', '2017-03-30 09:50:01'),
(70, 21, 87, 'SBANE', '0.00', '', '2017-03-30 09:50:22', '2017-03-30 09:50:22'),
(72, 27, 87, 'HR Site', '0.00', '', '2017-03-30 09:51:16', '2017-03-30 09:51:16'),
(73, 31, 87, 'TPP/P3', '0.00', '', '2017-03-31 07:08:47', '2017-03-31 07:08:47'),
(74, 14, 88, 'myShowcase', '0.00', '', '2017-04-03 08:45:04', '2017-04-03 08:45:04'),
(75, 14, 88, 'Omni Directional', '0.00', '', '2017-04-04 11:22:48', '2017-04-03 08:45:46'),
(76, 18, 89, 'Statement Search Tracker - Phase II', '0.00', '', '2017-04-04 08:25:40', '2017-04-04 08:25:40'),
(77, 18, 89, 'Convert Intranet Analytics to Google Analytics', '0.00', '', '2017-04-04 08:25:58', '2017-04-04 08:25:58'),
(78, 18, 89, 'Timesheet Report Job', '0.00', '', '2017-04-04 08:26:16', '2017-04-04 08:26:16'),
(79, 18, 70, 'Tiff Network Support', '0.00', '', '2017-04-04 12:39:54', '2017-04-04 11:55:39'),
(80, 30, 86, 'Township of Bridgewater(Testing)', '0.00', 'Testing of Bridgewater', '2017-04-05 05:42:20', '2017-04-05 05:34:20'),
(82, 15, 0, 'Training Team', '0.00', '', '2017-04-06 08:24:10', '2017-04-05 11:41:34'),
(83, 28, 86, 'Testing of Budget sheet app', '0.00', '', '2017-04-07 06:57:45', '2017-04-07 06:57:45'),
(84, 27, 86, 'Testing of Food and Beverage', '0.00', '', '2017-04-07 06:59:01', '2017-04-07 06:59:01'),
(85, 32, 87, 'UCSF', '0.00', '', '2017-04-07 08:42:32', '2017-04-07 08:42:32'),
(86, 33, 85, 'InterSoft Website Redesign', '0.00', '', '2017-04-10 05:16:48', '2017-04-10 05:16:48'),
(87, 27, 87, 'Tax Portal', '0.00', '', '2017-04-10 09:20:35', '2017-04-10 09:20:35'),
(88, 15, 87, 'TImeSheet App', '0.00', '', '2017-04-10 09:21:27', '2017-04-10 09:21:27'),
(89, 27, 87, 'Bid Portal', '0.00', '', '2017-04-10 12:20:30', '2017-04-10 12:20:30');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` int(10) NOT NULL,
  `company_id` int(10) NOT NULL,
  `project_id` int(10) NOT NULL,
  `task_type` varchar(255) NOT NULL,
  `task_titly` varchar(255) NOT NULL,
  `alloceted_hours` decimal(5,2) NOT NULL,
  `assign_to` int(16) DEFAULT NULL,
  `done` tinyint(1) NOT NULL DEFAULT '0',
  `task_description` text NOT NULL,
  `billable` tinyint(1) NOT NULL,
  `date_finish` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `company_id`, `project_id`, `task_type`, `task_titly`, `alloceted_hours`, `assign_to`, `done`, `task_description`, `billable`, `date_finish`, `created_at`, `updated_at`) VALUES
(35, 17, 32, 'Quality Assurance', 'HMSDC Event Registration', '0.00', 0, 1, 'Please review attached.   This is a picture of the Event Registration page as viewed on an iPhone.   \r\n\r\nWe are unable to process registration request through any mobile device.    There is no way go get to any of the registration buttons.  \r\n\r\nPlease QA.\r\n', 1, '2017-02-09 14:20:15', '2017-01-21 06:34:20', '2017-02-09 14:20:15'),
(36, 17, 32, 'New Feature', 'HMSDC Events', '0.00', 85, 0, 'Please remove all current Construction Industry Group Meetings and replace with new dates below', 1, NULL, '2017-01-21 06:35:18', '2017-02-07 07:33:34'),
(38, 19, 39, 'New Feature', 'Update the contact details', '0.00', 85, 0, 'update the contact details and google map location on stage site', 1, NULL, '2017-01-23 09:06:17', '2017-01-23 09:09:44'),
(39, 19, 43, 'New Feature', 'Updates and changes', '0.00', 85, 0, 'Update as per attached LMZ', 0, NULL, '2017-01-23 09:09:28', '2017-01-23 09:09:28'),
(40, 19, 42, 'New Feature', 'Updates', '0.00', 85, 0, 'updated content, images from live site', 0, NULL, '2017-01-23 09:17:59', '2017-01-23 09:17:59'),
(41, 21, 45, 'Bug Fixing', 'Barnstable code rule fixes', '0.00', 92, 0, '1.Barnstable code rule fixes', 0, NULL, '2017-01-24 05:56:03', '2017-01-24 05:56:03'),
(42, 20, 44, 'Bug Fixing', 'Accelerator Code Rule Fixes', '0.00', 93, 0, '1.       Accelerator Code Rule Fixes', 0, NULL, '2017-01-24 05:56:46', '2017-01-24 05:56:46'),
(43, 17, 33, 'New Feature', 'Web site Updates  - GNEMSDC', '0.00', 85, 0, 'Web site Updates  - GNEMSDC', 1, NULL, '2017-01-24 06:16:13', '2017-02-06 12:56:16'),
(44, 18, 34, 'Quality Assurance', 'Automation maintenance of TIFF', '8.00', 86, 1, '1) Execution of Tiff Script.', 1, '2017-04-10 09:09:31', '2017-01-24 06:39:08', '2017-04-10 09:09:31'),
(47, 15, 46, 'New Feature', 'Monthly Newsletter', '0.00', 85, 0, 'Update text and images in monthly newsletter', 0, NULL, '2017-01-25 05:17:04', '2017-01-25 05:17:04'),
(52, 15, 46, 'New Feature', 'Blog Formating', '1.00', 85, 0, 'Blog and save to draft the same way you did for the last time as this blog also has coding section similar to last blog. ', 0, NULL, '2017-01-25 06:05:53', '2017-01-25 06:05:53'),
(53, 15, 46, 'New Feature', 'Editing for the Blog image', '0.00', 85, 0, 'Editing for the Blog image', 0, NULL, '2017-01-25 06:09:52', '2017-01-25 06:09:52'),
(56, 19, 39, 'New Feature', 'make A&A Dubai site live ', '2.00', 70, 0, 'make A&A Dubai live today,', 1, NULL, '2017-01-25 06:55:53', '2017-01-25 06:56:56'),
(57, 19, 39, 'New Feature', 'make A&A Dubai live today', '2.00', 85, 0, 'make A&A Dubai live today,check and review support', 1, NULL, '2017-01-25 06:57:51', '2017-01-26 11:41:53'),
(58, 19, 39, 'New Feature', 'Update the description', '0.00', 85, 0, 'update the description', 1, NULL, '2017-01-25 07:27:21', '2017-01-25 07:27:21'),
(62, 21, 45, 'New Feature', 'Bug fixing', '0.00', 93, 0, 'Bug fixing', 0, NULL, '2017-01-25 10:20:00', '2017-01-26 11:41:39'),
(72, 15, 46, 'New Feature', 'Updates of Blog/Case Studies ', '1.00', 85, 0, 'Updates of Blog/Case Studies', 0, NULL, '2017-01-27 05:02:12', '2017-01-27 05:02:12'),
(73, 19, 43, 'New Feature', 'Update category product ', '5.00', 97, 0, 'Update category product, cropped images, updated in light box also', 0, NULL, '2017-01-27 05:42:23', '2017-01-27 13:19:38'),
(74, 15, 46, 'New Feature', 'Project Updates - Creative Team', '1.00', 85, 0, 'Project Updates - Creative Team', 0, NULL, '2017-01-27 07:57:59', '2017-02-06 12:56:17'),
(75, 19, 39, 'New Feature', 'Canvas pointer cursor issue', '2.00', 85, 0, 'Canvas pointer cursor issue', 0, NULL, '2017-01-27 13:28:14', '2017-01-27 13:28:14'),
(76, 17, 32, 'New Feature', 'HMSDC Event Updates', '1.00', 85, 0, 'HMSDC Event Updates', 1, NULL, '2017-01-30 04:19:38', '2017-01-30 04:19:38'),
(77, 19, 39, 'Bug Fixing', 'Responsive Fixing for Dubai Site', '0.00', 85, 0, 'Responsive Fixing for mobile devices', 0, '2017-02-06 10:34:34', '2017-01-30 08:27:17', '2017-02-06 10:34:34'),
(78, 19, 39, 'Bug Fixing', 'Responsive Fixing for German Site', '0.00', 85, 0, 'Responsive Fixing for Mobile Devices', 0, NULL, '2017-01-30 08:28:32', '2017-01-30 08:29:20'),
(79, 19, 39, 'New Feature', 'Designing', '0.00', 100, 0, 'SEO\r\nDesign Review\r\nDesign Updates', 0, '2017-02-07 06:08:16', '2017-01-31 12:31:44', '2017-02-07 06:08:16'),
(80, 19, 40, 'New Feature', 'Desining ', '0.00', 100, 0, 'SEO\r\nDesign Review\r\nDesign Updates', 0, '2017-02-07 06:08:17', '2017-01-31 12:32:30', '2017-02-07 06:08:17'),
(81, 19, 42, 'New Feature', 'Desining', '0.00', 100, 1, 'SEO\r\nDesign Review\r\nDesign Updates', 0, '2017-03-27 14:22:37', '2017-01-31 12:32:52', '2017-03-27 14:22:37'),
(82, 19, 43, 'New Feature', 'Desining', '0.00', 100, 0, 'SEO\r\nDesign Review\r\nDesign Updates', 0, '2017-02-06 10:34:35', '2017-01-31 12:33:26', '2017-02-06 10:34:35'),
(84, 19, 40, 'Bug Fixing', 'LMZ remaining updates', '0.30', 97, 0, 'LMZ remaining updates', 0, NULL, '2017-02-01 06:21:35', '2017-02-01 06:21:35'),
(95, 18, 50, 'New Feature', 'TIFF mockup', '3.00', 97, 0, 'TIFF Mockup', 1, NULL, '2017-02-02 06:38:30', '2017-03-28 09:26:09'),
(96, 15, 46, 'New Feature', 'Banner for Moodle Services', '0.00', 97, 0, 'Banner for Moodle Services on ignatiuz site home page', 0, NULL, '2017-02-02 07:15:59', '2017-02-02 07:15:59'),
(97, 19, 40, 'New Feature', 'A&A Germany', '0.00', 85, 0, 'A&A Germany changes and fixes', 0, NULL, '2017-02-02 09:38:04', '2017-02-02 09:38:04'),
(98, 14, 27, 'Quality Assurance', 'test task for QA ', '10.15', 0, 1, 'test task for QA ', 1, '2017-02-15 11:45:38', '2017-02-02 11:45:09', '2017-02-15 11:47:03'),
(99, 19, 40, 'New Feature', 'A&A Germany', '0.00', 97, 0, 'work for English language  menu, pages, home page all the features.', 1, NULL, '2017-02-03 04:43:43', '2017-02-03 04:43:43'),
(100, 15, 46, 'New Feature', 'Banner for Moodle Services', '0.00', 85, 0, 'Banner for Moodle Services', 0, NULL, '2017-02-03 04:55:51', '2017-02-03 04:55:51'),
(101, 19, 40, 'New Feature', 'A&A Germany', '0.00', 85, 0, 'Create new template for english site with all the home page features', 0, NULL, '2017-02-03 04:56:41', '2017-02-03 04:56:41'),
(102, 19, 39, 'New Feature', 'live site showing blank page', '0.00', 85, 0, 'aaemllc live site showing blank white page, not loading', 0, NULL, '2017-02-06 08:38:03', '2017-02-06 08:38:03'),
(103, 14, 27, 'Quality Assurance', 'Test for admin people report', '10.15', 44, 0, '', 1, '2017-02-06 10:40:39', '2017-02-06 10:36:03', '2017-02-06 10:57:32'),
(104, 14, 27, 'Quality Assurance', 'test for qa people report', '10.15', 0, 0, '', 0, '2017-02-06 11:05:51', '2017-02-06 11:03:06', '2017-02-06 11:05:51'),
(105, 19, 39, 'Bug Fixing', 'Browser issue', '0.00', 85, 0, 'Browser issue', 0, NULL, '2017-02-06 11:45:30', '2017-02-06 11:45:30'),
(106, 19, 40, 'New Feature', 'Web site Updates', '0.00', 97, 0, 'Web site Updates', 0, NULL, '2017-02-06 11:46:23', '2017-02-06 11:46:23'),
(107, 18, 50, 'New Feature', 'few more mockups', '0.00', 97, 1, 'create few more mockups as attached feedback', 1, '2017-03-29 11:18:04', '2017-02-07 04:56:10', '2017-03-29 11:18:04'),
(108, 15, 46, 'New Feature', 'Project Updates - Meeting', '0.15', 85, 0, 'Customizing cursor pointer animation in WordPress  plugin banner.', 0, NULL, '2017-02-07 07:16:13', '2017-02-07 07:16:13'),
(112, 15, 46, 'New Feature', 'External Newsletter', '11.00', 85, 0, 'External Newsletter', 0, NULL, '2017-02-08 05:04:23', '2017-02-09 11:31:55'),
(113, 15, 46, 'New Feature', 'Brochures Updates', '1.00', 91, 0, 'Brochures Updates', 1, NULL, '2017-02-08 06:35:51', '2017-03-28 12:03:15'),
(117, 15, 46, 'New Feature', 'Update Banner Plugin', '0.15', 85, 0, 'updated banner in stage gdiz site.', 0, NULL, '2017-02-09 06:03:13', '2017-02-09 11:26:30'),
(120, 14, 27, 'New Feature', 'Demo Application registration.', '2.15', 73, 1, 'Demo Application registration for Trial version on Version 1.4.8.', 1, '2017-02-09 12:08:40', '2017-02-09 11:49:11', '2017-02-09 12:08:40'),
(121, 19, 40, 'Bug Fixing', 'Test', '0.00', 91, 0, 'Test', 1, NULL, '2017-02-09 12:01:18', '2017-03-28 12:03:06'),
(122, 19, 40, 'Bug Fixing', 'QA issue Fixes', '3.00', 85, 0, 'QA issue Fixes', 0, NULL, '2017-02-09 12:02:26', '2017-02-09 12:02:26'),
(123, 15, 46, 'New Feature', 'GDIZ Website', '0.00', 85, 0, 'GDIZ Website', 0, NULL, '2017-02-09 12:03:18', '2017-02-09 12:03:18'),
(124, 15, 46, 'New Feature', 'Created Newsletter', '0.00', 85, 0, 'Created Newsletter', 0, NULL, '2017-02-10 13:13:30', '2017-02-10 13:13:30'),
(125, 17, 32, 'New Feature', 'check and updates', '0.00', 85, 0, 'check and updates', 0, NULL, '2017-02-10 13:21:58', '2017-02-10 13:21:58'),
(126, 17, 33, 'New Feature', 'check and updates', '0.00', 85, 0, 'check and updates', 0, NULL, '2017-02-10 13:22:09', '2017-02-10 13:22:17'),
(127, 19, 40, 'Bug Fixing', 'QA issue Fixes', '0.00', 85, 0, 'QA issue Fixes', 0, NULL, '2017-02-13 04:27:52', '2017-02-13 04:27:52'),
(128, 17, 33, 'New Feature', 'GNEMSDC Newsletters -', '0.00', 91, 1, 'GNEMSDC Newsletters -', 1, '2017-02-13 06:19:50', '2017-02-13 05:08:54', '2017-02-13 06:19:50'),
(129, 17, 33, 'New Feature', 'GNEMSDC Calendar', '0.00', 91, 1, 'GNEMSDC Calendar', 1, '2017-03-28 13:11:10', '2017-02-13 05:09:24', '2017-03-28 13:11:10'),
(130, 18, 50, 'New Feature', ' Strategic Planning site', '0.00', 97, 1, ' Strategic Planning site', 1, '2017-02-13 12:18:23', '2017-02-13 09:07:07', '2017-02-13 12:18:23'),
(131, 15, 46, 'New Feature', 'Newsletter HTML', '0.00', 85, 0, 'Newsletter HTML', 0, NULL, '2017-02-13 13:15:21', '2017-02-13 13:15:21'),
(132, 19, 39, 'Bug Fixing', 'Macpro browser issue', '0.00', 85, 0, 'Macpro browser issue fixes on client end via TV', 0, NULL, '2017-02-14 05:15:49', '2017-02-14 05:15:49'),
(133, 15, 51, 'New Feature', 'Test developers account', '0.50', 0, 1, 'Test developers account', 1, '2017-02-14 09:31:42', '2017-02-14 05:46:46', '2017-02-14 09:31:42'),
(134, 17, 32, 'New Feature', 'HMSDC - Events', '0.00', 97, 1, 'HMSDC - Events', 1, '2017-02-14 11:26:42', '2017-02-14 07:59:42', '2017-02-14 11:26:42'),
(135, 19, 40, 'Bug Fixing', 'A&A Germany and Dubai', '0.00', 85, 0, 'A&A Germany and Dubai Ipad', 0, NULL, '2017-02-15 04:57:48', '2017-02-15 04:57:48'),
(137, 19, 40, 'Bug Fixing', 'window 10 animation issue', '0.00', 85, 0, 'window 10 animation issue while touch and cursor over function', 0, NULL, '2017-02-16 13:45:38', '2017-02-16 13:45:38'),
(138, 15, 46, 'New Feature', 'Twitter header', '0.00', 97, 0, 'Twitter header', 0, NULL, '2017-02-17 04:37:02', '2017-02-17 04:37:11'),
(139, 15, 46, 'New Feature', 'External Newsletter', '0.00', 85, 0, 'Newsletter Updates and changes', 0, NULL, '2017-02-20 13:29:52', '2017-02-20 13:29:52'),
(140, 15, 51, 'New Feature', 'GeoDirectory', '0.00', 85, 0, 'GeoDirectory - Directory Plugin for word press, ', 0, NULL, '2017-02-20 13:31:31', '2017-02-20 13:31:31'),
(141, 15, 46, 'New Feature', 'Microsoft Teams Blog', '0.00', 97, 0, 'Feature Image creation for Microsoft Teams Blog', 0, NULL, '2017-02-21 06:43:07', '2017-02-21 06:43:07'),
(142, 15, 46, 'New Feature', 'External Newsletter', '0.00', 85, 0, 'Update in Newsletter', 0, NULL, '2017-02-21 06:45:37', '2017-02-21 06:45:37'),
(143, 17, 33, 'New Feature', 'GNEMSDC - New Section on Home Page', '0.00', 97, 0, 'GNEMSDC - New Section on Home Page', 1, NULL, '2017-02-22 05:06:50', '2017-02-22 05:08:07'),
(144, 17, 33, 'New Feature', 'GNEMSDC Footer', '0.00', 97, 0, 'GNEMSDC Footer updates', 1, NULL, '2017-02-22 05:08:00', '2017-02-22 05:08:00'),
(145, 15, 46, 'New Feature', 'External Newsletter', '0.00', 91, 1, 'External Newsletter G Suite', 0, '2017-03-31 10:31:51', '2017-02-27 10:38:18', '2017-03-31 10:31:51'),
(146, 15, 46, 'New Feature', 'GDIZ Website', '0.00', 97, 0, 'GDIZ Website', 0, NULL, '2017-02-27 10:38:57', '2017-02-27 10:38:57'),
(147, 19, 40, 'Bug Fixing', 'Browser issue', '3.00', 85, 0, 'Browser issue', 0, NULL, '2017-02-27 10:39:30', '2017-02-28 09:50:12'),
(148, 15, 46, 'New Feature', 'Case Studies', '2.00', 85, 0, 'Instead of having “ #” on image please insert the category name in case study section', 0, NULL, '2017-02-28 05:35:17', '2017-02-28 09:50:00'),
(149, 15, 46, 'New Feature', 'External Newsletter', '0.00', 91, 1, 'External Newsletter', 0, '2017-03-28 09:13:29', '2017-02-28 12:40:22', '2017-03-28 12:10:45'),
(150, 19, 39, 'Bug Fixing', 'Bug Fixing', '0.00', 85, 0, 'Bug Fixing', 0, NULL, '2017-02-28 12:41:18', '2017-02-28 12:41:18'),
(151, 17, 33, 'New Feature', 'GNEMSDC Events - Website', '0.30', 91, 0, 'GNEMSDC Events - Website', 1, NULL, '2017-03-02 04:38:24', '2017-03-03 07:26:43'),
(152, 17, 33, 'New Feature', 'GNEMSDC - Subscription new application', '0.30', 91, 0, 'GNEMSDC - Subscription new application', 1, NULL, '2017-03-02 04:38:52', '2017-03-03 07:26:32'),
(153, 21, 45, 'New Feature', 'Scope of Work', '0.00', 97, 0, 'Created Mock up', 1, NULL, '2017-03-03 06:52:26', '2017-03-03 06:52:26'),
(154, 26, 52, 'New Feature', 'Updates and Changes', '6.00', 91, 1, 'Updates and Changes', 1, '2017-03-27 05:49:08', '2017-03-03 07:25:15', '2017-03-27 05:49:08'),
(155, 26, 52, 'New Feature', 'Updates and Changes', '0.00', 97, 1, 'Updates and Changes', 0, '2017-04-04 04:06:46', '2017-03-06 05:07:13', '2017-04-04 04:06:46'),
(156, 17, 33, 'New Feature', 'GNEMSDC Sponsors', '0.00', 97, 0, 'GNEMSDC Sponsors', 1, NULL, '2017-03-06 12:46:27', '2017-03-06 12:46:27'),
(157, 17, 32, 'New Feature', 'Past HMSDC Events -', '0.00', 97, 0, 'Past HMSDC Events -', 1, NULL, '2017-03-06 12:46:48', '2017-03-06 12:46:48'),
(158, 26, 52, 'New Feature', 'Updates and Changes', '6.00', 85, 0, 'Updates and Changes', 0, NULL, '2017-03-06 12:47:12', '2017-03-06 12:47:28'),
(159, 14, 27, 'New Feature', 'Created Windows 10 Keyboard', '0.00', 91, 0, 'Created Windows 10 Keyboard in Inkscape tool  and illustrator tools', 1, NULL, '2017-03-07 05:20:04', '2017-03-07 05:20:04'),
(160, 26, 52, 'New Feature', 'Updates and Changes', '0.00', 97, 0, 'Updates and Changes as per mail', 0, NULL, '2017-03-07 05:20:45', '2017-03-07 05:20:45'),
(161, 26, 52, 'New Feature', 'Updates and Changes', '0.00', 85, 0, 'Updates and Changes as per mail', 0, NULL, '2017-03-07 05:21:11', '2017-03-07 05:21:11'),
(162, 18, 34, 'New Feature', 'Automation of Web Admin Portal', '8.00', 86, 1, '1. Web admin portal use case automation', 1, '2017-03-21 06:18:12', '2017-03-07 07:20:26', '2017-03-21 06:18:12'),
(163, 17, 32, 'New Feature', 'HMSDC Events & Calendar', '0.00', 97, 0, 'HMSDC Events & Calendar', 1, NULL, '2017-03-08 04:44:10', '2017-03-08 04:44:10'),
(164, 17, 32, 'New Feature', 'Public Policy Day Banner', '0.00', 97, 0, 'Public Policy Day Banner', 1, NULL, '2017-03-08 04:45:34', '2017-03-08 04:45:34'),
(165, 26, 52, 'New Feature', 'Updates and Changes', '0.00', 85, 0, 'Updates and Changes', 0, NULL, '2017-03-08 05:39:50', '2017-03-08 05:39:50'),
(166, 19, 40, 'Bug Fixing', 'updates and responsive', '0.00', 85, 0, 'updates and responsive', 0, NULL, '2017-03-08 05:40:35', '2017-03-08 05:40:35'),
(167, 25, 54, 'Quality Assurance', 'LiveStuff Browser Add on - Add to it  ', '4.00', 0, 0, '1. Will Test LiveStuff Browser Add on - Add to it  - In QA Task\r\n', 0, NULL, '2017-03-08 06:47:36', '2017-03-08 06:47:36'),
(168, 18, 34, 'New Feature', 'Automation of Web-Admin portal', '4.00', 109, 1, 'Assist Anish in Web -Admin portal Automation', 1, '2017-03-08 13:04:45', '2017-03-08 06:49:42', '2017-03-08 13:04:45'),
(169, 17, 32, 'New Feature', 'update on HMSDC website.', '0.30', 73, 1, '', 0, '2017-04-10 14:09:04', '2017-03-08 07:56:36', '2017-04-10 14:09:04'),
(170, 14, 27, 'Bug Fixing', 'Test fixed reported issues on myShowcase App. ', '3.00', 73, 1, 'Test Fixed reported issues.\r\nPerform regression testing on myshowcase App. (Installer 1.5.1)', 0, '2017-04-10 14:09:00', '2017-03-08 07:59:36', '2017-04-10 14:09:00'),
(171, 17, 32, 'New Feature', ' Public Policy Day Banner', '0.30', 97, 0, ' Public Policy Day Banner Changes', 1, NULL, '2017-03-09 04:44:32', '2017-03-10 04:41:28'),
(172, 26, 52, 'New Feature', 'Updates and Changes', '4.30', 97, 0, 'as per mail and meeting notes', 1, NULL, '2017-03-09 05:02:45', '2017-03-10 04:41:11'),
(173, 26, 52, 'New Feature', 'Updates and Changes', '2.00', 85, 0, 'as per mail and meeting notes', 0, NULL, '2017-03-09 05:03:09', '2017-03-09 08:53:11'),
(174, 26, 52, 'New Feature', 'Updates and Changes', '3.00', 97, 0, 'GIBF Content and section updates', 0, NULL, '2017-03-10 04:42:30', '2017-03-10 14:10:17'),
(175, 17, 32, 'New Feature', 'Updates and Changes', '1.00', 97, 0, '1) Correct the time for the event below\r\n2) Please remove these banners', 1, NULL, '2017-03-10 05:29:04', '2017-04-04 04:47:26'),
(176, 19, 40, 'Bug Fixing', 'Browser issue', '2.00', 85, 0, 'Browser issue, responsive', 0, NULL, '2017-03-10 14:11:13', '2017-03-10 14:11:13'),
(177, 21, 45, 'Quality Assurance', 'Manual Testing of Barnstable', '4.00', 109, 1, '1. Test Barnstable entire site', 0, '2017-03-15 13:36:39', '2017-03-14 06:49:51', '2017-03-15 13:36:39'),
(178, 18, 50, 'New Feature', 'mock up', '0.00', 97, 0, 'mock up', 0, NULL, '2017-03-14 10:29:26', '2017-03-14 10:29:26'),
(179, 17, 32, 'New Feature', 'HMSDC Slider', '0.30', 85, 0, 'HMSDC Slider', 1, NULL, '2017-03-14 11:45:02', '2017-03-14 11:45:02'),
(180, 17, 32, 'New Feature', 'HMSDC Events & Calendar', '0.45', 85, 0, 'HMSDC Events', 1, NULL, '2017-03-14 11:46:03', '2017-03-14 11:46:03'),
(181, 17, 33, 'Bug Fixing', 'GNEMSDC Sponsors', '0.30', 85, 0, 'GNEMSDC Sponsors - fixed page for mobile view', 0, NULL, '2017-03-14 11:46:53', '2017-03-14 11:46:53'),
(182, 17, 33, 'New Feature', 'GNEMSDC Sponsors', '1.00', 97, 0, 'GNEMSDC Sponsors - update logo', 1, NULL, '2017-03-14 11:49:52', '2017-03-14 11:49:52'),
(183, 27, 56, 'New Feature', 'Mockups', '0.00', 97, 1, 'Create mock ups for OB Food & Beverage site. Refer tax portal site for themes ', 1, '2017-03-28 09:26:44', '2017-03-14 12:30:11', '2017-03-28 09:26:44'),
(184, 26, 52, 'New Feature', 'Updates and Changes', '0.00', 85, 0, 'I appreciate the opportunity for this performance review', 0, NULL, '2017-03-15 04:56:59', '2017-03-15 04:56:59'),
(185, 26, 52, 'New Feature', 'Updates and Changes', '5.00', 85, 0, '[Done]', 0, NULL, '2017-03-15 13:38:32', '2017-03-15 13:38:32'),
(186, 19, 40, 'Bug Fixing', 'facebook updates issue', '1.00', 85, 0, 'facebook updates issue', 1, NULL, '2017-03-15 13:39:09', '2017-03-15 13:39:09'),
(187, 18, 50, 'New Feature', 'Create HTML for animation effects', '0.00', 97, 0, 'Create HTML for animation effects', 1, NULL, '2017-03-16 04:41:40', '2017-03-16 04:41:40'),
(188, 26, 52, 'New Feature', 'Updates and Changes', '0.00', 85, 0, 'Updates and Changes', 0, NULL, '2017-03-16 04:42:09', '2017-03-16 04:42:09'),
(189, 19, 40, 'New Feature', 'Add Video', '0.00', 85, 0, 'Add Video', 0, NULL, '2017-03-16 04:43:27', '2017-03-16 04:43:27'),
(190, 27, 58, 'New Feature', 'Creation of Test Cases', '0.00', 109, 0, 'Test case creation of :-\r\n1. Login screen\r\n2. Search screen\r\n3. Add new License screen\r\n\r\n', 0, NULL, '2017-03-16 08:49:55', '2017-03-21 05:48:30'),
(191, 27, 58, 'New Feature', 'Creation of Test Plan', '0.00', 109, 1, '1. Preparation of Test Plan', 0, '2017-03-16 12:34:25', '2017-03-16 08:50:37', '2017-03-16 12:34:25'),
(192, 27, 58, 'New Feature', 'KT from Pooja', '0.00', 109, 1, '1.Take KT from Pooja ON Food and Bevrages', 0, '2017-03-16 09:58:16', '2017-03-16 08:51:59', '2017-03-16 09:58:16'),
(193, 30, 59, 'Quality Assurance', 'Manual Testing of Bridgewater', '0.00', 109, 0, '1. Manual Testing of Bridgewater whole site', 0, NULL, '2017-03-20 05:01:13', '2017-03-20 05:01:13'),
(194, 17, 33, 'New Feature', 'Updates and Changes', '0.00', 97, 0, 'Updates and Changes', 1, NULL, '2017-03-20 05:32:13', '2017-03-20 05:32:13'),
(195, 17, 33, 'New Feature', 'Updates and Changes', '0.00', 97, 0, 'Updates and Changes', 1, NULL, '2017-03-20 05:32:34', '2017-03-20 05:32:34'),
(196, 26, 52, 'New Feature', 'Updates and Changes', '0.00', 85, 0, 'Updates and Changes', 0, NULL, '2017-03-20 05:33:00', '2017-03-20 05:33:00'),
(197, 28, 57, 'New Feature', 'Login Page', '8.00', 111, 0, 'Login Page design ,Create  database table and stored procedure for login. ', 1, NULL, '2017-03-20 13:40:11', '2017-03-20 13:41:05'),
(198, 19, 40, 'Bug Fixing', 'Updates and Changes', '0.00', 85, 0, '<div class="header_top_menu"></div>\r\n<div class="clear"></div>', 0, NULL, '2017-03-21 05:33:33', '2017-03-21 05:33:33'),
(199, 26, 52, 'Bug Fixing', 'Updates and Changes', '0.00', 97, 0, 'Updates and Changes', 0, NULL, '2017-03-21 05:34:04', '2017-03-21 05:34:04'),
(200, 15, 46, 'New Feature', 'Newsletter HTML', '0.00', 91, 0, 'Newsletter HTML', 0, NULL, '2017-03-21 05:34:32', '2017-03-28 14:15:36'),
(201, 17, 33, 'New Feature', 'Updates and Changes', '0.00', 85, 0, 'Updates and Changes', 1, NULL, '2017-03-21 05:34:54', '2017-03-21 05:34:54'),
(202, 27, 56, 'New Feature', 'Create HTML', '0.00', 97, 1, 'OB Food & Beverage HTML', 1, '2017-03-29 11:18:11', '2017-03-22 06:37:11', '2017-03-29 11:18:11'),
(203, 18, 50, 'New Feature', 'reate separate icons', '0.00', 97, 0, 'Attached image is containing various icons. Please create separate icons for each', 1, NULL, '2017-03-22 06:44:20', '2017-03-22 06:44:20'),
(204, 28, 57, 'New Feature', ' Design Helper entry form. Create database table. ', '8.00', 111, 0, '\r\nDesign Helper entry form. Create database table. \r\n', 1, NULL, '2017-03-22 07:15:46', '2017-03-22 07:15:46'),
(205, 28, 57, 'New Feature', 'Create SP, Code to save Helper entry form', '8.00', 111, 0, 'Create stored procedure and add code for save helper entry form data.\r\nDesign Department sheet entry form. Create database table.', 1, NULL, '2017-03-22 07:16:43', '2017-03-22 07:16:43'),
(206, 28, 57, 'New Feature', 'Create SP and code to save Department Sheet ', '8.00', 111, 0, 'Create stored procedure and add code for save department sheet data.Design WorkSheet B  UI. ', 1, NULL, '2017-03-22 07:17:35', '2017-03-22 07:17:35'),
(207, 28, 57, 'New Feature', 'Table/SP and Code for Worksheet B', '8.00', 111, 1, 'Create Table/SP for Worksheet B and add code for save entry.', 1, '2017-04-03 14:22:27', '2017-03-22 07:18:21', '2017-04-03 14:22:27'),
(208, 28, 57, 'New Feature', 'Create interface to  run current year budget report.', '8.00', 111, 0, 'Create interface for run current year budget report.', 1, NULL, '2017-03-22 07:18:59', '2017-03-22 07:18:59'),
(209, 28, 57, 'New Feature', 'Get Current year budget detail and budget summary details data.', '8.00', 111, 0, 'Get Current year budget detail and budget summary details data.', 1, NULL, '2017-03-22 07:19:34', '2017-03-22 07:19:34'),
(210, 28, 57, 'New Feature', 'Code for calculate data and create report', '8.00', 111, 0, 'Code for calculate data and create report', 1, NULL, '2017-03-22 07:20:15', '2017-03-22 07:20:15'),
(211, 26, 52, 'New Feature', 'Updates and Changes', '0.00', 85, 0, 'Updates and Changes', 0, NULL, '2017-03-22 07:29:21', '2017-03-22 07:29:21'),
(212, 15, 46, 'New Feature', 'Newsletter HTML', '0.00', 91, 0, 'Updates and Changes', 0, NULL, '2017-03-22 07:29:45', '2017-03-28 12:10:38'),
(213, 28, 57, 'New Feature', 'Development of Report for Sheet A', '24.00', 111, 1, 'Get data, design and development for PDF for Sheet A ', 1, '2017-04-04 13:20:49', '2017-03-22 12:00:57', '2017-04-04 13:20:49'),
(214, 17, 33, 'New Feature', 'Updates and Changes', '0.00', 97, 0, 'Updates and Changes', 1, NULL, '2017-03-22 14:25:13', '2017-03-22 14:25:13'),
(215, 27, 55, 'New Feature', 'Redesign Mock up', '0.00', 97, 0, 'Redesign Mock up', 1, NULL, '2017-03-23 05:14:18', '2017-03-23 05:14:18'),
(216, 30, 59, 'Quality Assurance', 'Testing of Bridgewater', '0.00', 109, 0, '1.Updation and creation of all the mails\r\n2. Testing of mails from various other user ', 0, NULL, '2017-03-23 05:29:56', '2017-03-23 05:29:56'),
(217, 28, 57, 'New Feature', 'Development of Report for Sheet B', '16.00', 111, 1, 'Get data, design and development for PDF for Sheet B ', 1, '2017-04-03 14:22:23', '2017-03-23 13:05:55', '2017-04-03 14:22:23'),
(218, 28, 57, 'New Feature', 'Development of Report for Sheet C', '16.00', 111, 0, 'Get data, design and development for PDF for Sheet C', 1, NULL, '2017-03-23 13:06:32', '2017-03-23 13:06:32'),
(219, 28, 57, 'New Feature', 'Development of Report for Sheet D', '16.00', 111, 0, 'Get data, design and development for PDF for Sheet D ', 1, NULL, '2017-03-23 13:07:22', '2017-03-23 13:07:22'),
(220, 28, 57, 'New Feature', ' Marge all report in PDF file', '16.00', 111, 0, 'Marge all report in PDF file\r\n', 1, NULL, '2017-03-23 13:08:00', '2017-03-23 13:08:00'),
(221, 28, 57, 'New Feature', 'Add code for department wise report generation', '8.00', 111, 0, 'Add code for department wise report generation\r\n', 1, NULL, '2017-03-23 13:08:54', '2017-03-23 13:08:54'),
(222, 15, 46, 'New Feature', 'Blog html', '0.00', 97, 0, 'Blog html for Get email delivery and read receipt by HttpModule', 0, NULL, '2017-03-24 04:57:49', '2017-03-24 04:57:49'),
(223, 15, 61, 'New Feature', 'Create HTML', '0.00', 97, 1, 'Create HTML for home page and inner pages', 0, '2017-03-29 05:32:26', '2017-03-24 04:58:41', '2017-03-29 05:32:26'),
(224, 19, 40, 'Bug Fixing', 'QA issue Fixes', '2.00', 85, 0, 'QA issue Fixes', 0, NULL, '2017-03-24 04:59:29', '2017-03-27 05:39:24'),
(225, 27, 58, 'New Feature', 'Login Page Design, Stored Procedure, Methods', '8.00', 92, 0, 'Development of login page', 1, NULL, '2017-03-24 06:31:16', '2017-03-24 06:31:16'),
(226, 27, 58, 'Quality Assurance', 'Test case creation of FBLMS', '0.00', 109, 1, 'Test case creation of FBLMS:-\r\n1. View/edit/renew/Unrevoke page\r\n2. Reports/Licence/Certificates\r\n3. Update system Variables', 0, '2017-03-28 04:50:24', '2017-03-24 06:34:10', '2017-03-28 04:50:24'),
(227, 27, 58, 'New Feature', 'Master Page ', '16.00', 92, 0, 'Master Page Creation and Design Integration with Page already Created', 1, NULL, '2017-03-24 06:34:17', '2017-03-24 06:34:17'),
(228, 27, 58, 'New Feature', 'Breadcrumb ', '8.00', 92, 0, 'Breadcrumb ', 1, NULL, '2017-03-24 06:44:48', '2017-03-24 06:44:48'),
(229, 27, 58, 'New Feature', 'Left Navigation', '8.00', 92, 0, 'Development of Left Navigation', 1, NULL, '2017-03-24 06:45:19', '2017-03-24 06:45:19'),
(230, 27, 58, 'New Feature', 'System Variables Logging', '16.00', 93, 0, 'Page for  updating system variables and logging.', 1, NULL, '2017-03-24 06:47:17', '2017-03-24 06:47:35'),
(231, 27, 58, 'New Feature', 'Add License', '8.00', 93, 0, 'Development of Add License page', 1, NULL, '2017-03-24 06:48:17', '2017-03-24 06:48:17'),
(232, 27, 58, 'New Feature', 'Payment Terms Condition Page,Coveyence Fees Pages', '8.00', 93, 0, 'Payment Terms Condition Page,Coveyence Fees Pages', 1, NULL, '2017-03-24 06:48:51', '2017-03-24 06:48:51'),
(233, 27, 58, 'New Feature', 'Pay By Cash', '8.00', 93, 0, 'License Payment by Cash', 1, NULL, '2017-03-24 06:49:35', '2017-03-24 06:49:35'),
(234, 27, 58, 'New Feature', 'License Search Page', '16.00', 92, 0, 'Development of License Search Page with various criteria ', 1, NULL, '2017-03-24 07:02:02', '2017-03-24 07:02:02'),
(235, 27, 58, 'New Feature', 'Events Search Page', '12.00', 93, 0, 'Development of Events Search Page using various criteria ', 1, NULL, '2017-03-24 07:03:45', '2017-03-24 07:06:18'),
(236, 27, 58, 'New Feature', 'View/Edit & Update License', '16.00', 93, 0, 'Development of View/Edit & Update License', 1, NULL, '2017-03-24 07:04:26', '2017-03-24 07:04:26'),
(237, 27, 58, 'New Feature', 'Report Page for All the reports', '24.00', 93, 0, 'Report Page for All the reports', 1, NULL, '2017-03-24 07:05:49', '2017-03-24 07:05:49'),
(238, 27, 58, 'New Feature', 'License Renewal ', '8.00', 93, 0, 'Page to renew license', 1, NULL, '2017-03-24 07:09:29', '2017-03-24 07:09:29'),
(239, 27, 58, 'New Feature', 'License Delete, Revoke & UnRevoke', '8.00', 93, 0, 'Page for elete, Revoke & UnRevoke License ', 1, NULL, '2017-03-24 07:10:03', '2017-03-24 07:10:03'),
(240, 27, 58, 'New Feature', 'License Inspection & Re Inspection, Payment', '16.00', 93, 0, 'Pages for License Inspection & Re Inspection, Payment', 1, NULL, '2017-03-24 07:10:47', '2017-03-24 07:10:47'),
(241, 27, 58, 'New Feature', 'License Cancellation & Inspection Passed Date ', '8.00', 93, 0, 'Updates on License Cancellation & Inspection Passed Date ', 1, NULL, '2017-03-24 07:12:03', '2017-03-24 07:12:03'),
(242, 27, 58, 'New Feature', 'Letter Writing Search Page, Report, Letter Wrtting & PDF Generation', '12.00', 93, 0, 'Page for Letter Writing Search Page, Report, Letter Wrtting & PDF Generation', 1, NULL, '2017-03-24 07:13:00', '2017-03-24 07:13:00'),
(243, 27, 58, 'New Feature', 'Certificate Creation, Search and Report', '12.00', 103, 1, 'Pages  for Certificate Creation Search, Report, Certificate Creation', 1, '2017-04-05 14:02:18', '2017-03-24 07:13:59', '2017-04-05 14:02:18'),
(244, 27, 58, 'New Feature', 'Unpaid License Search, Report and Letter Writing', '12.00', 93, 0, 'Page  for Unpaid License Search, Report and Letter Writing', 1, NULL, '2017-03-24 07:14:30', '2017-03-24 07:14:30'),
(245, 27, 58, 'New Feature', 'UnInspected Licenses Search, Report & Letter Writing', '12.00', 93, 0, 'Pages  for UnInspected Licenses Search, Report & Letter Writing', 1, NULL, '2017-03-24 07:15:24', '2017-03-24 07:15:24'),
(246, 27, 58, 'New Feature', 'Money Collection Search and Report', '16.00', 103, 1, 'Money Collection Search and Report page', 1, '2017-04-04 06:19:30', '2017-03-24 07:16:14', '2017-04-04 06:19:30'),
(247, 27, 58, 'New Feature', 'License Summary', '8.00', 93, 0, 'License Summary  Page', 1, NULL, '2017-03-24 07:16:41', '2017-03-24 07:16:41'),
(248, 27, 58, 'New Feature', 'Integrate Print & PDF Creation in All Reports', '16.00', 93, 0, 'Integrate Print & PDF Creation in All Reports', 1, NULL, '2017-03-24 07:17:17', '2017-03-24 07:17:17'),
(249, 19, 39, 'Quality Assurance', 'Testing of aaemllc site', '0.00', 109, 1, '1.Test the site on MAC\r\n', 0, '2017-03-28 04:50:27', '2017-03-27 05:20:50', '2017-03-28 04:50:27'),
(250, 19, 40, 'Quality Assurance', 'Testing of aa-q.de site', '0.00', 0, 0, 'Test the site one MAC', 0, NULL, '2017-03-27 05:21:32', '2017-03-27 05:21:32'),
(251, 19, 40, 'Bug Fixing', 'QA issue Fixes', '2.00', 85, 0, 'QA issue Fixes', 0, NULL, '2017-03-27 05:42:45', '2017-03-27 05:42:45'),
(252, 27, 58, 'New Feature', 'Menu Updates', '4.00', 97, 0, 'These mockups seems replica of existing application. Now where close to fresh look/navigation', 1, NULL, '2017-03-27 05:45:48', '2017-03-27 05:45:48'),
(253, 15, 61, 'New Feature', 'HTML', '4.00', 97, 0, 'HTML for inner pages', 1, NULL, '2017-03-27 05:48:48', '2017-03-27 05:48:48'),
(254, 15, 62, 'New Feature', 'Newsletter For marketing', '0.00', 100, 0, 'Newsletter For marketing', 0, NULL, '2017-03-27 12:41:30', '2017-03-27 12:41:30'),
(255, 15, 62, 'New Feature', 'Data Mining', '0.00', 100, 0, 'Data Mining', 0, NULL, '2017-03-27 12:41:59', '2017-03-29 14:28:26'),
(256, 15, 62, 'New Feature', 'Website review and client follow up', '0.00', 100, 1, 'Website review and client follow up', 0, '2017-03-28 14:30:04', '2017-03-27 12:45:32', '2017-03-28 14:30:04'),
(257, 15, 62, 'New Feature', 'Staffing', '0.00', 0, 0, 'Staffing', 0, NULL, '2017-03-27 12:45:48', '2017-03-27 12:45:48'),
(258, 15, 62, 'New Feature', 'GD Session', '0.00', 100, 0, 'GD Session', 0, NULL, '2017-03-27 12:46:09', '2017-03-27 12:46:09'),
(259, 15, 62, 'New Feature', 'SEO Report', '0.00', 100, 0, 'SEO Report', 0, NULL, '2017-03-27 12:46:32', '2017-03-27 12:46:32'),
(260, 15, 62, 'New Feature', 'Documents & Jot Form', '0.00', 100, 0, 'Documents & Jot Form', 0, NULL, '2017-03-27 12:47:00', '2017-03-27 12:47:00'),
(261, 15, 62, 'New Feature', 'Marketing Events updates', '0.00', 100, 0, 'Marketing Events updates', 0, NULL, '2017-03-27 12:47:21', '2017-03-27 12:47:21'),
(262, 15, 62, 'New Feature', 'Social Media', '0.00', 100, 0, 'Social Media', 0, NULL, '2017-03-27 12:47:56', '2017-03-27 12:47:56'),
(263, 15, 62, 'New Feature', 'Blog Posting', '0.00', 100, 0, 'Blog Posting', 0, NULL, '2017-03-27 12:49:28', '2017-03-27 12:49:28'),
(264, 18, 50, 'New Feature', 'Mockup for News Alert', '4.00', 97, 0, 'Build a mock up for News Alert: https://www.dropbox.com/sh/op1vtw9k6ldpb6t/AAA0H-vn6r409N-xU3abbVRia?dl=0 ', 1, NULL, '2017-03-28 04:54:13', '2017-03-28 04:54:13'),
(265, 15, 61, 'New Feature', 'HTML, Updates and Changes', '4.00', 97, 0, 'HTML, Updates and Changes', 1, NULL, '2017-03-28 04:55:21', '2017-03-28 04:55:21'),
(266, 15, 46, 'New Feature', 'Images for Blogs', '2.00', 91, 1, 'Images for Blogs', 0, '2017-03-28 08:37:48', '2017-03-28 04:56:03', '2017-03-28 12:10:14'),
(267, 26, 52, 'New Feature', 'Updates and Changes', '4.00', 85, 0, 'Updates and Changes', 0, NULL, '2017-03-28 04:56:44', '2017-03-28 13:48:50'),
(268, 26, 52, 'New Feature', 'Responsive', '4.00', 114, 0, 'Responsive for Banner slider and accordion ', 1, NULL, '2017-03-28 05:27:59', '2017-03-28 05:27:59'),
(269, 15, 46, 'Backup Restore', 'SharePoint Disaster Recovery pdf', '0.30', 91, 1, 'SharePoint Disaster Recovery pdf is missing on Ignatiuz site', 0, '2017-03-28 09:14:26', '2017-03-28 05:39:31', '2017-03-28 12:10:04'),
(270, 18, 50, 'New Feature', 'Updates and Changes', '0.00', 97, 0, 'Make attached changes & add few more/different ways for quick launch – may be under News & Announcements', 1, NULL, '2017-03-29 05:35:45', '2017-03-29 05:35:45'),
(271, 15, 61, 'New Feature', ' Byers Station 5K', '0.00', 97, 0, 'Please fix attached, I will be sharing more pictures tonight for certain sections of the website. ', 1, NULL, '2017-03-29 05:36:58', '2017-03-29 05:36:58'),
(272, 18, 50, 'New Feature', 'Icon update', '0.00', 97, 1, 'Icon update', 1, '2017-03-29 11:18:19', '2017-03-29 05:38:34', '2017-03-29 11:18:19'),
(273, 15, 61, 'New Feature', ' byers5k ka HTML changes', '2.00', 97, 1, ' byers5k ka HTML changes', 1, '2017-03-31 17:18:14', '2017-03-30 04:49:10', '2017-03-31 17:18:14'),
(274, 27, 56, 'New Feature', 'OB food tab design', '2.00', 97, 0, 'OB food tab design\r\n', 1, NULL, '2017-03-30 04:50:49', '2017-03-30 04:50:49'),
(275, 30, 59, 'Bug Fixing', 'Bid Go Live issue', '2.00', 92, 1, 'Bid was not going live.', 0, '2017-04-05 13:59:35', '2017-03-30 05:57:16', '2017-04-05 13:59:35'),
(276, 30, 59, 'Support', 'Vendor Update', '8.00', 92, 0, 'Updated vendor ', 0, NULL, '2017-03-30 05:57:50', '2017-04-05 05:48:12'),
(277, 27, 58, 'New Feature', 'Implementation of design on pages', '6.00', 103, 1, 'Login, Manage License, Add License and reports', 1, '2017-04-04 06:19:12', '2017-03-30 09:23:01', '2017-04-04 06:19:12'),
(278, 15, 61, 'New Feature', 'ByersStation5k updates', '4.00', 97, 0, 'ByersStation5k updates', 1, NULL, '2017-03-31 04:46:18', '2017-03-31 04:46:18'),
(279, 15, 46, 'New Feature', 'Ignatiuz Website Updates', '1.00', 91, 0, 'Ignatiuz Website Updates', 0, NULL, '2017-03-31 04:47:28', '2017-03-31 04:47:28'),
(280, 19, 39, 'Bug Fixing', 'QA issue Fixes', '0.00', 85, 0, 'QA issue Fixes', 1, NULL, '2017-03-31 04:48:05', '2017-03-31 04:48:05'),
(281, 19, 40, 'Bug Fixing', 'QA issue Fixes', '0.00', 85, 0, 'QA issue Fixes', 0, NULL, '2017-03-31 04:48:23', '2017-03-31 04:48:23'),
(282, 21, 70, 'R&D', 'Consuming Web Service using JavaScript Ajax', '16.00', 116, 1, 'Tried to consume web service which is hosted on other server (Cross Domain issue)', 1, '2017-04-04 12:25:38', '2017-03-31 09:54:54', '2017-04-04 12:25:38'),
(283, 21, 70, 'New Feature', 'Create Web Service and host on Ignatiuz Server', '4.00', 87, 0, 'Create Web Service and host on Ignatiuz Server', 1, NULL, '2017-03-31 09:55:27', '2017-03-31 09:55:27'),
(284, 21, 70, 'New Feature', 'Home Page Events using Ajax and Web Service', '4.00', 87, 0, 'Home Page Events using Ajax and Web Service', 1, NULL, '2017-03-31 10:00:20', '2017-03-31 10:00:20'),
(285, 21, 70, 'New Feature', 'Add Events on Committee Pages using Ajax and Web Service', '8.00', 87, 0, 'Add Events on Committee Pages using Ajax and Web Service', 1, NULL, '2017-03-31 10:02:36', '2017-03-31 10:02:36'),
(286, 14, 27, 'New Feature', 'Testing of updates and fixed issue of Omnidirectional module.', '4.00', 73, 1, 'Testing of updates of Omnidirectional module.\r\nTesting of reported fixed issues of Omnidirectional module.\r\nPerform regression testing of App.', 0, '2017-04-10 14:09:02', '2017-04-03 05:07:27', '2017-04-10 14:09:02'),
(287, 30, 59, 'New Feature', 'UI Formatting', '0.00', 91, 0, 'UI Formatting', 1, NULL, '2017-04-03 05:30:21', '2017-04-03 05:30:21'),
(288, 27, 58, 'New Feature', 'Responsive & Formatting', '0.00', 91, 0, 'Responsive & Formatting', 1, NULL, '2017-04-03 05:31:45', '2017-04-03 05:32:12'),
(289, 15, 61, 'New Feature', 'Updates and Changes', '0.00', 97, 0, 'Updates and Changes', 0, NULL, '2017-04-03 05:47:48', '2017-04-03 05:47:48'),
(290, 15, 68, 'Bug Fixing', 'Task time to be mentioned consistently across in the same format as HH:MM', '2.00', 113, 1, 'Task time to be mentioned consistently across in the same format as HH:MM', 0, '2017-04-04 06:48:07', '2017-04-03 08:21:19', '2017-04-04 06:48:07'),
(291, 15, 68, 'Bug Fixing', 'Validation error on the task page, clears all the other fields (Client, Project and Task).', '2.00', 125, 1, 'Validation error on the task page, clears all the other fields (Client, Project and Task).', 0, '2017-04-04 16:08:53', '2017-04-03 08:28:00', '2017-04-04 16:08:53'),
(292, 15, 68, 'Bug Fixing', 'Task which needs approval should come on top in the time tracks', '2.00', 125, 1, 'Task which needs approval should come on top in the time tracks', 0, '2017-04-05 05:25:07', '2017-04-03 08:29:02', '2017-04-05 05:25:07'),
(293, 15, 68, 'Support', 'Task creation and assigning to team.', '0.30', 113, 1, 'New task creation and assigning to other.', 0, '2017-04-04 06:48:04', '2017-04-03 08:37:07', '2017-04-04 06:48:04'),
(294, 27, 72, 'New Feature', 'Create lists for Payroll Change Notice', '4.00', 90, 1, 'Create schema for lists and child lists.', 1, '2017-04-11 08:27:45', '2017-04-03 10:12:23', '2017-04-11 08:27:45'),
(295, 27, 72, 'New Feature', 'Create html/css of Payroll Changes Notice form', '4.00', 90, 0, 'Design of Payroll Changes form', 1, NULL, '2017-04-03 10:13:20', '2017-04-03 10:13:20'),
(296, 27, 72, 'New Feature', 'implement code to get list items and bind in input checkbox list ', '5.00', 90, 1, '', 1, '2017-04-07 10:26:01', '2017-04-03 10:20:30', '2017-04-07 10:26:01'),
(297, 27, 72, 'New Feature', 'Implement code to get selected items of input checkbox ', '3.00', 90, 1, 'Implement code to get selected items of input checkbox on save form details ', 1, '2017-04-10 12:48:14', '2017-04-03 10:21:35', '2017-04-10 12:48:14'),
(298, 27, 72, 'New Feature', 'Code to Insert item into list using JSOM', '4.00', 90, 0, 'Code to Insert item into list using JSOM', 1, NULL, '2017-04-03 10:22:21', '2017-04-03 10:22:21'),
(299, 27, 72, 'New Feature', 'Code to create element for people picker in html and get value of control ', '5.00', 90, 0, 'Code to create element for people picker in html and get value of control ', 1, NULL, '2017-04-03 10:23:23', '2017-04-03 12:52:20'),
(300, 19, 39, 'New Feature', 'facebook updates issue', '1.00', 85, 0, 'facebook updates issue', 1, NULL, '2017-04-03 10:36:37', '2017-04-03 10:36:37'),
(301, 19, 40, 'New Feature', 'Updates and Changes', '2.00', 85, 0, 'Updates and Changes', 1, NULL, '2017-04-03 10:37:12', '2017-04-03 10:37:12'),
(302, 26, 52, 'Bug Fixing', 'Updates and Changes', '0.00', 85, 0, 'Updates and Changes', 0, NULL, '2017-04-03 10:37:37', '2017-04-04 04:07:16'),
(303, 15, 68, 'Bug Fixing', 'Deployed bug fixing changes to staging server. ', '3.00', 113, 1, 'Below are the list of changes deployed to staging server.\r\n1. Validation error on the task page, clears all the other fields (Client, Project and Task).\r\n2. Task time to be mentioned consistently across in the same format as HH:MM\r\n4. A cancel/clear button should be there on “Add Track Log” to clear the fields.\r\n5. Task which needs approval should come on top in the time tracks.\r\n6. Task Type master form to be created which can be used to update the task types details or add new task types', 0, '2017-04-04 06:48:01', '2017-04-03 13:12:33', '2017-04-04 06:48:01'),
(304, 15, 68, 'New Feature', 'Task Type master form to be created which can be used to update the task types details or add new task types', '3.00', 113, 0, '- Task Type master form to be created which can be used to update the task types details or add new task types.\r\n- Task Type form with Add/Edit/Delete functionality.', 0, NULL, '2017-04-03 13:18:08', '2017-04-03 13:18:08'),
(305, 15, 46, 'New Feature', 'SharePoint Newsletter', '3.00', 91, 0, 'Newsletter HTML for Sharepoint', 0, NULL, '2017-04-04 04:15:18', '2017-04-04 04:15:18'),
(306, 15, 46, 'Bug Fixing', 'Ignatiuz Logo', '1.00', 91, 0, 'Ignatiuz Logo need to fix on help desk', 0, NULL, '2017-04-04 04:16:31', '2017-04-04 04:16:31'),
(307, 30, 59, 'New Feature', 'HMSDC Update', '0.30', 97, 0, 'HMSDC Update', 1, NULL, '2017-04-04 04:31:08', '2017-04-04 04:31:08'),
(308, 21, 69, 'New Feature', 'Import Data in List from Excel, Set filters, Sorting, Add on a page', '4.00', 116, 1, 'Import Data in List from Excel, Set filters, Sorting, Add on a page, Add link on home page', 1, '2017-04-04 11:18:16', '2017-04-04 05:45:12', '2017-04-04 11:18:16'),
(309, 27, 58, 'New Feature', 'Display multiple records in report viewer', '8.00', 103, 1, 'Report to show multiple license', 1, '2017-04-05 11:30:01', '2017-04-04 06:32:01', '2017-04-05 11:30:01'),
(310, 15, 68, 'New Feature', 'Create new database table on staging server with name task type with required fields.', '0.30', 113, 1, 'This table is used to populate task type on task type manage page.', 0, '2017-04-04 16:08:39', '2017-04-04 06:45:40', '2017-04-04 16:08:39'),
(311, 15, 68, 'Support', 'Task creation and assigning to team.', '0.30', 113, 1, 'New tasks creation and assigning to other.', 0, '2017-04-04 16:08:34', '2017-04-04 06:47:44', '2017-04-04 16:08:34'),
(312, 15, 68, 'Bug Fixing', 'Remove Static value and populate Task Type drop down with data from database.', '1.00', 113, 1, 'Previously Task type drop down on task page have static value in it.\r\nAccording to new functionality task type come dynamically from database. ', 0, '2017-04-04 16:08:44', '2017-04-04 06:55:21', '2017-04-04 16:08:44'),
(313, 18, 76, 'Bug Fixing', 'Increase width of Account name and Sub account name Filters', '0.30', 89, 1, 'If Account name and Sub account name length increase, it get cutoff so increase size through SP designer and verify on browsers IE/Edge/Chrome.', 1, '2017-04-04 09:08:10', '2017-04-04 08:32:45', '2017-04-04 09:08:10'),
(314, 18, 76, 'Bug Fixing', 'Review Sort order and  prepare some screens and scenarios of existing sorting order and change sorting order', '8.00', 89, 1, 'Review Sort order and  prepare some screens and scenarios of existing sorting order \r\n\r\nSet sort order by most recent of Account Name, Sub Account and so on  \r\n ', 1, '2017-04-10 13:50:59', '2017-04-04 08:35:08', '2017-04-10 13:50:59'),
(315, 18, 76, 'New Feature', 'Add filename also on summary of selected items', '6.00', 89, 0, 'Add filename also on summary of selected items, which is showing item count per page for now.', 1, NULL, '2017-04-04 09:19:23', '2017-04-04 09:19:23'),
(316, 27, 58, 'Quality Assurance', 'Testing of FBLMS', '0.00', 109, 1, 'Testing whole site of FBLMS', 0, '2017-04-05 11:36:27', '2017-04-04 09:21:15', '2017-04-05 11:36:27'),
(317, 14, 75, 'New Feature', '1.Design (WPF lay out integration) and develop bottom horizontal tile bar as per the 4K PSD shared keeping the old vertical one working.', '0.00', 88, 0, '', 0, NULL, '2017-04-04 09:30:50', '2017-04-04 09:30:50'),
(318, 14, 75, 'New Feature', '2. Have an option in CMS for switching between old myShowcase and Omnidirectional one.', '0.00', 88, 0, '', 0, NULL, '2017-04-04 09:31:19', '2017-04-04 09:31:19'),
(319, 15, 68, 'Support', 'Add task in myhub', '0.00', 109, 1, 'Add task in myhub', 0, '2017-04-06 08:12:29', '2017-04-04 09:32:23', '2017-04-06 08:12:29'),
(320, 14, 75, 'New Feature', '3. Integrate horizontal endless and definite scrolling for horizontal bottom tile bar.', '0.00', 88, 0, '', 0, NULL, '2017-04-04 09:34:20', '2017-04-04 09:34:20'),
(321, 14, 74, 'New Feature', '4. Integrate horizontal parallax effect for horizontal bottom tile bar.', '0.00', 88, 0, '', 0, NULL, '2017-04-04 09:34:39', '2017-04-04 09:34:39'),
(322, 14, 75, 'New Feature', '5. Integrate horizontal center tile selection feature for horizontal bottom tile bar.', '0.00', 88, 0, '', 0, NULL, '2017-04-04 09:35:12', '2017-04-04 09:35:12'),
(323, 14, 75, 'New Feature', '6. Implement CMS features for horizontal tile', '0.00', 88, 0, '', 0, NULL, '2017-04-04 09:55:54', '2017-04-04 09:55:54'),
(324, 14, 75, 'New Feature', '7. When tapped over any tile, a detail popup will animate towards the app area. ', '0.00', 88, 0, '', 0, NULL, '2017-04-04 09:56:48', '2017-04-04 09:56:48'),
(325, 14, 75, 'New Feature', '1. Create custom control to extend the full screen media slide show features. ', '0.00', 88, 0, '', 0, NULL, '2017-04-04 09:57:30', '2017-04-04 09:57:30'),
(326, 14, 75, 'New Feature', '2. Add business logics for the multi user interaction in the full screen media custom control.', '0.00', 88, 0, '', 0, NULL, '2017-04-04 09:58:05', '2017-04-04 09:58:05'),
(327, 14, 75, 'New Feature', '3. Animate the full screen media custom control in the app middle area when user tapped over any tile.', '0.00', 88, 0, '', 0, NULL, '2017-04-04 09:58:27', '2017-04-04 09:58:27'),
(328, 14, 75, 'New Feature', '4. Disable the video playback and remove all the detail popups from the app middle area when user go to CMS while full screen media detail popup opened in the app middle area.', '0.00', 88, 0, '', 0, NULL, '2017-04-04 09:58:45', '2017-04-04 09:58:45'),
(329, 14, 75, 'New Feature', '5. Add business logic for the lay out changes (full screen media dimensions, left and right arrow navigation button positioning etc.) in the full screen media custom control.', '0.00', 88, 0, '', 0, NULL, '2017-04-04 09:59:11', '2017-04-04 09:59:11'),
(330, 14, 75, 'New Feature', '1.  Bottom filmstrip Tile - Heading line length is not matching with PSD.', '0.00', 88, 0, '', 0, NULL, '2017-04-04 09:59:35', '2017-04-04 09:59:35'),
(331, 14, 75, 'New Feature', '2. Gallery - media title and description text is appearing large if update and save any setting     (Appearance/Settings) from CMS.', '0.00', 88, 0, '', 0, NULL, '2017-04-04 09:59:48', '2017-04-04 09:59:48'),
(332, 14, 75, 'New Feature', '3. Add new category tile image and background image. Do not added any image on gallery and click on save and launch App. then click on associate tile.', '0.00', 88, 0, '', 0, NULL, '2017-04-04 10:00:50', '2017-04-04 10:00:50'),
(333, 14, 75, 'New Feature', '4. Tile finite scrolling not working properly.', '0.00', 88, 0, '', 0, NULL, '2017-04-04 10:01:15', '2017-04-04 10:01:15'),
(334, 14, 75, 'New Feature', '5. Add new category - upload only image and keep Tile title1, title2 and description text empty and save and launch App. Default it is appearing heading line on tile image.', '0.00', 88, 0, '', 0, NULL, '2017-04-04 10:01:31', '2017-04-04 10:01:31'),
(335, 14, 75, 'New Feature', '6. Infinity scroll - bottom filmstrip Auto slider not working, slider got stuck on tile.', '0.00', 88, 0, '', 0, NULL, '2017-04-04 10:01:52', '2017-04-04 10:01:52'),
(336, 14, 75, 'New Feature', '7. CMS for switching old myShowcase - Media thumbnail image and font size is appearing too small.', '0.00', 88, 0, '', 0, NULL, '2017-04-04 10:02:16', '2017-04-04 10:02:16'),
(337, 14, 75, 'New Feature', '1. Create custom control to extend the category detail of type Subcategories and the No Subcategories features.', '0.00', 88, 0, '', 0, NULL, '2017-04-04 10:02:41', '2017-04-04 10:02:41'),
(338, 14, 75, 'New Feature', '2. Add business logics for the multi user interaction in the Categories and No Subcategories custom control.', '0.00', 88, 0, '', 0, NULL, '2017-04-04 10:02:58', '2017-04-04 10:02:58'),
(339, 14, 75, 'New Feature', '3. Animate the Categories and No Subcategories custom control in the app middle area when user tapped over any tile.', '0.00', 88, 0, '', 0, NULL, '2017-04-04 10:03:16', '2017-04-04 10:03:16'),
(340, 14, 75, 'New Feature', '4. Disable the video playback and remove all the detail popups from the app middle area when user go to CMS while Categories and No Subcategories detail popup opened in the app middle area.', '0.00', 88, 0, '', 0, NULL, '2017-04-04 10:04:08', '2017-04-04 10:04:08'),
(341, 14, 75, 'New Feature', '5. Add business logic for the lay out changes in the categories and No Subcategories custom control.', '0.00', 88, 0, '', 0, NULL, '2017-04-04 10:05:35', '2017-04-04 10:05:35'),
(342, 21, 70, 'New Feature', 'Add background color category wise on event box on home page ', '2.00', 116, 1, '', 1, '2017-04-04 13:07:56', '2017-04-04 11:19:14', '2017-04-04 13:07:56'),
(343, 15, 63, 'Backup Restore', 'ELS DB Backup Restore', '1.30', 70, 1, '', 0, '2017-04-05 09:07:31', '2017-04-04 11:29:01', '2017-04-05 09:07:31'),
(344, 27, 64, 'Support', 'Setup Food and Beverage on OB125', '1.30', 70, 1, 'Setup Food and Beverage on OB125 and DB Logs Files over OB126 (OB125 and OB126 Server Review)', 0, '2017-04-05 09:07:36', '2017-04-04 11:35:09', '2017-04-05 09:07:36'),
(345, 15, 63, 'Support', 'IP Cam Setup', '1.00', 70, 1, 'IP Cam Setup for Pune Office (BInding, http request, firewall rules)', 0, '2017-04-05 09:07:42', '2017-04-04 11:38:23', '2017-04-05 09:07:42'),
(346, 18, 34, 'Support', 'TFS Source Code Mapping, Binding ', '1.00', 70, 0, 'TFS Source Code Mapping, Binding and new code added to the Test Automation Project', 0, NULL, '2017-04-04 11:44:28', '2017-04-04 11:44:28'),
(347, 15, 68, 'R&D', 'On Track page it is only showing five records.', '0.30', 113, 1, '', 0, '2017-04-06 05:39:17', '2017-04-04 11:55:17', '2017-04-06 05:39:17'),
(348, 15, 63, 'Support', 'Helpdesk and Support System', '1.00', 70, 1, '', 0, '2017-04-05 09:07:47', '2017-04-04 12:03:24', '2017-04-05 09:07:47');
INSERT INTO `tasks` (`id`, `company_id`, `project_id`, `task_type`, `task_titly`, `alloceted_hours`, `assign_to`, `done`, `task_description`, `billable`, `date_finish`, `created_at`, `updated_at`) VALUES
(349, 15, 46, 'New Feature', 'Single Page HTML', '0.00', 97, 0, 'Single Page HTML, showcase our SharePoint products', 0, NULL, '2017-04-04 12:11:19', '2017-04-04 12:11:19'),
(350, 15, 68, 'Bug Fixing', 'On lead Task page, only those tracks should appear which are related to the Lead’s team', '4.00', 113, 1, 'Investigate how task is fetch according to different users and implement some logic to show only lead and his team member tasks on task page.', 0, '2017-04-06 05:39:25', '2017-04-04 12:33:51', '2017-04-06 05:39:25'),
(351, 15, 63, 'Backup Restore', 'Hosting Backup- Windows and Linux', '2.00', 70, 1, 'Windows and Linux Hosting Backup Including DB', 0, '2017-04-05 06:31:45', '2017-04-05 04:21:58', '2017-04-05 06:31:45'),
(352, 28, 57, 'Quality Assurance', 'Testing of Budget sheet app', '0.00', 109, 1, 'Testing of Budget sheet app:-\r\n1. Verify sheets of client excel with code generated excel', 0, '2017-04-07 13:20:45', '2017-04-05 05:27:10', '2017-04-07 13:20:45'),
(353, 15, 68, 'Support', 'Task creation and delegation.', '0.30', 113, 1, 'New task creation and assigning to others.', 0, '2017-04-05 06:17:26', '2017-04-05 05:46:14', '2017-04-05 06:17:26'),
(354, 27, 58, 'Bug Fixing', 'QA Reported Issues Fixes :- 4-4-2017', '4.00', 93, 1, 'Functional issues Reported by QA ', 0, '2017-04-05 13:56:11', '2017-04-05 06:00:38', '2017-04-05 13:56:11'),
(355, 15, 68, 'Support', 'Shared understanding of staging server with swapnil.', '1.00', 113, 1, 'How to access staging server of myhub for deployement of change to staging myhub site. ', 0, '2017-04-05 09:00:29', '2017-04-05 06:00:55', '2017-04-05 09:00:29'),
(356, 27, 58, 'Bug Fixing', 'QA Reported Issues Fixes :- 4-4-2017', '4.00', 103, 0, 'Functional issues Reported by QA ', 0, NULL, '2017-04-05 06:01:23', '2017-04-05 06:01:23'),
(357, 27, 58, 'New Feature', 'Email notification functionality integration', '6.00', 93, 0, 'Email notification functionality integration on all edit pages', 0, NULL, '2017-04-05 06:03:00', '2017-04-05 06:03:00'),
(358, 27, 58, 'Support', 'Call / Discussion / Meetings', '0.00', 93, 0, 'Client Call of Team', 0, NULL, '2017-04-05 06:05:10', '2017-04-06 04:59:38'),
(359, 30, 59, 'Support', 'Call with Client', '0.00', 93, 0, 'Client call of Team', 0, NULL, '2017-04-05 06:05:42', '2017-04-05 06:05:42'),
(360, 30, 59, 'Support', 'Call / Discussion / Meetings', '0.00', 92, 0, 'Call / Discussion / Meetings', 0, NULL, '2017-04-05 06:06:13', '2017-04-06 05:00:08'),
(361, 30, 59, 'Bug Fixing', 'Bridgewater Fixes reported by QA', '0.00', 92, 0, 'Fix reported issues ', 0, NULL, '2017-04-05 06:07:00', '2017-04-05 06:07:00'),
(362, 15, 68, 'Support', 'Understanding of staging server with mithlesh.', '1.00', 125, 1, 'How to access staging server of myhub for deployement of change to staging myhub site. ', 0, '2017-04-05 14:29:42', '2017-04-05 06:07:30', '2017-04-05 14:29:42'),
(363, 30, 59, 'Bug Fixing', 'Bridgewater Email address exachange and review', '0.00', 92, 1, '', 0, '2017-04-05 13:59:42', '2017-04-05 06:07:30', '2017-04-05 13:59:42'),
(364, 30, 59, 'New Feature', 'Bridgewater changes', '0.00', 92, 0, 'Bridgewater changes given by client', 0, NULL, '2017-04-05 06:08:09', '2017-04-05 06:08:09'),
(365, 15, 68, 'New Feature', 'If a task tracking is approved/rejected by the lead, an email should be generated to the task assignee.', '2.30', 125, 1, 'If a task tracking is approved/rejected by the lead, an email should be generated to the task assignee.', 0, '2017-04-05 11:40:37', '2017-04-05 06:09:53', '2017-04-05 11:40:37'),
(366, 15, 68, 'Bug Fixing', 'Cross check task page functionality to show task related to lead and deployed it to staging server.', '2.00', 113, 1, 'Cross check task page functionality to show task related to lead and deployed it to staging server.', 0, '2017-04-05 09:27:40', '2017-04-05 06:21:23', '2017-04-05 09:27:40'),
(367, 15, 63, 'Support', 'Indore Office IP Cam Setup', '1.30', 70, 1, 'IP Cam Setup\r\nFirewall Traffic\r\n', 0, '2017-04-05 09:09:43', '2017-04-05 08:05:38', '2017-04-05 09:09:43'),
(368, 15, 68, 'Quality Assurance', 'Testing of myHub', '0.00', 109, 1, 'Tested the Issues related to Tracking ', 0, '2017-04-05 11:36:12', '2017-04-05 09:01:11', '2017-04-05 11:36:12'),
(369, 15, 63, 'Backup Restore', 'ELS DB Backup Restore', '1.30', 70, 1, '', 0, '2017-04-05 10:44:08', '2017-04-05 09:08:35', '2017-04-05 10:44:08'),
(370, 15, 68, 'New Feature', 'If task is rejected, it should have some description associated with it.', '4.00', 125, 0, 'If task is rejected, it should have some description associated with it.', 0, NULL, '2017-04-05 09:29:35', '2017-04-05 09:29:35'),
(371, 15, 68, 'Bug Fixing', 'On lead time track page, only those tracks should appear which are related to the Lead’s team.', '3.00', 113, 1, 'On lead time track page, only those tracks should appear which are related to the Lead’s team.', 0, '2017-04-05 13:52:43', '2017-04-05 09:31:49', '2017-04-05 13:52:43'),
(372, 14, 74, 'Bug Fixing', 'Preserve Presentation Module is not working.  (Update older presentation to new presentation) from mS Installer 1.5.0 to 1.5.1.', '0.00', 117, 0, '', 0, NULL, '2017-04-05 10:29:21', '2017-04-06 05:59:10'),
(373, 14, 74, 'Bug Fixing', 'On custom keyboard  not working  on CMS Share Email Body text pane. (custom keyboard not workin on rich textbox)', '0.00', 117, 0, '', 0, NULL, '2017-04-05 10:29:45', '2017-04-06 05:59:06'),
(374, 14, 74, 'Bug Fixing', 'By default myshowcase.exe is not run as adminstrator.', '0.00', 117, 0, '', 0, NULL, '2017-04-05 10:30:04', '2017-04-06 05:59:02'),
(375, 14, 74, 'Bug Fixing', 'On Close myShowcase App. still run on task manager not able to uninstall application if application process running on task manager.', '0.00', 118, 0, '', 0, NULL, '2017-04-05 10:30:26', '2017-04-10 12:10:57'),
(376, 14, 74, 'Bug Fixing', 'Scalling - disable option by default not getting checked.', '0.00', 117, 0, '', 0, NULL, '2017-04-05 10:30:49', '2017-04-06 05:58:15'),
(377, 14, 74, 'Bug Fixing', 'Scalling feature not implement on splash screen, category,subcategory,media font text & CMS.  (update scalling 150%)', '0.00', 117, 0, '', 0, NULL, '2017-04-05 10:31:13', '2017-04-06 05:58:12'),
(378, 14, 74, 'Bug Fixing', 'Browser will not allow user to select fields easily on some of websites. (dropbox)', '0.00', 117, 0, '', 0, NULL, '2017-04-05 10:31:38', '2017-04-06 05:58:09'),
(379, 14, 74, 'Bug Fixing', 'Custom keyboard - Enter key should work as ', '0.00', 117, 0, '( issues on client HTML)Windows 10 default keyboard "Enter" key is working as "Go" on mS browser media. please impliment the same on our custom keyboard "Enter" key.', 0, NULL, '2017-04-05 10:33:05', '2017-04-06 05:58:05'),
(380, 14, 74, 'Bug Fixing', 'On play navigate of browser media then keep idle to auto close and move to other media images - share icon place got changed.', '0.00', 117, 0, '', 0, NULL, '2017-04-05 10:33:31', '2017-04-06 05:58:02'),
(381, 14, 74, 'Bug Fixing', 'On play browser navigate - it is appearing consol popup for a while on website (using flash player on page).', '0.00', 117, 0, '', 0, NULL, '2017-04-05 10:34:11', '2017-04-06 05:57:59'),
(382, 14, 74, 'Bug Fixing', 'Full screen media - remove white space before left arrow navigation button.', '0.00', 118, 0, '', 0, NULL, '2017-04-05 10:35:00', '2017-04-10 11:31:59'),
(383, 14, 74, 'Bug Fixing', 'Custom keyboard >> https://www.tiff.org/secure/loginMF.aspx  - tab key not working properly on browser media.', '0.00', 117, 0, '', 0, NULL, '2017-04-05 10:50:39', '2017-04-06 05:57:52'),
(384, 14, 74, 'Bug Fixing', 'CMS - Apply scroll settings, disable Use Infinity scroll option and save & launch app. click on last tile to switch to layer2, not able to open last selected tile. it open second last tile.', '0.00', 117, 0, '( Tile Size - Large/small), fix on tile overlay also, not able to redirect to respective tile on layer2.', 0, NULL, '2017-04-05 10:51:22', '2017-04-06 05:57:49'),
(385, 14, 74, 'Bug Fixing', 'CMS - Settings >> select ', '0.00', 117, 0, '', 0, NULL, '2017-04-05 10:51:49', '2017-04-06 05:57:46'),
(386, 14, 74, 'Quality Assurance', 'On CMS - Click on  Gallery tab, the system freezes or  take a very long time to load.', '0.00', 117, 0, '', 0, NULL, '2017-04-05 10:52:11', '2017-04-06 05:56:23'),
(387, 14, 74, 'Bug Fixing', 'CMS - unchecked on infinite scroll checkbox and select tile size ', '0.00', 118, 0, '', 0, NULL, '2017-04-05 10:52:33', '2017-04-10 11:32:48'),
(388, 14, 74, 'Bug Fixing', 'Custom keyboard not able to enter the text to input field on some websites(e.g. https://en.wikipedia.org/wiki/Main_Page)', '0.00', 117, 0, '', 0, NULL, '2017-04-05 10:52:49', '2017-04-06 05:56:15'),
(389, 14, 74, 'Bug Fixing', 'Browser Media: Edit url from textbox (on backspace it edit/delete from last word).', '0.00', 117, 0, '', 0, NULL, '2017-04-05 10:53:08', '2017-04-06 05:56:11'),
(390, 14, 74, 'Bug Fixing', ' Scaling to be turned off', '0.00', 117, 0, '', 0, NULL, '2017-04-05 10:54:31', '2017-04-06 05:56:07'),
(391, 14, 74, 'Bug Fixing', 'mS thumbnail reduced quality', '0.00', 117, 0, '', 0, NULL, '2017-04-05 10:54:52', '2017-04-06 05:56:03'),
(392, 14, 74, 'Bug Fixing', 'Background video pause and flicker', '0.00', 118, 0, '', 0, NULL, '2017-04-05 10:55:10', '2017-04-10 11:43:44'),
(393, 14, 74, 'Bug Fixing', 'Browser zoom', '0.00', 117, 0, '', 0, NULL, '2017-04-05 10:55:47', '2017-04-06 05:55:54'),
(394, 14, 74, 'Bug Fixing', 'Integrate Touch Keyboard like windows 10 for myShowcase', '0.00', 117, 0, '', 0, NULL, '2017-04-05 10:56:05', '2017-04-06 05:55:49'),
(395, 14, 74, 'Bug Fixing', 'Dropbox not working', '0.00', 117, 0, '', 0, NULL, '2017-04-05 10:56:24', '2017-04-06 05:55:44'),
(396, 14, 74, 'Bug Fixing', 'Save content by original name', '0.00', 117, 1, '', 0, '2017-04-10 13:49:55', '2017-04-05 10:56:39', '2017-04-10 13:49:55'),
(397, 14, 74, 'Bug Fixing', 'MyTouch', '0.00', 117, 0, '', 0, NULL, '2017-04-05 10:57:00', '2017-04-06 05:54:46'),
(398, 15, 63, 'R&D', 'Network Point Issue ', '1.00', 70, 1, 'Network Point was not working since 28th Mar 17 ', 0, '2017-04-05 12:45:09', '2017-04-05 11:20:30', '2017-04-05 12:45:09'),
(399, 15, 82, 'Support', 'Meeting with Team', '0.00', 109, 0, '', 0, NULL, '2017-04-05 11:42:12', '2017-04-05 11:42:12'),
(400, 15, 63, 'Support', 'Support and Helpdesk', '1.30', 70, 1, '', 0, '2017-04-05 13:08:22', '2017-04-05 11:51:33', '2017-04-05 13:08:22'),
(401, 15, 68, 'Bug Fixing', 'Task billability should be displayed correctly across the site, no matter who is logged in.', '1.00', 125, 1, 'Task billability should be displayed correctly across the site, no matter who is logged in.', 0, '2017-04-05 14:35:03', '2017-04-05 13:07:55', '2017-04-05 14:35:03'),
(402, 15, 63, 'Support', 'Jyoti Laptop Rebuild for MS License', '4.00', 70, 1, 'MS License Setup over Jyoti,s Laptop', 0, '2017-04-06 13:08:32', '2017-04-06 05:00:33', '2017-04-06 13:08:32'),
(403, 15, 63, 'Backup Restore', 'ELS DB Backup Restore', '1.00', 70, 1, 'ELS DB Backup Restore- 6th Apr 17', 0, '2017-04-06 13:08:33', '2017-04-06 05:01:20', '2017-04-06 13:08:33'),
(404, 27, 58, 'New Feature', 'Changes suggested by Client 5-4-2017', '8.00', 103, 1, 'New functional changes suggested by client based on April 5 site review', 0, '2017-04-10 14:25:13', '2017-04-06 05:03:01', '2017-04-10 14:25:13'),
(405, 30, 59, 'New Feature', 'Change request by client ', '16.00', 92, 0, '\r\n1.Admin  will be able to upload the PDF file on selection of “Awarded To” status on “Update Bid” page.\r\n2. Admin ,Vendors and Guests, they will be able to view the uploaded Bidders Summary file link in new column added in grid\r\n3.On clicking the link PDF will get opened into new tab which will display the details available in PDF file\r\n', 0, NULL, '2017-04-06 05:06:59', '2017-04-06 05:06:59'),
(406, 27, 58, 'New Feature', 'Changes suggested by Client 5-4-2017', '8.00', 93, 0, 'New functional changes suggested by client based on April 5 site review', 0, NULL, '2017-04-06 05:33:07', '2017-04-06 06:43:12'),
(407, 15, 68, 'Support', 'Task creation and delegation.', '0.30', 113, 1, 'Task creation and delegation', 0, '2017-04-06 14:21:08', '2017-04-06 05:35:00', '2017-04-06 14:21:08'),
(408, 15, 68, 'Bug Fixing', 'When cancel button is click on tracked page, all fields are not clear.', '2.00', 125, 1, 'When cancel button is click on tracked all fields are not clear.', 0, '2017-04-06 14:13:59', '2017-04-06 05:37:37', '2017-04-06 14:13:59'),
(409, 15, 68, 'Bug Fixing', 'Update Tracktime model logic for retuning all the record according to given team id.', '3.00', 113, 1, 'Update Tracktime model logic for retuning all the record according to given team id.  ', 0, '2017-04-06 14:21:13', '2017-04-06 05:44:32', '2017-04-06 14:21:13'),
(410, 15, 68, 'New Feature', 'Add functionality to find the assignee information when task is given.  ', '3.00', 125, 1, 'To implement functionality to email assignee when task is approved/rejected.\r\nWe need to find assignee detail for this.', 0, '2017-04-06 14:14:05', '2017-04-06 06:41:49', '2017-04-06 14:14:05'),
(411, 27, 58, 'Quality Assurance', 'Meeting with Team', '0.00', 109, 1, 'Discussion regarding client new change request', 0, '2017-04-06 08:12:34', '2017-04-06 08:09:36', '2017-04-06 08:12:34'),
(412, 27, 58, 'New Feature', 'Creation Change requests document ', '0.00', 109, 1, 'Document the points of client in to an excel', 0, '2017-04-06 08:12:31', '2017-04-06 08:11:05', '2017-04-06 08:12:31'),
(413, 15, 82, 'Support', 'Adding documents and working on Training portal', '0.00', 109, 1, '1.Adding PPT\r\n2.Adding Quiz question\r\n3.Enrollment of employees\r\n4.Creation of new events and Courses', 0, '2017-04-06 08:24:33', '2017-04-06 08:20:49', '2017-04-06 08:24:33'),
(414, 27, 58, 'New Feature', 'Updation of test cases ', '0.00', 109, 1, '1.Updation of test cases according to new functionality \r\n2. Test case creation of Remaining forms', 0, '2017-04-10 08:12:59', '2017-04-06 08:49:13', '2017-04-10 08:12:59'),
(415, 15, 63, 'Support', 'Clients Server Review', '2.30', 70, 1, 'OldBridge\r\nUSR\r\nmyShowcase\r\nMARS/SF', 0, '2017-04-06 13:08:34', '2017-04-06 10:43:33', '2017-04-06 13:08:34'),
(416, 15, 68, 'Bug Fixing', 'On lead track page, only those tracks should appear which are related to the Lead’s team.', '3.00', 113, 1, 'On lead track page, only those tracks should appear which are related to the Lead’s team.', 0, '2017-04-06 14:21:23', '2017-04-06 11:26:58', '2017-04-06 14:21:23'),
(417, 15, 68, 'New Feature', 'Add scroll on track page where all the tracking task is shown.', '1.30', 125, 1, 'Currently we need to scroll at end to see last task. \r\nAdd scroll on track page where all the tracking task is shown.', 0, '2017-04-06 14:14:10', '2017-04-06 12:11:35', '2017-04-06 14:14:10'),
(418, 26, 52, 'Bug Fixing', 'GDIZ site Jot Form', '3.30', 91, 0, 'GDIZ site Jot Form', 0, NULL, '2017-04-07 04:38:00', '2017-04-07 04:40:26'),
(419, 27, 58, 'Bug Fixing', 'OB Food & Beverage ', '6.30', 97, 0, 'Responsive Design', 0, NULL, '2017-04-07 04:39:44', '2017-04-07 04:40:06'),
(420, 26, 52, 'Bug Fixing', 'Updates and Changes', '7.00', 91, 0, 'Updates and Changes', 0, NULL, '2017-04-07 04:42:04', '2017-04-07 04:42:04'),
(421, 19, 39, 'Bug Fixing', 'Updates and Changes', '0.30', 91, 0, 'Updates and Changes', 0, NULL, '2017-04-07 04:42:50', '2017-04-07 04:42:50'),
(422, 26, 52, 'Bug Fixing', 'Updated  changes as per doc file', '6.30', 97, 0, 'Updated  changes as per doc file', 0, NULL, '2017-04-07 04:43:49', '2017-04-07 04:43:49'),
(423, 27, 58, 'Bug Fixing', 'Bug Fixing', '0.30', 97, 0, 'Bug Fixing', 0, NULL, '2017-04-07 04:44:33', '2017-04-07 04:44:33'),
(424, 15, 68, 'Quality Assurance', 'Testing of myHub', '0.00', 109, 1, '1. Testing myhub issues on Staging \r\nStaging server Link :- http://myhubstg.ignatiuz.com:8070/task/all', 0, '2017-04-07 13:20:43', '2017-04-07 04:53:13', '2017-04-07 13:20:43'),
(425, 30, 59, 'Support', 'Data import and Modify', '1.00', 92, 1, 'Data import and Modify', 0, '2017-04-07 06:10:55', '2017-04-07 05:15:05', '2017-04-07 06:10:55'),
(426, 15, 46, 'New Feature', 'Single Page HTML', '0.00', 97, 0, 'Single Page HTML', 0, NULL, '2017-04-07 05:25:48', '2017-04-07 05:25:48'),
(427, 15, 46, 'New Feature', 'Newsletter HTML', '0.00', 91, 0, 'Single Page HTML', 0, NULL, '2017-04-07 05:26:50', '2017-04-07 05:26:50'),
(428, 27, 58, 'Bug Fixing', 'Design support and fixed design issue', '0.00', 97, 0, 'Design support and fixed design issue', 0, NULL, '2017-04-07 05:38:14', '2017-04-07 05:38:14'),
(429, 15, 68, 'Support', 'Task creation and delegation.', '0.30', 113, 1, 'Task creation and delegation.', 0, '2017-04-07 12:22:43', '2017-04-07 05:42:11', '2017-04-07 12:22:43'),
(430, 15, 68, 'New Feature', 'Correct the Format of email which is send on approval/rejection of task. ', '3.00', 125, 1, 'Correct the Format of email which is send on approval/rejection of task. ', 0, '2017-04-07 15:12:02', '2017-04-07 05:48:49', '2017-04-07 15:12:02'),
(431, 15, 63, 'Support', 'Rebuild Testing Machine with Three OS', '6.00', 70, 1, 'Windows 7\r\nWindows 8\r\nWindows 10', 0, '2017-04-10 09:30:16', '2017-04-07 05:55:45', '2017-04-10 09:30:16'),
(432, 15, 68, 'New Feature', 'Once the task is approved, it should get removed from the time track page.', '3.00', 113, 1, 'Once the task is approved, it should get removed from the time track page.', 0, '2017-04-07 14:52:54', '2017-04-07 06:11:22', '2017-04-07 14:52:54'),
(433, 28, 83, 'Bug Fixing', 'Test Budget sheet app', '0.00', 109, 0, '1. Compare all the PDF generated with code from client PDF', 0, NULL, '2017-04-07 07:01:13', '2017-04-07 07:01:13'),
(434, 27, 84, 'New Feature', 'Updation of test cases ', '0.00', 109, 1, '1.Updation of test cases according to new functionality \r\n2. Test case creation of Remaining forms', 0, '2017-04-10 11:27:56', '2017-04-07 07:01:56', '2017-04-10 11:27:56'),
(435, 15, 68, 'Bug Fixing', 'On tracked page in edit mode, issue in bill-ability.', '1.00', 125, 1, 'On tracked page in edit mode, issue in bill-ability.', 0, '2017-04-07 15:12:33', '2017-04-07 08:18:40', '2017-04-07 15:12:33'),
(436, 32, 85, 'New Feature', 'Add extra fields to List and Form', '4.00', 90, 0, 'Client send screenshot to add some  extra fields to form and list', 1, NULL, '2017-04-07 08:43:56', '2017-04-07 08:43:56'),
(437, 27, 58, 'New Feature', 'Payment collection reports changes', '0.00', 103, 1, 'a.  Default FROM is Jan 1 of current year. Default TO date is Dec 31 of current year.\r\nb.  Add a default report; Current year, summary of each license type. Total license, inspection & late fees paid.\r\nc.  Reports need to sort on column headers\r\nd.  I input FROM date of 1/1/2017 and left TO date empty then ran report. The date selected is not used.\r\n       e.  Bottom of page shows “Total Renewal Fee Collected”. Strange title; does not reflect what I chose in top of screen.', 0, '2017-04-07 15:23:00', '2017-04-07 08:53:23', '2017-04-07 15:23:00'),
(438, 15, 68, 'Bug Fixing', 'On tracked page in edit mode, wrong task is selected for editing.', '2.00', 113, 1, 'On tracked page in edit mode, wrong task is selected for editing.', 0, '2017-04-07 14:53:02', '2017-04-07 09:04:41', '2017-04-07 14:53:02'),
(439, 26, 52, 'Bug Fixing', 'Updates and Changes', '3.00', 85, 0, 'Updates and Changes as per google doc', 0, NULL, '2017-04-07 11:58:11', '2017-04-07 11:58:11'),
(440, 26, 52, 'R&D', 'power point presentation', '1.00', 85, 0, 'power point presentation text coming in tab', 0, NULL, '2017-04-07 11:59:25', '2017-04-07 11:59:25'),
(441, 19, 39, 'New Feature', 'Updates on lmz query', '0.30', 85, 0, 'Updates on lmz query', 0, NULL, '2017-04-07 12:05:03', '2017-04-07 12:05:03'),
(442, 15, 68, 'Support', 'Deployed bug fixed and new features changes to Live server. ', '2.00', 113, 1, 'Deployed bug fixed and new features changes to Live server. ', 0, '2017-04-07 14:34:39', '2017-04-07 12:29:23', '2017-04-07 14:34:39'),
(443, 15, 68, 'Support', 'Swapnil: Deployed bug fixed and new features changes to Live server. ', '2.00', 125, 1, 'Swapnil: Deployed bug fixed and new features changes to Live server. ', 0, '2017-04-07 15:12:54', '2017-04-07 12:31:03', '2017-04-07 15:12:54'),
(447, 27, 64, 'New Feature', 'Dashboard HTML', '0.00', 97, 0, 'Dashboard HTML', 1, NULL, '2017-04-10 04:33:35', '2017-04-10 04:33:35'),
(448, 15, 63, 'Backup Restore ', 'ELS DB Backup Restore', '1.30', 70, 1, 'ELS DB Restore to NEO Server', 0, '2017-04-10 13:21:25', '2017-04-10 05:19:33', '2017-04-10 13:21:25'),
(449, 15, 63, 'Support', 'MS License Indore Office', '3.00', 70, 0, 'MS License- Testing Machine', 0, NULL, '2017-04-10 05:20:27', '2017-04-10 05:20:27'),
(450, 33, 86, 'New Feature', 'Website Redesign Mock Up', '0.00', 97, 0, 'Website Redesign Mock Up', 1, NULL, '2017-04-10 05:26:59', '2017-04-10 05:26:59'),
(451, 15, 68, 'Support', 'Task creation and delegation.', '0.30', 113, 1, 'Task creation and delegation.', 0, '2017-04-11 05:37:03', '2017-04-10 05:34:02', '2017-04-11 05:37:03'),
(452, 27, 55, 'New Feature', 'Create 1 or 2 mock up', '0.00', 91, 0, 'Create 1 or 2 mock up', 1, NULL, '2017-04-10 05:53:42', '2017-04-10 05:53:42'),
(453, 15, 68, 'New Feature', 'If task is rejected, it should have some description associated with it.', '4.00', 125, 1, 'If task is rejected, it should have some description associated with it.\r\n', 0, '2017-04-11 05:48:43', '2017-04-10 06:01:58', '2017-04-11 05:48:43'),
(454, 15, 68, 'R&D', 'Explore functionality to exports the reports as spreadsheet in laravel.', '3.00', 113, 1, 'Explore functionality to exports the reports as spreadsheet in laravel.', 0, '2017-04-11 05:37:09', '2017-04-10 06:04:08', '2017-04-11 05:37:09'),
(455, 21, 69, 'New Feature', 'Technical Issues faced by client using SharePoint online general features ', '4.00', 116, 1, 'Technical Issues faced by client using SharePoint online general features ', 1, '2017-04-10 14:11:12', '2017-04-10 07:09:43', '2017-04-10 14:11:12'),
(459, 15, 63, 'Support', 'BioMetric', '1.00', 70, 1, 'Bio Metric Machine Installation and Configuration', 0, '2017-04-10 13:21:22', '2017-04-10 09:31:24', '2017-04-10 13:21:22'),
(461, 27, 72, 'New Feature', 'OB HR - Payroll change form design', '0.00', 85, 0, 'OB HR - Payroll change form design', 1, NULL, '2017-04-10 09:43:25', '2017-04-10 09:43:25'),
(462, 17, 32, 'New Feature', 'Updates and Changes', '0.00', 91, 0, 'Updates and Changes', 1, NULL, '2017-04-10 09:48:51', '2017-04-10 12:27:31'),
(464, 15, 68, 'Bug Fixing', 'Task which is approved is not get removed from tracked page for QA Lead.', '2.00', 113, 1, 'Specifically for QA lead once the task is approved, it should get removed from tracked page tracking list.\r\n', 0, '2017-04-11 05:37:23', '2017-04-10 10:07:22', '2017-04-11 05:37:23'),
(465, 15, 88, 'R&D', 'Review license module', '8.00', 120, 0, 'Review license module ', 1, NULL, '2017-04-10 10:07:39', '2017-04-11 05:24:55'),
(466, 27, 72, 'New Feature', 'Insert data in child table', '3.00', 90, 0, 'Get ID of inserted item and passed it to child table to insert item in child list.', 1, NULL, '2017-04-10 10:25:27', '2017-04-10 10:25:27'),
(467, 27, 72, 'New Feature', 'Validations on Payroll changes notice form form.', '6.00', 90, 0, 'Required validations on Payroll changes notice form form.', 1, NULL, '2017-04-10 10:26:08', '2017-04-10 10:26:08'),
(468, 27, 72, 'New Feature', 'Payroll changes notice from designing.', '8.00', 90, 0, 'Payroll changes notice from designing.', 1, NULL, '2017-04-10 10:26:43', '2017-04-10 10:26:43'),
(469, 27, 72, 'New Feature', 'Get item from list by item ID and bind in form and implement code.', '6.00', 90, 0, 'Get item from list by item id and bind in form and implement code.', 1, NULL, '2017-04-10 10:27:32', '2017-04-10 10:27:32'),
(470, 27, 72, 'New Feature', 'Code to bind list items to dynamic controls.', '6.00', 90, 0, 'Code to bind list items to dynamic controls.', 1, NULL, '2017-04-10 10:28:08', '2017-04-10 10:28:08'),
(471, 15, 63, 'Support', 'Network Cable Issue', '0.30', 70, 0, 'NUI Team Network Cable Issue', 0, NULL, '2017-04-10 11:16:27', '2017-04-10 11:16:27'),
(472, 15, 68, 'Quality Assurance', 'Call with Client', '4.00', 109, 0, 'Call with Client', 1, NULL, '2017-04-10 11:23:26', '2017-04-10 11:23:26'),
(473, 21, 45, 'New Feature', 'Data Import', '2.30', 92, 0, 'Import data sent by client ', 1, NULL, '2017-04-10 11:55:02', '2017-04-10 11:55:02'),
(474, 21, 45, 'Bug Fixing', 'Issue fixes and changes', '8.00', 92, 0, 'Issue fixes and changes', 1, NULL, '2017-04-10 11:56:31', '2017-04-10 11:56:31'),
(475, 27, 89, 'New Feature', 'Create Department table in Database.', '0.10', 89, 1, 'Create Department table in Database.', 1, '2017-04-10 13:41:41', '2017-04-10 12:21:43', '2017-04-10 13:41:41'),
(476, 27, 89, 'New Feature', 'Design form to manage Departments', '2.00', 89, 1, 'Design form to manage Departments', 1, '2017-04-11 05:50:34', '2017-04-10 12:22:14', '2017-04-11 05:50:34'),
(477, 27, 89, 'New Feature', 'Create SPROC to Create/Update/Delete/Search/Active-In-active department', '1.30', 89, 1, 'Create SPROC to Create/Update/Delete/Search/Active-In-active department', 1, '2017-04-11 07:11:28', '2017-04-10 12:22:47', '2017-04-11 07:11:28'),
(478, 27, 89, 'New Feature', 'Functionality to assign Department to employee', '8.00', 89, 0, 'Functionality to assign Department to employee', 1, NULL, '2017-04-10 12:23:31', '2017-04-10 12:23:31'),
(479, 27, 89, 'New Feature', 'SPROC to assign Department to employee', '1.30', 89, 0, 'SPROC to assign Department to employee', 1, NULL, '2017-04-10 12:23:56', '2017-04-10 13:18:14'),
(480, 27, 89, 'New Feature', 'Functionality to assign Bid Type to Department ', '16.00', 89, 0, 'Functionality to assign Bid Type to Department ', 1, NULL, '2017-04-10 12:24:18', '2017-04-10 13:18:28'),
(481, 27, 89, 'New Feature', 'SPROC to assign Bid Type to Department ', '1.00', 89, 0, 'SPROC to assign Bid Type to Department ', 1, NULL, '2017-04-10 12:24:48', '2017-04-10 13:18:44'),
(482, 27, 89, 'New Feature', 'Functionality to provide read/write access to Users on Bid Type accordingly to department.', '16.00', 89, 0, 'Functionality to provide read/write access to Users on Bid Type accordingly to department.', 1, NULL, '2017-04-10 12:25:12', '2017-04-10 13:20:08'),
(483, 27, 89, 'New Feature', 'Apply check in existing code to verify user access.', '16.00', 89, 0, 'Apply check in existing code to verify user access.', 1, NULL, '2017-04-10 12:25:44', '2017-04-10 13:19:32'),
(484, 27, 89, 'New Feature', 'Functionality to add/update/Delete/Search/Active-Inactive department', '8.00', 89, 0, 'Functionality to add/update/Delete/Search/Active-Inactive department', 1, NULL, '2017-04-10 12:27:23', '2017-04-10 12:27:23'),
(485, 27, 87, 'R&D', 'Blog on Tax Portal', '1.00', 89, 0, '', 1, NULL, '2017-04-10 12:28:27', '2017-04-10 12:28:27'),
(486, 15, 68, 'Bug Fixing', 'Done the required changes in database to fixed  issue not showing tasks and tracks in staging and Live.', '1.00', 113, 0, 'Investigate issue face when login with QA Lead and no teams tasks and tracks is shown.\r\nDone the required changes in database to fixed issue not showing tasks and tracks in staging and Live.\r\n', 0, NULL, '2017-04-10 13:37:43', '2017-04-10 13:37:43'),
(487, 15, 46, 'New Feature', 'Newsletter to be designed', '0.00', 85, 0, 'Update text in email newsletter', 0, NULL, '2017-04-11 05:29:46', '2017-04-11 05:29:46'),
(488, 15, 46, 'R&D', 'Details - Blog and Case-Study', '0.30', 85, 0, 'Details - Blog and Case-Study', 0, NULL, '2017-04-11 05:31:16', '2017-04-11 05:31:16'),
(489, 15, 68, 'Support', 'Task creation and delegation.', '0.30', 113, 0, 'Task creation and delegation.', 0, NULL, '2017-04-11 05:40:10', '2017-04-11 05:40:10'),
(490, 15, 68, 'Bug Fixing', 'Retain all non-mandatory fields in task add page.', '4.00', 125, 0, 'When form all field is filled. After submission error occur form must retain all the filled value. Currently, the only mandatory field is retained need to update it for non-mandatory fields.', 0, NULL, '2017-04-11 05:47:27', '2017-04-11 05:47:27'),
(491, 27, 58, 'New Feature', 'Fix Design Issues ', '0.00', 97, 0, 'Fix Design Issues ', 0, NULL, '2017-04-11 05:54:00', '2017-04-11 05:54:00'),
(492, 27, 60, 'New Feature', 'Project MVC Architecture  setup with database', '8.00', 112, 0, 'Project MVC Architecture  setup with database', 1, NULL, '2017-04-11 06:35:59', '2017-04-11 06:35:59'),
(493, 27, 60, 'New Feature', 'Create responsive UI Design', '8.00', 97, 0, 'Create responsive UI Design', 1, NULL, '2017-04-11 06:48:52', '2017-04-11 06:48:52'),
(494, 27, 60, 'New Feature', 'Integration created design with project and test with different browser', '8.00', 112, 0, '', 1, NULL, '2017-04-11 06:49:29', '2017-04-11 06:49:29'),
(495, 27, 60, 'New Feature', 'Create UI for display all created layer', '8.00', 112, 0, '', 1, NULL, '2017-04-11 07:01:30', '2017-04-11 07:01:30'),
(496, 27, 60, 'New Feature', 'Code for hide and show layer comes from shapefile', '8.00', 112, 0, '', 1, NULL, '2017-04-11 07:02:02', '2017-04-11 07:02:02'),
(497, 27, 60, 'New Feature', 'Code for hide and show layer comes from GeoJSON file', '8.00', 112, 0, 'Code for hide and show layer comes from GeoJSON file', 1, NULL, '2017-04-11 07:02:31', '2017-04-11 07:02:31'),
(498, 27, 60, 'New Feature', 'Highlight block lot on map click', '8.00', 111, 0, '', 1, NULL, '2017-04-11 07:02:59', '2017-04-11 07:02:59'),
(499, 27, 60, 'New Feature', 'Bind Selected Block lot details to information Div ', '8.00', 111, 0, '', 1, NULL, '2017-04-11 07:03:36', '2017-04-11 07:03:36'),
(500, 27, 60, 'New Feature', 'Add button (search,block lot,Address and Places) and functionality ', '8.00', 111, 0, 'Add button (search,block lot,Address and Places) and functionality ', 1, NULL, '2017-04-11 07:04:04', '2017-04-11 07:04:04'),
(501, 27, 60, 'New Feature', 'Create popup and insert block lot details ', '8.00', 112, 0, 'Create popup and insert block lot details ', 1, NULL, '2017-04-11 07:04:48', '2017-04-11 07:04:48'),
(502, 27, 60, 'New Feature', 'Add Click event and Open popup', '8.00', 112, 0, 'Add Click event and Open popup', 1, NULL, '2017-04-11 07:05:17', '2017-04-11 07:05:17'),
(503, 27, 60, 'New Feature', 'Add restriction for public and logged in user', '8.00', 112, 0, 'Add restriction for public and logged in user', 1, NULL, '2017-04-11 07:05:45', '2017-04-11 07:05:45'),
(504, 27, 60, 'New Feature', 'Adding multiple shape file to the map', '8.00', 111, 0, 'Adding multiple shape file to the map', 1, NULL, '2017-04-11 07:06:20', '2017-04-11 07:06:20'),
(505, 27, 60, 'New Feature', 'Read shape File Data and show on map ', '8.00', 111, 0, 'Read shape File Data and show on map ', 1, NULL, '2017-04-11 07:06:56', '2017-04-11 07:06:56'),
(506, 27, 60, 'New Feature', 'Add Search functionality using shape file data ', '8.00', 111, 0, 'Add Search functionality using shape file data ', 1, NULL, '2017-04-11 07:07:39', '2017-04-11 07:07:39'),
(507, 15, 68, 'New Feature', 'Explore the packages of PHPExcel of PHPOffice in laravel.', '3.00', 113, 0, 'Explore the packages of PHPExcel of PHPOffice in laravel. This packages is used for creation of excel with pass data.', 0, NULL, '2017-04-11 07:16:04', '2017-04-11 07:16:04'),
(508, 27, 60, 'New Feature', 'Create Javascript custom function to read shapefile data', '8.00', 111, 0, 'Create Javascript custom function to read shapefile data', 1, NULL, '2017-04-11 08:30:50', '2017-04-11 08:30:50'),
(509, 27, 60, 'New Feature', 'Get Lat and Long from map and pass block lot/latlong to the function ', '8.00', 111, 0, 'Get Lat and Long from map and pass block lot/latlong to the function ', 1, NULL, '2017-04-11 08:31:24', '2017-04-11 08:31:24'),
(510, 27, 60, 'New Feature', 'Search block lot in shape file , Highlight and Zoom selected block lot ', '8.00', 111, 0, 'Search block lot in shape file , Highlight and Zoom selected block lot ', 1, NULL, '2017-04-11 08:32:02', '2017-04-11 08:32:02'),
(511, 27, 60, 'New Feature', 'Create Admin UI for Add Document and images ', '8.00', 111, 0, 'Create Admin UI for Add Document and images ', 1, NULL, '2017-04-11 08:32:31', '2017-04-11 08:32:31'),
(512, 27, 60, 'New Feature', 'Insert record in DB and Save file on filesystem with desired location on server', '8.00', 111, 0, 'Insert record in DB and Save file on filesystem with desired location on server', 1, NULL, '2017-04-11 08:33:00', '2017-04-11 08:33:00'),
(513, 27, 60, 'New Feature', 'Implement Edit/Delete functionality', '8.00', 111, 0, 'Implement Edit/Delete functionality', 1, NULL, '2017-04-11 08:33:25', '2017-04-11 08:33:25'),
(514, 27, 60, 'New Feature', 'Create Web service to get documents for associated Block lot ', '8.00', 111, 0, 'Create Web service to get documents for associated Block lot ', 1, NULL, '2017-04-11 08:33:54', '2017-04-11 08:33:54'),
(515, 27, 60, 'New Feature', 'Consume web service and get particular block lot details.', '8.00', 112, 0, 'Consume web service and get particular block lot details.', 1, NULL, '2017-04-11 08:34:25', '2017-04-11 08:34:25'),
(516, 27, 60, 'New Feature', 'Bind Block lot Details to Popup', '8.00', 112, 0, 'Bind Block lot Details to Popup', 1, NULL, '2017-04-11 08:34:52', '2017-04-11 08:34:52'),
(517, 27, 60, 'New Feature', 'Create custom javascript function to show details in popup ', '8.00', 112, 0, 'Create custom javascript function to show details in popup ', 1, NULL, '2017-04-11 08:35:17', '2017-04-11 08:35:17'),
(518, 27, 72, 'New Feature', 'Department Request for New Hire form design', '2.00', 116, 0, '', 1, NULL, '2017-04-11 09:11:22', '2017-04-11 09:11:22'),
(519, 15, 88, 'New Feature', 'Implement Responsive Design', '8.00', 120, 0, 'Make app responsive', 1, NULL, '2017-04-11 10:31:46', '2017-04-11 10:31:46'),
(520, 15, 68, 'New Feature', 'Adding Timestamp with name of the person after a rejection of task in a description.', '2.30', 125, 0, 'Adding Timestamp with name of the person after a rejection of task in a description. Also, show the rejection comment in the email send to an assignee.', 0, NULL, '2017-04-11 11:24:38', '2017-04-11 11:24:38'),
(521, 15, 68, 'New Feature', 'Add PHPExcel package in myhub project and use it to creation of excel reports.', '2.30', 113, 0, 'Add PHPExcel package in myhub project and use it to creation of excel reports.', 0, NULL, '2017-04-11 11:29:13', '2017-04-11 11:29:13');

-- --------------------------------------------------------

--
-- Table structure for table `task_type`
--

CREATE TABLE `task_type` (
  `id` int(10) NOT NULL,
  `task_type` varchar(255) CHARACTER SET utf8 NOT NULL,
  `description` text CHARACTER SET utf8 NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `task_type`
--

INSERT INTO `task_type` (`id`, `task_type`, `description`, `created_at`, `updated_at`) VALUES
(1, 'New Feature', 'New Feature', '2017-03-28 00:00:00', '2017-03-29 09:49:54'),
(2, 'Bug Fixing', 'Bug Fixing', '2017-03-28 00:00:00', '2017-03-28 00:00:00'),
(3, 'Quality Assurance', 'Quality Assurance', '2017-03-28 00:00:00', '2017-03-28 00:00:00'),
(4, 'Estimates Required', 'Estimates Required', '2017-03-28 00:00:00', '2017-03-28 00:00:00'),
(5, 'Support', 'Support', '2017-03-28 00:00:00', '2017-03-28 00:00:00'),
(6, 'R&D', 'R&D', '2017-03-28 00:00:00', '2017-03-28 00:00:00'),
(7, 'Backup Restore ', 'Backup Restore', '2017-03-28 00:00:00', '2017-03-28 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `id` int(11) NOT NULL,
  `teams_lead_id` int(10) NOT NULL,
  `team_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `teams_lead_id`, `team_name`) VALUES
(15, 87, 'Web Technology'),
(16, 88, 'NUI'),
(17, 0, 'Sharepoint'),
(18, 86, 'QA'),
(19, 85, 'Creative Team'),
(22, 107, 'Resource Pool'),
(26, 115, 'Biz Dev'),
(27, 70, 'Tech Support'),
(28, 121, 'HR & Administration'),
(29, 113, 'CMS'),
(30, 0, 'LiveTechnology');

-- --------------------------------------------------------

--
-- Table structure for table `time_log`
--

CREATE TABLE `time_log` (
  `id` int(16) NOT NULL,
  `project_id` int(16) NOT NULL,
  `task_id` int(16) NOT NULL,
  `track_id` int(16) NOT NULL,
  `start` datetime NOT NULL,
  `finish` datetime DEFAULT NULL,
  `total_time` int(16) DEFAULT NULL,
  `updated_at` date NOT NULL,
  `created_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `time_log`
--

INSERT INTO `time_log` (`id`, `project_id`, `task_id`, `track_id`, `start`, `finish`, `total_time`, `updated_at`, `created_at`) VALUES
(210, 52, 155, 194, '2017-03-06 05:34:01', '2017-03-06 09:47:50', 15229, '2017-03-06', '2017-03-06'),
(211, 52, 155, 194, '2017-03-06 09:47:58', '2017-03-06 10:22:38', 2080, '2017-03-06', '2017-03-06'),
(212, 52, 155, 194, '2017-03-06 11:57:51', '2017-03-06 12:53:28', 3337, '2017-03-06', '2017-03-06'),
(213, 32, 157, 195, '2017-03-06 13:02:32', '2017-03-06 13:03:15', 43, '2017-03-06', '2017-03-06'),
(214, 33, 156, 196, '2017-03-06 13:03:15', '2017-03-06 13:03:26', 11, '2017-03-06', '2017-03-06'),
(215, 32, 157, 195, '2017-03-06 13:03:26', '2017-03-06 13:04:25', 59, '2017-03-06', '2017-03-06'),
(216, 32, 157, 195, '2017-03-06 13:04:39', '2017-03-06 13:10:26', 347, '2017-03-06', '2017-03-06'),
(217, 33, 156, 196, '2017-03-06 13:10:30', '2017-03-06 13:37:34', 1624, '2017-03-06', '2017-03-06'),
(218, 52, 160, 197, '2017-03-07 05:54:42', '2017-03-07 13:21:50', 26828, '2017-03-07', '2017-03-07'),
(219, 32, 164, 198, '2017-03-08 05:09:30', '2017-03-08 05:25:44', 974, '2017-03-08', '2017-03-08'),
(220, 32, 163, 199, '2017-03-08 05:32:49', '2017-03-08 06:19:48', 2819, '2017-03-08', '2017-03-08'),
(221, 32, 163, 199, '2017-03-08 06:20:48', '2017-03-08 06:21:53', 65, '2017-03-08', '2017-03-08'),
(222, 34, 168, 200, '2017-03-08 06:50:45', '2017-03-08 06:50:55', 10, '2017-03-08', '2017-03-08'),
(223, 34, 168, 200, '2017-03-08 06:51:37', '2017-03-08 13:04:41', 22384, '2017-03-08', '2017-03-08'),
(224, 34, 162, 201, '2017-03-08 06:59:23', NULL, NULL, '2017-03-08', '2017-03-08'),
(225, 52, 160, 202, '2017-03-08 09:43:59', '2017-03-10 05:32:52', 157733, '2017-03-10', '2017-03-08'),
(226, 32, 134, 205, '2017-03-10 05:32:52', '2017-03-10 06:26:02', 3190, '2017-03-10', '2017-03-10'),
(227, 45, 177, 206, '2017-03-14 06:54:16', '2017-03-14 07:01:07', 411, '2017-03-14', '2017-03-14'),
(228, 45, 177, 206, '2017-03-14 08:10:28', '2017-03-14 14:07:11', 21403, '2017-03-14', '2017-03-14'),
(229, 50, 95, 207, '2017-03-14 08:34:35', '2017-03-14 12:31:19', 14204, '2017-03-14', '2017-03-14'),
(230, 56, 183, 208, '2017-03-14 12:32:00', '2017-03-15 05:03:47', 59507, '2017-03-15', '2017-03-14'),
(231, 33, 182, 209, '2017-03-15 05:06:12', '2017-03-15 05:27:13', 1261, '2017-03-15', '2017-03-15'),
(232, 33, 182, 209, '2017-03-15 05:43:44', '2017-03-15 05:48:52', 308, '2017-03-15', '2017-03-15'),
(233, 45, 177, 210, '2017-03-15 05:56:00', '2017-03-15 06:29:27', 2007, '2017-03-15', '2017-03-15'),
(234, 56, 183, 211, '2017-03-15 06:00:31', '2017-03-15 06:38:25', 2274, '2017-03-15', '2017-03-15'),
(235, 34, 162, 212, '2017-03-15 06:02:01', '2017-03-15 17:37:47', 41746, '2017-03-15', '2017-03-15'),
(236, 45, 177, 210, '2017-03-15 06:44:32', '2017-03-15 06:56:52', 740, '2017-03-15', '2017-03-15'),
(237, 56, 183, 211, '2017-03-15 06:46:46', '2017-03-15 07:24:27', 2261, '2017-03-15', '2017-03-15'),
(238, 56, 183, 211, '2017-03-15 07:54:42', '2017-03-15 11:20:16', 12334, '2017-03-15', '2017-03-15'),
(239, 45, 177, 210, '2017-03-15 07:54:42', '2017-03-15 13:36:33', 20511, '2017-03-15', '2017-03-15'),
(240, 56, 183, 211, '2017-03-15 11:21:21', '2017-03-15 13:04:56', 6215, '2017-03-15', '2017-03-15'),
(241, 50, 187, 214, '2017-03-16 05:03:40', '2017-03-16 07:06:27', 7367, '2017-03-16', '2017-03-16'),
(242, 56, 183, 216, '2017-03-16 07:46:49', '2017-03-16 08:50:22', 3813, '2017-03-16', '2017-03-16'),
(243, 58, 192, 218, '2017-03-16 08:52:54', '2017-03-16 09:33:18', 2424, '2017-03-16', '2017-03-16'),
(244, 27, 170, 215, '2017-03-16 09:05:20', '2017-03-16 13:37:11', 16311, '2017-03-16', '2017-03-16'),
(245, 56, 183, 216, '2017-03-16 09:11:59', '2017-03-16 10:53:52', 6113, '2017-03-16', '2017-03-16'),
(246, 34, 162, 217, '2017-03-16 09:19:26', NULL, NULL, '2017-03-16', '2017-03-16'),
(247, 58, 192, 218, '2017-03-16 09:33:53', '2017-03-16 09:58:10', 1457, '2017-03-16', '2017-03-16'),
(248, 58, 191, 219, '2017-03-16 09:58:14', '2017-03-16 12:34:18', 9364, '2017-03-16', '2017-03-16'),
(249, 56, 183, 216, '2017-03-16 10:54:04', '2017-03-16 10:58:40', 276, '2017-03-16', '2017-03-16'),
(251, 34, 162, 212, '2017-03-17 07:46:11', '2017-03-17 07:46:20', 9, '2017-03-17', '2017-03-17'),
(252, 34, 162, 212, '2017-03-17 07:46:31', '2017-03-17 07:46:33', 2, '2017-03-17', '2017-03-17'),
(253, 34, 162, 212, '2017-03-17 07:46:35', '2017-03-17 07:46:36', 1, '2017-03-17', '2017-03-17'),
(254, 34, 162, 212, '2017-03-17 07:46:41', '2017-03-17 07:50:38', 237, '2017-03-17', '2017-03-17'),
(255, 34, 44, 222, '2017-03-20 04:58:02', '2017-03-21 06:17:27', 91165, '2017-03-21', '2017-03-20'),
(256, 27, 170, 221, '2017-03-20 04:59:58', '2017-03-20 05:00:02', 4, '2017-03-20', '2017-03-20'),
(257, 27, 170, 221, '2017-03-20 05:01:34', '2017-03-20 12:32:23', 27049, '2017-03-20', '2017-03-20'),
(258, 59, 193, 224, '2017-03-20 05:03:37', '2017-03-20 08:02:11', 10714, '2017-03-20', '2017-03-20'),
(259, 50, 178, 225, '2017-03-20 05:39:48', '2017-03-20 07:23:49', 6241, '2017-03-20', '2017-03-20'),
(260, 50, 178, 225, '2017-03-20 07:41:53', '2017-03-20 11:16:05', 12852, '2017-03-20', '2017-03-20'),
(261, 27, 170, 226, '2017-03-21 05:31:32', '2017-03-21 12:50:53', 26361, '2017-03-21', '2017-03-21'),
(262, 58, 190, 227, '2017-03-21 05:50:59', '2017-03-21 06:44:43', 3224, '2017-03-21', '2017-03-21'),
(263, 34, 44, 222, '2017-03-21 06:17:55', '2017-03-22 05:49:48', 84713, '2017-03-22', '2017-03-21'),
(264, 52, 199, 228, '2017-03-21 07:37:37', '2017-03-21 08:09:03', 1886, '2017-03-21', '2017-03-21'),
(265, 52, 199, 228, '2017-03-21 08:42:05', '2017-03-21 14:54:37', 22352, '2017-03-21', '2017-03-21'),
(266, 58, 190, 227, '2017-03-21 09:32:26', '2017-03-21 13:12:21', 13195, '2017-03-21', '2017-03-21'),
(267, 32, 169, 229, '2017-03-21 12:51:02', '2017-03-21 14:27:43', 5801, '2017-03-21', '2017-03-21'),
(269, 34, 44, 230, '2017-03-22 05:50:30', NULL, NULL, '2017-03-22', '2017-03-22'),
(271, 56, 202, 232, '2017-03-22 06:43:24', '2017-03-22 07:36:22', 3178, '2017-03-22', '2017-03-22'),
(272, 27, 170, 233, '2017-03-22 07:10:03', '2017-03-22 17:29:06', 37143, '2017-03-22', '2017-03-22'),
(273, 56, 202, 232, '2017-03-22 07:36:35', '2017-03-22 07:36:58', 23, '2017-03-22', '2017-03-22'),
(274, 56, 202, 232, '2017-03-22 07:54:52', '2017-03-22 09:59:35', 7483, '2017-03-22', '2017-03-22'),
(275, 58, 190, 227, '2017-03-22 08:35:21', '2017-03-22 08:38:41', 200, '2017-03-22', '2017-03-22'),
(276, 58, 190, 227, '2017-03-22 08:39:05', '2017-03-22 08:39:15', 10, '2017-03-22', '2017-03-22'),
(277, 58, 190, 227, '2017-03-22 08:44:49', NULL, NULL, '2017-03-22', '2017-03-22'),
(278, 33, 194, 234, '2017-03-22 11:54:03', '2017-03-22 13:02:25', 4102, '2017-03-22', '2017-03-22'),
(279, 46, 145, 235, '2017-03-22 13:06:29', '2017-03-22 13:06:38', 9, '2017-03-22', '2017-03-22'),
(281, 46, 145, 235, '2017-03-22 13:07:50', '2017-03-22 13:14:00', 370, '2017-03-22', '2017-03-22'),
(282, 52, 154, 236, '2017-03-22 13:14:00', '2017-03-22 13:18:32', 272, '2017-03-22', '2017-03-22'),
(283, 46, 145, 235, '2017-03-22 13:18:32', '2017-03-22 13:18:39', 7, '2017-03-22', '2017-03-22'),
(284, 52, 154, 236, '2017-03-22 13:18:39', '2017-03-22 14:57:36', 5937, '2017-03-22', '2017-03-22'),
(285, 46, 145, 235, '2017-03-22 14:57:41', '2017-03-22 14:57:49', 8, '2017-03-22', '2017-03-22'),
(286, 27, 170, 233, '2017-03-22 16:00:25', '2017-03-22 16:00:31', 6, '2017-03-22', '2017-03-22'),
(287, 27, 170, 237, '2017-03-23 05:02:14', '2017-03-23 10:09:32', 18438, '2017-03-23', '2017-03-23'),
(288, 55, 215, 238, '2017-03-23 05:20:13', '2017-03-23 06:12:22', 3129, '2017-03-23', '2017-03-23'),
(290, 55, 215, 238, '2017-03-23 06:12:43', '2017-03-23 06:24:41', 718, '2017-03-23', '2017-03-23'),
(291, 33, 214, 240, '2017-03-23 12:36:31', '2017-03-23 13:12:43', 2172, '2017-03-23', '2017-03-23'),
(292, 46, 222, 241, '2017-03-24 05:03:39', '2017-03-24 06:30:05', 5186, '2017-03-24', '2017-03-24'),
(293, 58, 226, 242, '2017-03-24 06:37:15', '2017-03-24 11:04:54', 16059, '2017-03-24', '2017-03-24'),
(294, 61, 223, 243, '2017-03-24 07:14:27', '2017-03-24 07:51:56', 2249, '2017-03-24', '2017-03-24'),
(295, 61, 223, 243, '2017-03-24 09:21:22', '2017-03-24 13:44:04', 15762, '2017-03-24', '2017-03-24'),
(296, 39, 249, 244, '2017-03-27 05:22:12', '2017-03-27 08:38:23', 11771, '2017-03-27', '2017-03-27'),
(297, 46, 145, 235, '2017-03-27 05:47:30', '2017-03-27 06:47:22', 3592, '2017-03-27', '2017-03-27'),
(298, 56, 183, 245, '2017-03-27 07:07:01', '2017-03-27 08:51:12', 6251, '2017-03-27', '2017-03-27'),
(299, 39, 249, 244, '2017-03-27 08:41:37', '2017-03-27 09:49:43', 4086, '2017-03-27', '2017-03-27'),
(300, 61, 223, 246, '2017-03-27 09:26:57', '2017-03-27 14:27:17', 18020, '2017-03-27', '2017-03-27'),
(301, 58, 226, 242, '2017-03-27 09:49:51', '2017-03-27 10:09:42', 1191, '2017-03-27', '2017-03-27'),
(302, 58, 226, 242, '2017-03-27 11:13:46', '2017-03-27 12:24:22', 4236, '2017-03-27', '2017-03-27'),
(303, 58, 226, 242, '2017-03-27 12:55:11', '2017-03-27 12:57:30', 139, '2017-03-27', '2017-03-27'),
(304, 39, 249, 244, '2017-03-27 12:57:40', '2017-03-27 13:11:53', 853, '2017-03-27', '2017-03-27'),
(305, 61, 223, 248, '2017-03-28 04:49:58', '2017-03-28 09:19:34', 16176, '2017-03-28', '2017-03-28'),
(306, 46, 269, 250, '2017-03-28 05:44:05', '2017-03-28 06:02:23', 1098, '2017-03-28', '2017-03-28'),
(307, 46, 266, 251, '2017-03-28 06:38:19', '2017-03-28 07:04:53', 1594, '2017-03-28', '2017-03-28'),
(308, 46, 149, 252, '2017-03-28 08:38:42', '2017-03-28 09:13:26', 2084, '2017-03-28', '2017-03-28'),
(310, 57, 207, 253, '2017-03-28 09:31:03', '2017-04-03 10:28:23', 521840, '2017-04-03', '2017-03-28'),
(311, 46, 145, 254, '2017-03-28 09:57:01', '2017-03-28 12:31:57', 9296, '2017-03-28', '2017-03-28'),
(312, 33, 129, 255, '2017-03-28 12:32:05', '2017-03-28 13:11:08', 2343, '2017-03-28', '2017-03-28'),
(313, 46, 200, 256, '2017-03-28 14:15:41', '2017-03-28 14:15:42', 1, '2017-03-28', '2017-03-28'),
(314, 46, 200, 256, '2017-03-28 14:15:46', '2017-04-07 12:10:52', 856506, '2017-04-07', '2017-03-28'),
(315, 61, 265, 260, '2017-03-29 05:34:08', '2017-03-29 05:39:39', 331, '2017-03-29', '2017-03-29'),
(316, 50, 272, 262, '2017-03-29 05:41:17', '2017-03-29 06:30:36', 2959, '2017-03-29', '2017-03-29'),
(317, 58, 226, 261, '2017-03-29 05:41:33', '2017-03-29 05:47:58', 385, '2017-03-29', '2017-03-29'),
(318, 58, 226, 261, '2017-03-29 05:42:02', '2017-03-29 05:50:57', 535, '2017-03-29', '2017-03-29'),
(320, 58, 226, 261, '2017-03-29 05:51:08', NULL, NULL, '2017-03-29', '2017-03-29'),
(321, 61, 265, 260, '2017-03-29 06:30:49', '2017-03-29 07:31:07', 3618, '2017-03-29', '2017-03-29'),
(322, 56, 202, 264, '2017-03-29 08:02:39', '2017-03-29 10:03:02', 7223, '2017-03-29', '2017-03-29'),
(323, 58, 226, 261, '2017-03-29 08:45:31', '2017-03-29 14:32:27', 20816, '2017-03-29', '2017-03-29'),
(324, 50, 107, 265, '2017-03-29 10:20:16', '2017-03-29 11:17:53', 3457, '2017-03-29', '2017-03-29'),
(325, 61, 265, 271, '2017-03-30 04:42:16', '2017-03-30 09:46:32', 18256, '2017-03-30', '2017-03-30'),
(327, 58, 246, 275, '2017-03-30 05:28:15', '2017-03-30 05:30:07', 112, '2017-03-30', '2017-03-30'),
(328, 59, 193, 276, '2017-03-30 08:30:48', '2017-03-30 11:32:28', 10900, '2017-03-30', '2017-03-30'),
(329, 58, 277, 277, '2017-03-30 09:24:47', '2017-03-30 11:13:54', 6547, '2017-03-30', '2017-03-30'),
(330, 61, 265, 271, '2017-03-30 10:37:43', '2017-03-30 12:26:58', 6555, '2017-03-30', '2017-03-30'),
(331, 59, 193, 276, '2017-03-30 11:32:59', '2017-03-30 11:33:31', 32, '2017-03-30', '2017-03-30'),
(332, 58, 277, 277, '2017-03-30 11:38:12', '2017-03-30 12:16:50', 2318, '2017-03-30', '2017-03-30'),
(333, 58, 277, 277, '2017-03-30 12:17:07', '2017-03-30 15:22:40', 11133, '2017-03-30', '2017-03-30'),
(334, 32, 134, 278, '2017-03-30 12:27:34', '2017-03-30 13:20:01', 3147, '2017-03-30', '2017-03-30'),
(335, 59, 193, 276, '2017-03-30 12:29:54', '2017-03-30 15:51:21', 12087, '2017-03-30', '2017-03-30'),
(336, 33, 194, 279, '2017-03-30 13:21:30', '2017-03-30 13:52:34', 1864, '2017-03-30', '2017-03-30'),
(337, 61, 273, 280, '2017-03-31 05:50:23', '2017-03-31 09:30:20', 13197, '2017-03-31', '2017-03-31'),
(338, 58, 246, 275, '2017-03-31 06:11:38', '2017-03-31 11:21:55', 18617, '2017-03-31', '2017-03-31'),
(339, 56, 274, 281, '2017-03-31 09:30:45', '2017-03-31 11:50:11', 8366, '2017-03-31', '2017-03-31'),
(340, 61, 273, 280, '2017-03-31 11:50:24', '2017-03-31 17:18:01', 19657, '2017-03-31', '2017-03-31'),
(341, 58, 246, 275, '2017-03-31 11:55:14', '2017-03-31 12:28:25', 1991, '2017-03-31', '2017-03-31'),
(342, 58, 277, 277, '2017-03-31 13:11:58', '2017-03-31 14:26:51', 4493, '2017-03-31', '2017-03-31'),
(344, 61, 278, 286, '2017-04-03 04:14:35', '2017-04-03 07:44:40', 12605, '2017-04-03', '2017-04-03'),
(345, 27, 170, 287, '2017-04-03 05:10:54', '2017-04-03 09:15:23', 14669, '2017-04-03', '2017-04-03'),
(346, 68, 291, 289, '2017-04-03 08:35:03', '2017-04-03 10:36:21', 7278, '2017-04-03', '2017-04-03'),
(347, 68, 293, 291, '2017-04-03 08:38:29', '2017-04-03 09:10:27', 1918, '2017-04-03', '2017-04-03'),
(348, 27, 286, 292, '2017-04-03 09:10:34', '2017-04-03 14:51:16', 20442, '2017-04-03', '2017-04-03'),
(349, 68, 290, 288, '2017-04-03 09:10:34', '2017-04-03 10:25:36', 4502, '2017-04-03', '2017-04-03'),
(350, 27, 286, 292, '2017-04-03 09:15:36', '2017-04-03 12:31:05', 11729, '2017-04-03', '2017-04-03'),
(352, 57, 217, 294, '2017-04-03 10:28:23', '2017-04-03 14:22:19', 14036, '2017-04-03', '2017-04-03'),
(353, 68, 292, 290, '2017-04-03 10:39:43', NULL, NULL, '2017-04-03', '2017-04-03'),
(354, 68, 290, 288, '2017-04-03 10:40:26', '2017-04-03 11:29:18', 2932, '2017-04-03', '2017-04-03'),
(355, 68, 303, 295, '2017-04-03 13:18:55', '2017-04-03 16:06:42', 10067, '2017-04-03', '2017-04-03'),
(356, 27, 286, 292, '2017-04-03 13:20:43', '2017-04-03 13:40:42', 1199, '2017-04-03', '2017-04-03'),
(357, 32, 175, 300, '2017-04-04 04:47:35', '2017-04-04 05:01:47', 852, '2017-04-04', '2017-04-04'),
(358, 57, 213, 301, '2017-04-04 04:57:54', '2017-04-04 11:26:12', 23298, '2017-04-04', '2017-04-04'),
(359, 61, 289, 302, '2017-04-04 05:03:23', NULL, NULL, '2017-04-04', '2017-04-04'),
(360, 61, 289, 302, '2017-04-04 06:10:28', '2017-04-04 06:52:53', 2545, '2017-04-04', '2017-04-04'),
(361, 58, 277, 277, '2017-04-04 06:18:17', '2017-04-04 06:18:21', 4, '2017-04-04', '2017-04-04'),
(362, 69, 308, 304, '2017-04-04 06:27:43', '2017-04-04 06:32:34', 291, '2017-04-04', '2017-04-04'),
(363, 58, 309, 305, '2017-04-04 06:34:31', '2017-04-04 06:55:36', 1265, '2017-04-04', '2017-04-04'),
(364, 69, 308, 304, '2017-04-04 06:35:05', '2017-04-04 06:53:27', 1102, '2017-04-04', '2017-04-04'),
(365, 68, 311, 306, '2017-04-04 06:51:18', '2017-04-04 07:21:58', 1840, '2017-04-04', '2017-04-04'),
(366, 56, 274, 308, '2017-04-04 07:01:38', '2017-04-04 08:16:32', 4494, '2017-04-04', '2017-04-04'),
(367, 58, 309, 305, '2017-04-04 07:19:45', '2017-04-04 11:16:07', 14182, '2017-04-04', '2017-04-04'),
(368, 68, 312, 309, '2017-04-04 07:22:07', '2017-04-04 08:22:23', 3616, '2017-04-04', '2017-04-04'),
(369, 69, 308, 304, '2017-04-04 07:57:06', '2017-04-04 09:08:50', 4304, '2017-04-04', '2017-04-04'),
(370, 68, 310, 307, '2017-04-04 08:22:30', '2017-04-04 08:53:29', 1859, '2017-04-04', '2017-04-04'),
(371, 76, 313, 310, '2017-04-04 08:41:36', '2017-04-04 08:42:28', 52, '2017-04-04', '2017-04-04'),
(372, 76, 313, 310, '2017-04-04 08:44:17', '2017-04-04 09:03:49', 1172, '2017-04-04', '2017-04-04'),
(373, 68, 291, 311, '2017-04-04 08:54:28', '2017-04-04 10:38:51', 6263, '2017-04-04', '2017-04-04'),
(374, 76, 313, 310, '2017-04-04 09:04:07', '2017-04-04 09:08:06', 239, '2017-04-04', '2017-04-04'),
(375, 58, 316, 314, '2017-04-04 09:23:10', '2017-04-04 09:31:41', 511, '2017-04-04', '2017-04-04'),
(376, 69, 308, 304, '2017-04-04 09:29:22', '2017-04-04 09:34:46', 324, '2017-04-04', '2017-04-04'),
(377, 76, 315, 312, '2017-04-04 09:30:42', '2017-04-04 09:43:03', 741, '2017-04-04', '2017-04-04'),
(378, 68, 319, 315, '2017-04-04 09:33:43', '2017-04-04 10:07:08', 2005, '2017-04-04', '2017-04-04'),
(379, 69, 308, 304, '2017-04-04 09:34:49', '2017-04-04 11:15:10', 6021, '2017-04-04', '2017-04-04'),
(380, 76, 315, 312, '2017-04-04 09:53:47', '2017-04-04 10:05:02', 675, '2017-04-04', '2017-04-04'),
(381, 58, 316, 314, '2017-04-04 10:07:21', '2017-04-04 11:23:01', 4540, '2017-04-04', '2017-04-04'),
(382, 70, 342, 317, '2017-04-04 11:26:59', '2017-04-04 13:07:44', 6045, '2017-04-04', '2017-04-04'),
(384, 68, 291, 311, '2017-04-04 11:33:52', '2017-04-04 11:53:09', 1157, '2017-04-04', '2017-04-04'),
(385, 64, 344, 319, '2017-04-04 11:36:10', '2017-04-04 11:36:16', 6, '2017-04-04', '2017-04-04'),
(386, 63, 343, 318, '2017-04-04 11:36:16', '2017-04-05 04:22:39', 60383, '2017-04-05', '2017-04-04'),
(387, 57, 213, 301, '2017-04-04 11:39:15', '2017-04-04 13:20:47', 6092, '2017-04-04', '2017-04-04'),
(388, 75, 333, 321, '2017-04-04 11:41:31', '2017-04-04 14:14:37', 9186, '2017-04-04', '2017-04-04'),
(389, 68, 347, 322, '2017-04-04 11:55:57', '2017-04-04 12:26:10', 1813, '2017-04-04', '2017-04-04'),
(390, 46, 349, 323, '2017-04-04 12:14:00', '2017-04-04 12:56:12', 2532, '2017-04-04', '2017-04-04'),
(391, 58, 309, 305, '2017-04-04 12:15:43', '2017-04-04 13:52:46', 5823, '2017-04-04', '2017-04-04'),
(392, 68, 350, 325, '2017-04-04 12:34:27', '2017-04-04 13:01:27', 1620, '2017-04-04', '2017-04-04'),
(393, 68, 350, 325, '2017-04-04 13:24:00', '2017-04-04 13:24:42', 42, '2017-04-04', '2017-04-04'),
(394, 68, 350, 325, '2017-04-04 13:25:46', '2017-04-04 16:07:52', 9726, '2017-04-04', '2017-04-04'),
(395, 58, 309, 305, '2017-04-04 14:19:03', '2017-04-04 15:01:46', 2563, '2017-04-04', '2017-04-04'),
(396, 32, 163, 329, '2017-04-05 04:07:35', '2017-04-05 04:58:22', 3047, '2017-04-05', '2017-04-05'),
(397, 32, 163, 329, '2017-04-05 04:07:36', NULL, NULL, '2017-04-05', '2017-04-05'),
(398, 63, 351, 330, '2017-04-05 04:23:07', '2017-04-05 06:30:46', 7659, '2017-04-05', '2017-04-05'),
(399, 57, 352, 331, '2017-04-05 05:29:13', '2017-04-05 06:03:30', 2057, '2017-04-05', '2017-04-05'),
(400, 68, 353, 332, '2017-04-05 05:46:48', '2017-04-05 06:17:01', 1813, '2017-04-05', '2017-04-05'),
(401, 34, 44, 303, '2017-04-05 06:02:31', '2017-04-05 13:25:00', 26549, '2017-04-05', '2017-04-05'),
(402, 68, 319, 333, '2017-04-05 06:04:07', '2017-04-05 06:09:18', 311, '2017-04-05', '2017-04-05'),
(403, 58, 354, 334, '2017-04-05 06:04:44', '2017-04-05 10:07:27', 14563, '2017-04-05', '2017-04-05'),
(404, 68, 319, 333, '2017-04-05 06:09:27', '2017-04-05 06:24:53', 926, '2017-04-05', '2017-04-05'),
(405, 59, 363, 336, '2017-04-05 06:09:44', '2017-04-05 08:27:55', 8291, '2017-04-05', '2017-04-05'),
(406, 68, 365, 337, '2017-04-05 06:16:29', '2017-04-05 09:20:57', 11068, '2017-04-05', '2017-04-05'),
(407, 68, 355, 335, '2017-04-05 06:17:44', '2017-04-05 07:04:53', 2829, '2017-04-05', '2017-04-05'),
(408, 57, 352, 331, '2017-04-05 06:24:57', '2017-04-05 06:25:02', 5, '2017-04-05', '2017-04-05'),
(409, 57, 352, 331, '2017-04-05 06:25:13', '2017-04-05 08:32:19', 7626, '2017-04-05', '2017-04-05'),
(410, 63, 343, 318, '2017-04-05 06:31:12', '2017-04-05 06:31:25', 13, '2017-04-05', '2017-04-05'),
(411, 68, 366, 338, '2017-04-05 07:05:00', '2017-04-05 08:45:03', 6003, '2017-04-05', '2017-04-05'),
(412, 63, 367, 339, '2017-04-05 08:08:30', '2017-04-05 09:09:35', 3665, '2017-04-05', '2017-04-05'),
(413, 58, 309, 305, '2017-04-05 08:09:59', '2017-04-05 09:45:48', 5749, '2017-04-05', '2017-04-05'),
(414, 59, 363, 336, '2017-04-05 08:28:02', '2017-04-05 08:28:28', 26, '2017-04-05', '2017-04-05'),
(415, 68, 355, 335, '2017-04-05 08:45:11', '2017-04-05 09:00:17', 906, '2017-04-05', '2017-04-05'),
(416, 68, 366, 338, '2017-04-05 09:00:45', '2017-04-05 09:27:14', 1589, '2017-04-05', '2017-04-05'),
(417, 68, 368, 340, '2017-04-05 09:01:45', '2017-04-05 10:24:29', 4964, '2017-04-05', '2017-04-05'),
(418, 63, 369, 341, '2017-04-05 09:10:13', '2017-04-05 10:44:03', 5630, '2017-04-05', '2017-04-05'),
(419, 68, 365, 342, '2017-04-05 09:22:48', '2017-04-05 11:40:25', 8257, '2017-04-05', '2017-04-05'),
(420, 68, 371, 344, '2017-04-05 09:34:02', '2017-04-05 12:52:16', 11894, '2017-04-05', '2017-04-05'),
(421, 58, 309, 305, '2017-04-05 09:46:49', '2017-04-05 11:29:59', 6190, '2017-04-05', '2017-04-05'),
(422, 72, 296, 346, '2017-04-05 09:48:58', '2017-04-05 14:17:16', 16098, '2017-04-05', '2017-04-05'),
(423, 59, 275, 347, '2017-04-05 09:54:46', '2017-04-05 13:59:19', 14673, '2017-04-05', '2017-04-05'),
(424, 58, 357, 348, '2017-04-05 10:12:20', '2017-04-05 11:23:15', 4255, '2017-04-05', '2017-04-05'),
(425, 68, 319, 349, '2017-04-05 10:25:56', '2017-04-05 10:57:37', 1901, '2017-04-05', '2017-04-05'),
(426, 57, 352, 331, '2017-04-05 10:59:10', '2017-04-05 11:36:01', 2211, '2017-04-05', '2017-04-05'),
(427, 63, 398, 350, '2017-04-05 11:21:18', '2017-04-05 12:44:48', 5010, '2017-04-05', '2017-04-05'),
(428, 68, 370, 345, '2017-04-05 11:40:45', '2017-04-05 12:50:52', 4207, '2017-04-05', '2017-04-05'),
(430, 58, 243, 352, '2017-04-05 11:45:35', '2017-04-05 14:02:09', 8194, '2017-04-05', '2017-04-05'),
(431, 58, 357, 348, '2017-04-05 12:31:21', '2017-04-05 13:56:09', 5088, '2017-04-05', '2017-04-05'),
(432, 63, 400, 353, '2017-04-05 12:45:02', '2017-04-05 13:08:14', 1392, '2017-04-05', '2017-04-05'),
(433, 68, 371, 344, '2017-04-05 12:53:05', '2017-04-05 13:42:11', 2946, '2017-04-05', '2017-04-05'),
(434, 68, 401, 354, '2017-04-05 13:09:27', '2017-04-05 13:11:01', 94, '2017-04-05', '2017-04-05'),
(435, 68, 362, 343, '2017-04-05 13:11:06', '2017-04-05 14:29:34', 4708, '2017-04-05', '2017-04-05'),
(436, 57, 352, 331, '2017-04-05 13:17:50', '2017-04-05 13:27:29', 579, '2017-04-05', '2017-04-05'),
(437, 56, 202, 355, '2017-04-06 04:48:03', '2017-04-06 05:39:03', 3060, '2017-04-06', '2017-04-06'),
(438, 63, 402, 356, '2017-04-06 05:01:49', '2017-04-06 09:36:45', 16496, '2017-04-06', '2017-04-06'),
(439, 59, 405, 357, '2017-04-06 05:07:47', '2017-04-06 12:29:05', 26478, '2017-04-06', '2017-04-06'),
(440, 68, 407, 360, '2017-04-06 05:39:51', '2017-04-06 06:31:03', 3072, '2017-04-06', '2017-04-06'),
(441, 68, 408, 361, '2017-04-06 05:41:46', '2017-04-06 06:44:26', 3760, '2017-04-06', '2017-04-06'),
(442, 68, 409, 363, '2017-04-06 06:31:27', '2017-04-06 09:51:34', 12007, '2017-04-06', '2017-04-06'),
(443, 58, 404, 359, '2017-04-06 06:39:17', '2017-04-06 08:07:01', 5264, '2017-04-06', '2017-04-06'),
(444, 68, 408, 364, '2017-04-06 06:47:53', '2017-04-06 08:06:07', 4694, '2017-04-06', '2017-04-06'),
(446, 68, 410, 365, '2017-04-06 08:06:17', '2017-04-06 10:42:00', 9343, '2017-04-06', '2017-04-06'),
(447, 58, 414, 370, '2017-04-06 08:51:01', '2017-04-06 11:43:04', 10323, '2017-04-06', '2017-04-06'),
(448, 58, 404, 359, '2017-04-06 09:37:06', '2017-04-06 14:09:30', 16344, '2017-04-06', '2017-04-06'),
(449, 63, 403, 372, '2017-04-06 09:37:22', '2017-04-06 10:40:34', 3792, '2017-04-06', '2017-04-06'),
(450, 68, 409, 363, '2017-04-06 10:11:46', '2017-04-06 11:23:16', 4290, '2017-04-06', '2017-04-06'),
(451, 63, 415, 374, '2017-04-06 11:05:37', '2017-04-06 13:08:10', 7353, '2017-04-06', '2017-04-06'),
(452, 56, 202, 375, '2017-04-06 11:16:27', '2017-04-07 04:54:27', 63480, '2017-04-07', '2017-04-06'),
(453, 68, 410, 365, '2017-04-06 11:16:42', '2017-04-06 11:50:16', 2014, '2017-04-06', '2017-04-06'),
(454, 68, 416, 376, '2017-04-06 11:28:22', '2017-04-06 14:20:56', 10354, '2017-04-06', '2017-04-06'),
(455, 68, 417, 377, '2017-04-06 12:13:33', '2017-04-06 13:21:29', 4076, '2017-04-06', '2017-04-06'),
(456, 59, 405, 357, '2017-04-06 12:34:21', '2017-04-06 13:11:23', 2222, '2017-04-06', '2017-04-06'),
(457, 59, 405, 357, '2017-04-07 04:41:20', '2017-04-07 05:10:33', 1753, '2017-04-07', '2017-04-07'),
(458, 68, 424, 380, '2017-04-07 04:54:03', '2017-04-07 05:11:27', 1044, '2017-04-07', '2017-04-07'),
(459, 56, 202, 381, '2017-04-07 04:56:13', '2017-04-07 06:27:53', 5500, '2017-04-07', '2017-04-07'),
(460, 58, 404, 359, '2017-04-07 05:14:41', '2017-04-07 08:46:47', 12726, '2017-04-07', '2017-04-07'),
(461, 68, 424, 380, '2017-04-07 05:15:25', '2017-04-07 06:54:53', 5968, '2017-04-07', '2017-04-07'),
(462, 59, 425, 382, '2017-04-07 05:17:29', '2017-04-07 06:10:52', 3203, '2017-04-07', '2017-04-07'),
(463, 58, 406, 383, '2017-04-07 05:18:57', '2017-04-07 13:41:32', 30155, '2017-04-07', '2017-04-07'),
(464, 34, 44, 384, '2017-04-07 05:41:17', '2017-04-07 13:27:27', 27970, '2017-04-07', '2017-04-07'),
(465, 68, 429, 386, '2017-04-07 05:46:15', '2017-04-07 06:21:43', 2128, '2017-04-07', '2017-04-07'),
(466, 63, 431, 387, '2017-04-07 05:56:13', '2017-04-07 08:44:19', 10086, '2017-04-07', '2017-04-07'),
(467, 68, 430, 388, '2017-04-07 06:01:06', '2017-04-07 08:40:58', 9592, '2017-04-07', '2017-04-07'),
(468, 59, 405, 357, '2017-04-07 06:17:31', '2017-04-10 06:11:28', 258837, '2017-04-10', '2017-04-07'),
(469, 68, 432, 389, '2017-04-07 06:21:51', '2017-04-07 09:03:05', 9674, '2017-04-07', '2017-04-07'),
(470, 46, 426, 390, '2017-04-07 06:28:39', '2017-04-07 12:50:09', 22890, '2017-04-07', '2017-04-07'),
(471, 57, 352, 391, '2017-04-07 08:09:51', '2017-04-07 11:36:01', 12370, '2017-04-07', '2017-04-07'),
(472, 68, 430, 388, '2017-04-07 08:41:06', '2017-04-07 08:41:17', 11, '2017-04-07', '2017-04-07'),
(473, 68, 435, 392, '2017-04-07 08:41:24', '2017-04-07 09:36:05', 3281, '2017-04-07', '2017-04-07'),
(474, 85, 436, 393, '2017-04-07 08:45:35', '2017-04-07 10:25:55', 6020, '2017-04-07', '2017-04-07'),
(475, 58, 437, 395, '2017-04-07 08:54:56', '2017-04-07 15:22:54', 23278, '2017-04-07', '2017-04-07'),
(476, 68, 438, 396, '2017-04-07 09:05:11', '2017-04-07 10:40:19', 5708, '2017-04-07', '2017-04-07'),
(477, 68, 435, 392, '2017-04-07 10:05:16', '2017-04-07 10:11:14', 358, '2017-04-07', '2017-04-07'),
(478, 68, 430, 388, '2017-04-07 10:11:26', '2017-04-07 10:32:36', 1270, '2017-04-07', '2017-04-07'),
(479, 85, 436, 393, '2017-04-07 11:09:14', '2017-04-07 12:14:54', 3940, '2017-04-07', '2017-04-07'),
(480, 68, 424, 380, '2017-04-07 11:36:04', '2017-04-07 12:11:25', 2121, '2017-04-07', '2017-04-07'),
(481, 68, 438, 396, '2017-04-07 11:36:06', '2017-04-07 12:16:16', 2410, '2017-04-07', '2017-04-07'),
(482, 46, 427, 398, '2017-04-07 12:10:52', '2017-04-10 08:39:32', 246520, '2017-04-10', '2017-04-07'),
(483, 72, 295, 401, '2017-04-07 12:15:30', '2017-04-07 12:50:20', 2090, '2017-04-07', '2017-04-07'),
(484, 68, 432, 389, '2017-04-07 12:16:36', '2017-04-07 12:31:34', 898, '2017-04-07', '2017-04-07'),
(485, 68, 442, 402, '2017-04-07 12:31:49', '2017-04-07 14:34:35', 7366, '2017-04-07', '2017-04-07'),
(486, 68, 443, 403, '2017-04-07 12:32:52', '2017-04-07 14:34:51', 7319, '2017-04-07', '2017-04-07'),
(487, 85, 436, 393, '2017-04-07 12:50:24', '2017-04-10 05:13:39', 231795, '2017-04-10', '2017-04-07'),
(488, 68, 432, 389, '2017-04-07 14:34:49', '2017-04-07 14:52:42', 1073, '2017-04-07', '2017-04-07'),
(489, 58, 406, 383, '2017-04-08 05:30:49', '2017-04-08 16:52:19', 40890, '2017-04-08', '2017-04-08'),
(490, 56, 202, 406, '2017-04-10 04:40:40', '2017-04-10 07:31:21', 10241, '2017-04-10', '2017-04-10'),
(491, 72, 295, 401, '2017-04-10 05:13:39', '2017-04-10 05:42:39', 1740, '2017-04-10', '2017-04-10'),
(492, 63, 448, 407, '2017-04-10 05:24:24', '2017-04-10 08:25:30', 10866, '2017-04-10', '2017-04-10'),
(493, 68, 451, 409, '2017-04-10 05:35:16', '2017-04-10 06:09:09', 2033, '2017-04-10', '2017-04-10'),
(494, 58, 404, 410, '2017-04-10 05:45:31', '2017-04-10 10:43:41', 17890, '2017-04-10', '2017-04-10'),
(495, 72, 297, 411, '2017-04-10 05:49:26', '2017-04-10 07:32:16', 6170, '2017-04-10', '2017-04-10'),
(496, 68, 453, 413, '2017-04-10 06:09:10', '2017-04-10 08:01:53', 6763, '2017-04-10', '2017-04-10'),
(497, 68, 454, 412, '2017-04-10 06:09:18', '2017-04-10 09:09:44', 10826, '2017-04-10', '2017-04-10'),
(498, 59, 364, 414, '2017-04-10 06:11:28', '2017-04-10 08:02:48', 6680, '2017-04-10', '2017-04-10'),
(499, 56, 202, 406, '2017-04-10 07:58:51', '2017-04-10 09:18:22', 4771, '2017-04-10', '2017-04-10'),
(500, 72, 297, 411, '2017-04-10 08:04:14', '2017-04-10 09:13:27', 4153, '2017-04-10', '2017-04-10'),
(501, 68, 453, 413, '2017-04-10 08:20:55', '2017-04-10 09:52:10', 5475, '2017-04-10', '2017-04-10'),
(502, 69, 455, 415, '2017-04-10 08:24:04', '2017-04-10 09:16:42', 3158, '2017-04-10', '2017-04-10'),
(503, 63, 431, 387, '2017-04-10 08:25:39', '2017-04-10 09:29:20', 3821, '2017-04-10', '2017-04-10'),
(504, 55, 452, 419, '2017-04-10 08:39:32', '2017-04-10 09:49:50', 4218, '2017-04-10', '2017-04-10'),
(505, 72, 297, 422, '2017-04-10 09:13:53', '2017-04-10 09:15:51', 118, '2017-04-10', '2017-04-10'),
(506, 72, 297, 422, '2017-04-10 09:15:55', '2017-04-10 12:48:11', 12736, '2017-04-10', '2017-04-10'),
(507, 69, 455, 423, '2017-04-10 09:17:11', '2017-04-10 11:34:16', 8225, '2017-04-10', '2017-04-10'),
(508, 86, 450, 424, '2017-04-10 09:22:39', '2017-04-10 12:18:58', 10579, '2017-04-10', '2017-04-10'),
(509, 63, 449, 426, '2017-04-10 09:30:10', '2017-04-10 11:07:11', 5821, '2017-04-10', '2017-04-10'),
(510, 76, 314, 425, '2017-04-10 09:33:08', '2017-04-10 10:27:25', 3257, '2017-04-10', '2017-04-10'),
(511, 32, 462, 428, '2017-04-10 09:50:14', '2017-04-10 11:33:30', 6196, '2017-04-10', '2017-04-10'),
(512, 75, 325, 429, '2017-04-10 09:54:35', '2017-04-11 06:26:33', 73918, '2017-04-11', '2017-04-10'),
(513, 68, 453, 413, '2017-04-10 09:55:48', '2017-04-10 10:35:59', 2411, '2017-04-10', '2017-04-10'),
(514, 68, 464, 436, '2017-04-10 10:08:01', '2017-04-10 12:09:45', 7304, '2017-04-10', '2017-04-10'),
(515, 88, 465, 437, '2017-04-10 10:08:51', '2017-04-10 12:21:20', 7949, '2017-04-10', '2017-04-10'),
(516, 58, 406, 383, '2017-04-10 10:36:24', '2017-04-11 08:20:42', 78258, '2017-04-11', '2017-04-10'),
(517, 58, 404, 438, '2017-04-10 10:44:06', '2017-04-10 14:25:08', 13262, '2017-04-10', '2017-04-10'),
(518, 63, 459, 439, '2017-04-10 11:07:11', '2017-04-10 12:23:56', 4605, '2017-04-10', '2017-04-10'),
(519, 76, 314, 425, '2017-04-10 11:23:11', '2017-04-10 11:33:46', 635, '2017-04-10', '2017-04-10'),
(520, 32, 462, 444, '2017-04-10 11:34:55', '2017-04-10 12:07:13', 1938, '2017-04-10', '2017-04-10'),
(521, 68, 464, 436, '2017-04-10 12:11:12', '2017-04-10 13:28:52', 4660, '2017-04-10', '2017-04-10'),
(522, 56, 202, 406, '2017-04-10 12:19:16', '2017-04-10 12:42:56', 1420, '2017-04-10', '2017-04-10'),
(523, 88, 465, 437, '2017-04-10 12:21:30', '2017-04-10 12:21:33', 3, '2017-04-10', '2017-04-10'),
(524, 88, 465, 437, '2017-04-10 12:21:35', '2017-04-11 05:22:08', 61233, '2017-04-11', '2017-04-10'),
(525, 63, 448, 440, '2017-04-10 12:24:00', '2017-04-10 13:21:16', 3436, '2017-04-10', '2017-04-10'),
(526, 32, 462, 445, '2017-04-10 12:27:39', '2017-04-10 13:04:47', 2228, '2017-04-10', '2017-04-10'),
(527, 32, 462, 445, '2017-04-10 12:27:40', NULL, NULL, '2017-04-10', '2017-04-10'),
(528, 32, 462, 445, '2017-04-10 12:27:42', NULL, NULL, '2017-04-10', '2017-04-10'),
(529, 76, 314, 425, '2017-04-10 12:28:07', '2017-04-10 12:43:21', 914, '2017-04-10', '2017-04-10'),
(530, 69, 455, 423, '2017-04-10 12:32:47', '2017-04-10 13:49:52', 4625, '2017-04-10', '2017-04-10'),
(531, 72, 294, 449, '2017-04-10 12:48:39', '2017-04-10 13:29:27', 2448, '2017-04-10', '2017-04-10'),
(532, 89, 475, 450, '2017-04-10 13:31:42', '2017-04-10 13:41:37', 595, '2017-04-10', '2017-04-10'),
(534, 89, 476, 452, '2017-04-10 13:46:51', '2017-04-11 05:47:08', 57617, '2017-04-11', '2017-04-10'),
(535, 56, 202, 455, '2017-04-11 04:41:17', '2017-04-11 04:43:10', 113, '2017-04-11', '2017-04-11'),
(536, 59, 405, 456, '2017-04-11 04:41:33', '2017-04-11 08:20:26', 13133, '2017-04-11', '2017-04-11'),
(537, 56, 202, 455, '2017-04-11 04:57:58', '2017-04-11 04:58:08', 10, '2017-04-11', '2017-04-11'),
(538, 72, 294, 457, '2017-04-11 05:07:20', '2017-04-11 08:27:42', 12022, '2017-04-11', '2017-04-11'),
(539, 88, 465, 458, '2017-04-11 05:24:57', NULL, NULL, '2017-04-11', '2017-04-11'),
(540, 34, 44, 459, '2017-04-11 05:29:08', NULL, NULL, '2017-04-11', '2017-04-11'),
(541, 56, 202, 455, '2017-04-11 05:40:18', '2017-04-11 05:58:15', 1077, '2017-04-11', '2017-04-11'),
(542, 68, 489, 460, '2017-04-11 05:41:33', '2017-04-11 06:11:36', 1803, '2017-04-11', '2017-04-11'),
(543, 89, 477, 461, '2017-04-11 05:51:51', '2017-04-11 06:22:00', 1809, '2017-04-11', '2017-04-11'),
(544, 68, 490, 462, '2017-04-11 05:52:20', '2017-04-11 08:06:40', 8060, '2017-04-11', '2017-04-11'),
(545, 56, 202, 455, '2017-04-11 05:58:56', NULL, NULL, '2017-04-11', '2017-04-11'),
(546, 68, 486, 464, '2017-04-11 06:11:39', '2017-04-11 07:14:20', 3761, '2017-04-11', '2017-04-11'),
(547, 89, 477, 461, '2017-04-11 06:26:16', '2017-04-11 06:36:08', 592, '2017-04-11', '2017-04-11'),
(548, 75, 326, 431, '2017-04-11 06:26:55', NULL, NULL, '2017-04-11', '2017-04-11'),
(549, 89, 477, 461, '2017-04-11 06:39:23', '2017-04-11 06:59:18', 1195, '2017-04-11', '2017-04-11'),
(550, 89, 477, 461, '2017-04-11 06:59:24', '2017-04-11 07:11:24', 720, '2017-04-11', '2017-04-11'),
(551, 89, 484, 463, '2017-04-11 07:11:32', '2017-04-11 07:34:21', 1369, '2017-04-11', '2017-04-11'),
(552, 68, 507, 465, '2017-04-11 07:16:55', '2017-04-11 11:20:06', 14591, '2017-04-11', '2017-04-11'),
(553, 58, 406, 466, '2017-04-11 08:20:42', NULL, NULL, '2017-04-11', '2017-04-11'),
(554, 89, 484, 463, '2017-04-11 08:22:57', '2017-04-11 08:25:41', 164, '2017-04-11', '2017-04-11'),
(555, 72, 298, 467, '2017-04-11 08:29:02', '2017-04-11 10:41:19', 7937, '2017-04-11', '2017-04-11'),
(556, 68, 490, 462, '2017-04-11 08:29:17', '2017-04-11 09:02:34', 1997, '2017-04-11', '2017-04-11'),
(557, 89, 484, 463, '2017-04-11 08:30:20', '2017-04-11 10:40:38', 7818, '2017-04-11', '2017-04-11'),
(558, 59, 364, 468, '2017-04-11 08:56:53', NULL, NULL, '2017-04-11', '2017-04-11'),
(559, 58, 404, 469, '2017-04-11 09:17:52', NULL, NULL, '2017-04-11', '2017-04-11'),
(560, 68, 490, 462, '2017-04-11 09:30:07', '2017-04-11 10:40:11', 4204, '2017-04-11', '2017-04-11'),
(561, 72, 518, 470, '2017-04-11 10:09:18', '2017-04-11 10:43:01', 2023, '2017-04-11', '2017-04-11'),
(562, 72, 518, 470, '2017-04-11 11:18:40', '2017-04-11 12:35:15', 4595, '2017-04-11', '2017-04-11'),
(563, 72, 298, 467, '2017-04-11 11:19:22', NULL, NULL, '2017-04-11', '2017-04-11'),
(564, 68, 520, 473, '2017-04-11 11:26:44', NULL, NULL, '2017-04-11', '2017-04-11'),
(565, 68, 521, 474, '2017-04-11 11:29:48', NULL, NULL, '2017-04-11', '2017-04-11'),
(566, 89, 484, 463, '2017-04-11 12:10:26', '2017-04-11 12:35:01', 1475, '2017-04-11', '2017-04-11'),
(567, 89, 484, 463, '2017-04-11 12:45:03', '2017-04-11 12:54:23', 560, '2017-04-11', '2017-04-11');

-- --------------------------------------------------------

--
-- Table structure for table `time_track`
--

CREATE TABLE `time_track` (
  `id` int(16) NOT NULL,
  `approve` tinyint(1) NOT NULL DEFAULT '0',
  `done` tinyint(1) NOT NULL DEFAULT '0',
  `project_id` int(16) NOT NULL,
  `task_id` int(16) NOT NULL,
  `track_date` date DEFAULT NULL,
  `finish_track` datetime DEFAULT NULL,
  `date_start` datetime DEFAULT NULL,
  `date_finish` datetime DEFAULT NULL,
  `duration` int(16) DEFAULT NULL,
  `billable_time` tinyint(1) NOT NULL DEFAULT '0',
  `description` text,
  `additional_cost` int(16) DEFAULT NULL,
  `value` decimal(5,2) DEFAULT NULL,
  `total_time` int(16) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `time_track`
--

INSERT INTO `time_track` (`id`, `approve`, `done`, `project_id`, `task_id`, `track_date`, `finish_track`, `date_start`, `date_finish`, `duration`, `billable_time`, `description`, `additional_cost`, `value`, `total_time`, `updated_at`, `created_at`) VALUES
(194, 1, 1, 52, 155, '2017-03-07', '2017-03-06 12:53:28', NULL, NULL, 240, 0, '', NULL, '0.00', 20646, '2017-04-04 04:06:46', '2017-03-06 05:33:55'),
(195, 0, 0, 32, 157, '2017-02-08', '2017-03-06 13:10:26', NULL, NULL, 30, 0, '', NULL, '0.00', 449, '2017-03-06 13:10:26', '2017-03-06 13:02:26'),
(196, 0, 0, 33, 156, '2017-02-08', '2017-03-06 13:37:34', NULL, NULL, 60, 0, '', NULL, '0.00', 1635, '2017-03-06 13:37:34', '2017-03-06 13:03:09'),
(197, 0, 0, 52, 160, '2017-02-08', '2017-03-07 13:21:50', NULL, NULL, 60, 0, '', NULL, '0.00', 26828, '2017-03-07 13:21:50', '2017-03-07 05:54:36'),
(198, 0, 0, 32, 164, '2017-02-08', '2017-03-08 05:25:44', NULL, NULL, 30, 0, '', NULL, '0.00', 974, '2017-03-08 05:25:44', '2017-03-08 05:09:21'),
(199, 0, 0, 32, 163, '2017-01-11', '2017-03-08 06:21:53', NULL, NULL, 60, 0, 'Add HMSDC site Events & Calendar with QA', NULL, '0.00', 2884, '2017-03-23 07:26:41', '2017-03-08 05:32:40'),
(200, 1, 1, 34, 168, '2017-03-08', '2017-03-08 13:04:41', NULL, NULL, 240, 0, '', NULL, '0.00', 22394, '2017-03-29 08:37:33', '2017-03-08 06:50:41'),
(201, 0, 0, 34, 162, '2017-03-08', NULL, NULL, NULL, 480, 0, '', NULL, NULL, NULL, '2017-03-08 06:59:20', '2017-03-08 06:59:20'),
(202, 0, 0, 52, 160, '2017-02-08', '2017-03-10 05:32:52', NULL, NULL, 240, 0, '', NULL, '0.00', 157733, '2017-03-10 05:32:52', '2017-03-08 07:48:36'),
(203, 1, 1, 32, 169, '2017-03-08', NULL, NULL, NULL, 30, 0, 'Test updates on HMSDC website. ', NULL, NULL, NULL, '2017-03-28 09:25:58', '2017-03-08 08:02:37'),
(204, 1, 1, 27, 170, '2017-03-08', NULL, NULL, NULL, 420, 0, '', NULL, NULL, NULL, '2017-03-29 08:37:40', '2017-03-08 08:03:16'),
(205, 0, 0, 32, 134, '2017-02-08', '2017-03-10 06:26:02', NULL, NULL, 30, 0, '', NULL, '0.00', 3190, '2017-03-10 06:26:02', '2017-03-10 05:32:43'),
(206, 1, 1, 45, 177, '2017-03-14', '2017-03-14 14:07:11', NULL, NULL, 240, 0, 'Test the entire Site', NULL, '0.00', 21814, '2017-03-29 05:06:29', '2017-03-14 06:54:12'),
(207, 0, 0, 50, 95, '2017-02-08', '2017-03-14 12:31:19', NULL, NULL, 240, 0, '', NULL, '0.00', 14204, '2017-03-28 09:26:09', '2017-03-14 08:34:27'),
(208, 0, 0, 56, 183, '2017-02-08', '2017-03-15 05:03:47', NULL, NULL, 180, 0, '', NULL, '0.00', 59507, '2017-03-15 05:11:07', '2017-03-14 12:31:51'),
(209, 0, 0, 33, 182, '2017-02-08', '2017-03-15 05:48:52', NULL, NULL, 30, 0, '', NULL, '0.00', 1569, '2017-03-15 05:48:52', '2017-03-15 05:06:04'),
(210, 1, 1, 45, 177, '2017-03-14', '2017-03-15 13:36:33', NULL, NULL, 300, 0, '', NULL, '0.00', 23258, '2017-03-29 05:07:09', '2017-03-15 05:55:56'),
(211, 1, 1, 56, 183, '2017-02-08', '2017-03-15 13:04:56', NULL, NULL, 240, 0, '', NULL, '0.00', 23084, '2017-03-28 09:27:21', '2017-03-15 06:00:23'),
(212, 1, 1, 34, 162, '2017-03-15', '2017-03-17 07:50:38', NULL, NULL, 480, 1, '', NULL, '0.00', 41995, '2017-03-29 08:37:47', '2017-03-15 06:00:37'),
(213, 1, 1, 27, 170, '2017-03-15', NULL, NULL, NULL, 480, 0, 'Testing of fixed reported issues and change request of myshowcase app.', NULL, NULL, NULL, '2017-04-10 07:10:17', '2017-03-15 06:03:46'),
(214, 0, 0, 50, 187, '2017-02-08', '2017-03-16 07:06:27', NULL, NULL, 180, 0, '', NULL, '0.00', 7367, '2017-03-16 07:06:27', '2017-03-16 05:03:28'),
(215, 0, 0, 27, 170, '2017-03-16', '2017-03-16 13:37:11', NULL, NULL, 480, 0, 'Testing of myshowcase app.\r\n- Test fixed reported issues and updated change request.\r\n- Perform regression testing of App.', NULL, '0.00', 16311, '2017-03-20 04:56:14', '2017-03-16 05:30:53'),
(216, 1, 1, 56, 183, '2017-02-08', '2017-03-16 10:58:40', NULL, NULL, 180, 0, '', NULL, '0.00', 10202, '2017-03-28 09:27:08', '2017-03-16 07:12:25'),
(217, 0, 0, 34, 162, '2017-03-16', NULL, NULL, NULL, 480, 1, '', NULL, NULL, NULL, '2017-03-16 08:50:24', '2017-03-16 08:50:24'),
(218, 1, 1, 58, 192, '2017-03-14', '2017-03-16 09:58:10', NULL, NULL, 30, 0, '', NULL, '0.00', 3881, '2017-03-28 09:26:54', '2017-03-16 08:52:51'),
(219, 1, 1, 58, 191, '2017-03-14', '2017-03-16 12:34:18', NULL, NULL, 150, 0, '', NULL, '0.00', 9364, '2017-03-29 05:07:31', '2017-03-16 09:34:25'),
(221, 1, 1, 27, 170, '2017-03-20', '2017-03-20 12:32:23', NULL, NULL, 450, 0, 'also review Omnidirectional Scope document.', NULL, '0.00', 27053, '2017-03-29 08:37:59', '2017-03-20 04:57:27'),
(222, 1, 1, 34, 44, '2017-03-15', '2017-03-22 05:49:48', NULL, NULL, 480, 1, '', NULL, '0.00', 175878, '2017-03-29 08:38:04', '2017-03-20 04:57:55'),
(223, 0, 0, 32, 169, '2017-03-20', NULL, NULL, NULL, 35, 0, 'Test updates on HMSDC & GNEMSDC website.', NULL, NULL, NULL, '2017-03-20 06:14:44', '2017-03-20 05:01:03'),
(224, 0, 0, 59, 193, '2017-03-20', '2017-03-20 08:02:11', NULL, NULL, 240, 0, '', NULL, '0.00', 10714, '2017-03-20 08:02:11', '2017-03-20 05:03:34'),
(225, 0, 0, 50, 178, '2017-02-08', '2017-03-20 11:16:05', NULL, NULL, 300, 0, '', NULL, '0.00', 19093, '2017-03-20 11:16:05', '2017-03-20 05:34:56'),
(226, 0, 0, 27, 170, '2017-03-21', '2017-03-21 12:50:53', NULL, NULL, 420, 0, 'verify client reported issues on remote pc & our testing pc and Review myshowcase Omnidirectional scope document.', NULL, '0.00', 26361, '2017-03-21 12:50:53', '2017-03-21 05:31:25'),
(227, 0, 0, 58, 190, '2017-03-20', '2017-03-22 08:39:15', NULL, NULL, 300, 0, '', NULL, '0.00', 16629, '2017-03-22 08:39:15', '2017-03-21 05:50:56'),
(228, 0, 0, 52, 199, '2017-02-08', '2017-03-21 14:54:37', NULL, NULL, 300, 0, '', NULL, '0.00', 24238, '2017-03-21 14:54:37', '2017-03-21 07:37:29'),
(229, 0, 0, 32, 169, '2017-03-21', '2017-03-21 14:27:43', NULL, NULL, 30, 0, 'Test Updates on HMSDC & GNEMSDC website.', NULL, '0.00', 5801, '2017-03-21 14:27:43', '2017-03-21 10:21:23'),
(230, 0, 0, 34, 44, '2017-03-15', NULL, NULL, NULL, 120, 0, '', NULL, NULL, NULL, '2017-03-22 05:50:25', '2017-03-22 05:50:25'),
(232, 1, 1, 56, 202, '2017-02-08', '2017-03-22 09:59:35', NULL, NULL, 300, 0, '', NULL, '0.00', 10684, '2017-03-28 09:27:01', '2017-03-22 06:43:13'),
(233, 1, 1, 27, 170, '2017-03-22', '2017-03-22 17:29:06', NULL, NULL, 480, 0, 'Testing of myshowcase App. on different OS. ( windows 7, 8 and 10)', NULL, '0.00', 37149, '2017-03-29 08:38:15', '2017-03-22 07:09:57'),
(234, 0, 0, 33, 194, '2017-02-08', '2017-03-22 13:02:25', NULL, NULL, 60, 0, '', NULL, '0.00', 4102, '2017-03-22 13:02:25', '2017-03-22 11:53:54'),
(235, 1, 1, 46, 145, '2017-02-08', '2017-03-27 06:47:22', NULL, NULL, 60, 1, '', NULL, '0.00', 3986, '2017-03-27 06:47:24', '2017-03-22 13:06:23'),
(236, 1, 1, 52, 154, '2017-02-08', '2017-03-22 14:57:36', NULL, NULL, 60, 0, '', NULL, '0.00', 6209, '2017-03-28 09:18:52', '2017-03-22 13:08:19'),
(237, 0, 0, 27, 170, '2017-03-23', '2017-03-23 10:09:32', NULL, NULL, 300, 0, '', NULL, '0.00', 18438, '2017-03-23 10:09:32', '2017-03-23 05:02:00'),
(238, 0, 0, 55, 215, '2017-02-08', '2017-03-23 06:24:41', NULL, NULL, 120, 0, '', NULL, '0.00', 3847, '2017-03-23 06:24:41', '2017-03-23 05:20:02'),
(240, 0, 0, 33, 214, '2017-02-08', '2017-03-23 13:12:43', NULL, NULL, 60, 0, '', NULL, '0.00', 2172, '2017-03-23 13:12:43', '2017-03-23 12:36:12'),
(241, 0, 0, 46, 222, '2017-02-08', '2017-03-24 06:30:05', NULL, NULL, 60, 0, '', NULL, '0.00', 5186, '2017-03-24 06:30:05', '2017-03-24 05:03:30'),
(242, 1, 1, 58, 226, '2017-03-23', '2017-03-27 12:57:30', NULL, NULL, 240, 0, '', NULL, '0.00', 21625, '2017-03-29 08:38:23', '2017-03-24 06:37:12'),
(243, 1, 1, 61, 223, '2017-02-08', '2017-03-24 13:44:04', NULL, NULL, 360, 0, '', NULL, '0.00', 18011, '2017-04-10 07:11:37', '2017-03-24 07:14:17'),
(244, 1, 1, 39, 249, '2017-03-07', '2017-03-27 13:11:53', NULL, NULL, 300, 0, '', NULL, '0.00', 16710, '2017-04-04 04:06:48', '2017-03-27 05:22:08'),
(245, 1, 1, 56, 183, '2017-02-08', '2017-03-27 08:51:12', NULL, NULL, 60, 0, '', NULL, '0.00', 6251, '2017-03-28 09:25:47', '2017-03-27 07:06:52'),
(246, 1, 1, 61, 223, '2017-02-08', '2017-03-27 14:27:17', NULL, NULL, 360, 0, '', NULL, '0.00', 18020, '2017-03-28 09:27:36', '2017-03-27 09:26:49'),
(247, 1, 1, 42, 81, '2017-03-27', NULL, NULL, NULL, 40, 0, '', NULL, NULL, NULL, '2017-03-28 09:26:20', '2017-03-27 14:22:33'),
(248, 1, 1, 61, 223, '2017-02-08', '2017-03-28 09:19:34', NULL, NULL, 360, 0, '', NULL, '0.00', 16176, '2017-03-29 05:32:26', '2017-03-28 04:49:50'),
(250, 1, 1, 46, 269, '2017-02-08', '2017-03-28 06:02:23', NULL, NULL, 30, 1, '', NULL, '0.00', 1098, '2017-03-28 09:17:45', '2017-03-28 05:44:02'),
(251, 1, 1, 46, 266, '2017-02-08', '2017-03-28 07:04:53', NULL, NULL, 30, 1, '', NULL, '0.00', 1594, '2017-03-28 09:18:00', '2017-03-28 06:34:36'),
(252, 1, 1, 46, 149, '2017-02-08', '2017-03-28 09:13:26', NULL, NULL, 60, 1, '', NULL, '0.00', 2084, '2017-03-28 09:18:10', '2017-03-28 08:38:29'),
(253, 1, 1, 57, 207, '2017-03-20', '2017-04-03 10:28:23', NULL, NULL, 480, 0, '', NULL, '0.00', 521840, '2017-04-04 13:06:30', '2017-03-28 09:30:56'),
(254, 1, 1, 46, 145, '2017-03-28', '2017-03-28 12:31:57', NULL, NULL, 120, 1, '', NULL, '0.00', 9296, '2017-03-31 10:32:24', '2017-03-28 09:56:58'),
(255, 1, 1, 33, 129, '2017-03-28', '2017-03-28 13:11:08', NULL, NULL, 30, 1, '', NULL, '0.00', 2343, '2017-03-31 10:33:29', '2017-03-28 09:57:27'),
(256, 0, 0, 46, 200, '2017-03-28', '2017-04-07 12:10:52', NULL, NULL, 120, 1, '', NULL, '0.00', 856507, '2017-04-07 12:10:52', '2017-03-28 09:58:57'),
(257, 0, 1, 62, 256, '2017-03-27', NULL, NULL, NULL, 30, 0, 'GIBZ', NULL, NULL, NULL, '2017-03-28 14:30:04', '2017-03-28 14:29:04'),
(258, 0, 0, 62, 255, '2017-03-27', NULL, NULL, NULL, 120, 0, 'PASBO contact updates', NULL, NULL, NULL, '2017-03-29 14:28:26', '2017-03-28 14:29:40'),
(259, 0, 0, 62, 254, '2017-03-27', NULL, NULL, NULL, 120, 0, 'Newsletter and Thank you mail ', NULL, NULL, NULL, '2017-03-28 14:30:00', '2017-03-28 14:30:00'),
(260, 0, 0, 61, 265, '2017-02-08', '2017-03-29 07:31:07', NULL, NULL, 180, 0, '', NULL, '0.00', 3949, '2017-03-29 07:31:07', '2017-03-29 05:32:53'),
(261, 0, 0, 58, 226, '2017-03-29', '2017-03-29 14:32:27', NULL, NULL, 240, 0, '', NULL, '0.00', 21736, '2017-03-29 14:32:27', '2017-03-29 05:38:55'),
(262, 0, 1, 50, 272, '2017-02-08', '2017-03-29 06:30:36', NULL, NULL, 30, 0, '', NULL, '0.00', 2959, '2017-03-29 11:18:19', '2017-03-29 05:40:42'),
(264, 0, 1, 56, 202, '2017-02-08', '2017-03-29 10:03:02', NULL, NULL, 180, 0, '', NULL, '0.00', 7223, '2017-03-29 11:18:11', '2017-03-29 07:31:36'),
(265, 0, 1, 50, 107, '2017-02-08', '2017-03-29 11:17:53', NULL, NULL, 90, 0, '', NULL, '0.00', 3457, '2017-03-29 11:18:04', '2017-03-29 10:04:11'),
(266, 0, 0, 62, 259, '2017-03-27', NULL, NULL, NULL, 230, 0, 'SEO Report of Automated Digital Homes', NULL, NULL, NULL, '2017-03-29 14:29:42', '2017-03-29 14:29:42'),
(267, 0, 0, 62, 260, '2017-03-27', NULL, NULL, NULL, 60, 0, 'Agreement for GIBF', NULL, NULL, NULL, '2017-03-29 14:30:31', '2017-03-29 14:30:31'),
(268, 0, 0, 62, 254, '2017-03-27', NULL, NULL, NULL, 60, 0, 'Newsletter content update', NULL, NULL, NULL, '2017-03-29 14:32:12', '2017-03-29 14:31:46'),
(269, 0, 0, 62, 256, '2017-03-27', NULL, NULL, NULL, 40, 0, 'Discussion with Jiten and site review', NULL, NULL, NULL, '2017-03-29 14:33:18', '2017-03-29 14:33:18'),
(271, 0, 0, 61, 265, '2017-02-08', '2017-03-30 12:26:58', NULL, NULL, 300, 0, '', NULL, '0.00', 24811, '2017-03-30 12:26:58', '2017-03-30 04:42:04'),
(272, 0, 0, 27, 170, '2017-03-30', NULL, NULL, NULL, 180, 0, '', NULL, NULL, NULL, '2017-03-30 05:13:09', '2017-03-30 05:13:09'),
(273, 0, 0, 27, 170, '2017-03-30', NULL, NULL, NULL, 240, 0, 'Test updates on Omnidirectional module of myshowcase app. and fixed reported issues of respective module.', NULL, NULL, NULL, '2017-03-30 05:14:18', '2017-03-30 05:14:18'),
(275, 1, 1, 58, 246, '2017-03-30', '2017-03-31 12:28:25', NULL, NULL, 960, 0, '', NULL, '0.00', 20720, '2017-04-04 06:21:33', '2017-03-30 05:28:12'),
(276, 0, 0, 59, 193, '2017-03-30', '2017-03-30 15:51:21', NULL, NULL, 180, 0, '', NULL, '0.00', 23019, '2017-03-30 15:51:21', '2017-03-30 08:30:45'),
(277, 1, 1, 58, 277, '2017-03-30', '2017-04-04 06:18:58', NULL, NULL, 480, 1, '', NULL, '0.00', 24495, '2017-04-04 06:20:40', '2017-03-30 09:24:41'),
(278, 0, 0, 32, 134, '2017-02-08', '2017-03-30 13:20:01', NULL, NULL, 30, 0, '', NULL, '0.00', 3147, '2017-03-30 13:20:01', '2017-03-30 12:27:19'),
(279, 0, 0, 33, 194, '2017-02-08', '2017-03-30 13:52:34', NULL, NULL, 30, 0, '', NULL, '0.00', 1864, '2017-03-30 13:52:34', '2017-03-30 13:20:44'),
(280, 0, 1, 61, 273, '2017-02-08', '2017-03-31 17:18:01', NULL, NULL, 360, 0, '', NULL, '0.00', 32854, '2017-03-31 17:18:14', '2017-03-31 05:50:15'),
(281, 0, 0, 56, 274, '2017-02-08', '2017-03-31 11:50:12', NULL, NULL, 240, 0, '', NULL, '0.00', 8366, '2017-03-31 11:50:12', '2017-03-31 09:30:38'),
(282, 1, 1, 70, 282, '2017-03-31', '2017-04-03 10:08:42', NULL, NULL, 950, 1, '', NULL, '0.00', 0, '2017-04-04 12:25:38', '2017-03-31 10:35:47'),
(283, 0, 0, 62, 256, '2017-03-27', NULL, NULL, NULL, 90, 0, 'Website Updates ana issues. ', NULL, NULL, NULL, '2017-03-31 14:51:59', '2017-03-31 14:51:59'),
(284, 0, 0, 62, 258, '2017-03-27', NULL, NULL, NULL, 20, 0, 'Result result', NULL, NULL, NULL, '2017-03-31 14:52:30', '2017-03-31 14:52:30'),
(285, 0, 0, 62, 260, '2017-03-27', NULL, NULL, NULL, 120, 0, 'Agreement for Automated Digital Homes and GDIZ\r\n', NULL, NULL, NULL, '2017-03-31 14:53:32', '2017-03-31 14:53:32'),
(286, 0, 0, 61, 278, '2017-02-08', '2017-04-03 07:44:40', NULL, NULL, 240, 0, '', NULL, '0.00', 12605, '2017-04-03 07:44:40', '2017-04-03 04:14:25'),
(287, 0, 1, 27, 170, '2017-04-03', '2017-04-03 09:15:23', NULL, NULL, 240, 0, '', NULL, '0.00', 14669, '2017-04-03 13:45:23', '2017-04-03 05:10:27'),
(288, 1, 1, 68, 290, '2017-04-03', '2017-04-03 11:29:18', NULL, NULL, 120, 0, '', NULL, '0.00', 7434, '2017-04-07 05:55:49', '2017-04-03 08:25:17'),
(289, 1, 1, 68, 291, '2017-04-03', '2017-04-03 10:36:21', NULL, NULL, 120, 0, '', NULL, '0.00', 7278, '2017-04-07 05:56:12', '2017-04-03 08:32:55'),
(290, 1, 1, 68, 292, '2017-04-03', NULL, NULL, NULL, 120, 0, '', NULL, NULL, NULL, '2017-04-07 05:56:46', '2017-04-03 08:33:17'),
(291, 1, 1, 68, 293, '2017-04-03', '2017-04-03 09:10:27', NULL, NULL, 30, 0, '', NULL, '0.00', 1918, '2017-04-07 05:57:07', '2017-04-03 08:37:33'),
(292, 0, 1, 27, 286, '2017-04-03', '2017-04-03 14:51:16', NULL, NULL, 210, 0, 'also update release note of Omnidirectional.', NULL, '0.00', 33370, '2017-04-03 14:51:16', '2017-04-03 08:57:45'),
(294, 1, 1, 57, 217, '2017-03-20', '2017-04-03 14:22:19', NULL, NULL, 480, 0, '', NULL, '0.00', 14036, '2017-04-04 13:06:45', '2017-04-03 10:28:19'),
(295, 1, 1, 68, 303, '2017-04-03', '2017-04-03 16:06:42', NULL, NULL, 180, 0, '', NULL, '0.00', 10067, '2017-04-07 05:57:14', '2017-04-03 13:18:49'),
(296, 0, 0, 62, 255, '2017-03-27', NULL, NULL, NULL, 120, 0, 'Hubspot', NULL, NULL, NULL, '2017-04-03 13:53:08', '2017-04-03 13:53:08'),
(297, 0, 0, 62, 263, '2017-03-27', NULL, NULL, NULL, 60, 0, '2 Blog verification and posting', NULL, NULL, NULL, '2017-04-03 13:53:48', '2017-04-03 13:53:48'),
(298, 0, 0, 62, 256, '2017-03-27', NULL, NULL, NULL, 60, 0, 'Review, Client follow up.', NULL, NULL, NULL, '2017-04-03 13:55:04', '2017-04-03 13:55:04'),
(299, 0, 1, 27, 170, '2017-04-04', NULL, NULL, NULL, 150, 0, '', NULL, NULL, NULL, '2017-04-04 13:20:04', '2017-04-04 04:44:47'),
(300, 0, 0, 32, 175, '2017-02-08', '2017-04-04 05:01:47', NULL, NULL, 30, 0, '', NULL, '0.00', 852, '2017-04-04 05:01:47', '2017-04-04 04:47:01'),
(301, 0, 1, 57, 213, '2017-03-20', '2017-04-04 13:20:47', NULL, NULL, 480, 0, '', NULL, '0.00', 29390, '2017-04-04 13:20:49', '2017-04-04 04:57:50'),
(302, 0, 0, 61, 289, '2017-02-08', '2017-04-04 06:52:53', NULL, NULL, 60, 0, '', NULL, '0.00', 2545, '2017-04-04 06:52:53', '2017-04-04 05:03:13'),
(303, 0, 1, 34, 44, '2017-04-03', '2017-04-05 13:25:00', NULL, NULL, 480, 1, '', NULL, '0.00', 26549, '2017-04-07 05:38:29', '2017-04-04 05:18:39'),
(304, 1, 1, 69, 308, '2017-04-04', '2017-04-04 11:15:10', NULL, NULL, 240, 1, '', NULL, '0.00', 12042, '2017-04-04 11:20:14', '2017-04-04 06:27:38'),
(305, 1, 1, 58, 309, '2017-03-30', '2017-04-05 11:29:59', NULL, NULL, 480, 0, 'User will select multiple records from grid and click on next button all the records will be visible same as detailed reports one by one.', NULL, '0.00', 35772, '2017-04-07 06:15:07', '2017-04-04 06:34:24'),
(306, 1, 1, 68, 311, '2017-04-04', '2017-04-04 07:21:58', NULL, NULL, 30, 0, '', NULL, '0.00', 1840, '2017-04-07 05:57:28', '2017-04-04 06:48:58'),
(307, 1, 1, 68, 310, '2017-04-04', '2017-04-04 08:53:29', NULL, NULL, 30, 0, '', NULL, '0.00', 1859, '2017-04-07 05:58:04', '2017-04-04 06:49:25'),
(308, 0, 0, 56, 274, '2017-02-08', '2017-04-04 08:16:32', NULL, NULL, 240, 0, '', NULL, '0.00', 4494, '2017-04-04 08:16:32', '2017-04-04 06:53:20'),
(309, 1, 1, 68, 312, '2017-04-04', '2017-04-04 08:22:23', NULL, NULL, 60, 0, '', NULL, '0.00', 3616, '2017-04-07 05:58:11', '2017-04-04 06:55:50'),
(310, 0, 1, 76, 313, '2017-04-04', '2017-04-04 09:08:06', NULL, NULL, 30, 1, '', NULL, '0.00', 1463, '2017-04-04 09:08:10', '2017-04-04 08:41:25'),
(311, 1, 1, 68, 291, '2017-04-04', '2017-04-04 11:53:09', NULL, NULL, 120, 0, '', NULL, '0.00', 7420, '2017-04-07 05:58:21', '2017-04-04 08:54:17'),
(312, 0, 0, 76, 315, '2017-04-04', '2017-04-04 10:05:02', NULL, NULL, 360, 1, '', NULL, '0.00', 1416, '2017-04-04 10:05:02', '2017-04-04 09:22:02'),
(313, 0, 1, 58, 316, '2017-04-03', NULL, NULL, NULL, 480, 0, '', NULL, NULL, NULL, '2017-04-04 09:22:23', '2017-04-04 09:22:17'),
(314, 0, 1, 58, 316, '2017-04-04', '2017-04-05 11:36:25', NULL, NULL, 480, 0, '', NULL, '0.00', 5051, '2017-04-05 11:36:27', '2017-04-04 09:23:02'),
(315, 1, 1, 68, 319, '2017-04-04', '2017-04-04 10:07:08', NULL, NULL, 60, 0, '', NULL, '0.00', 2005, '2017-04-07 05:58:30', '2017-04-04 09:32:49'),
(316, 0, 1, 27, 286, '2017-04-04', NULL, NULL, NULL, 330, 0, '', NULL, NULL, NULL, '2017-04-04 13:20:06', '2017-04-04 10:26:03'),
(317, 1, 1, 70, 342, '2017-04-04', '2017-04-04 13:07:44', NULL, NULL, 120, 1, '', NULL, '0.00', 6045, '2017-04-04 13:08:14', '2017-04-04 11:23:31'),
(318, 0, 1, 63, 343, '2017-03-20', '2017-04-05 06:31:25', NULL, NULL, 90, 0, '', NULL, '0.00', 60396, '2017-04-05 09:07:31', '2017-04-04 11:30:05'),
(319, 0, 1, 64, 344, '2017-03-20', '2017-04-04 11:36:16', NULL, NULL, 90, 0, 'Server Review\r\nLog files issue\r\nSetup Food and Beverage on OB125', NULL, '0.00', 6, '2017-04-05 09:07:36', '2017-04-04 11:36:02'),
(320, 0, 1, 63, 345, '2017-03-20', NULL, NULL, NULL, 60, 0, '', NULL, NULL, NULL, '2017-04-05 09:07:42', '2017-04-04 11:38:54'),
(321, 0, 0, 75, 333, '2017-04-03', '2017-04-04 14:14:37', NULL, NULL, 240, 1, '', NULL, '0.00', 9186, '2017-04-04 14:14:37', '2017-04-04 11:41:22'),
(322, 1, 1, 68, 347, '2017-04-04', '2017-04-04 12:26:10', NULL, NULL, 30, 0, '', NULL, '0.00', 1813, '2017-04-07 05:59:00', '2017-04-04 11:55:48'),
(323, 0, 0, 46, 349, '2017-02-08', '2017-04-04 12:56:12', NULL, NULL, 60, 0, '', NULL, '0.00', 2532, '2017-04-04 12:56:12', '2017-04-04 12:13:48'),
(324, 0, 1, 63, 348, '2017-03-20', NULL, NULL, NULL, 60, 0, 'Review the Support System and Help-desk and Update the tickets and email to team for unresolved tickets.', NULL, NULL, NULL, '2017-04-05 09:07:47', '2017-04-04 12:22:33'),
(325, 1, 1, 68, 350, '2017-04-04', '2017-04-04 16:07:52', NULL, NULL, 180, 0, '', NULL, '0.00', 11388, '2017-04-07 06:00:16', '2017-04-04 12:34:13'),
(326, 0, 0, 62, 255, '2017-03-27', NULL, NULL, NULL, 230, 0, 'HubSpot sheet updated', NULL, NULL, NULL, '2017-04-04 15:06:22', '2017-04-04 15:06:22'),
(327, 0, 0, 62, 256, '2017-03-27', NULL, NULL, NULL, 60, 0, 'GDIZ, A&A', NULL, NULL, NULL, '2017-04-04 15:07:08', '2017-04-04 15:07:08'),
(328, 0, 0, 62, 258, '2017-03-27', NULL, NULL, NULL, 50, 0, 'GD session', NULL, NULL, NULL, '2017-04-04 15:07:30', '2017-04-04 15:07:30'),
(329, 0, 0, 32, 163, '2017-02-08', '2017-04-05 04:58:22', NULL, NULL, 60, 0, '', NULL, '0.00', 3047, '2017-04-05 04:58:22', '2017-04-05 04:07:05'),
(330, 0, 1, 63, 351, '2017-03-20', '2017-04-05 06:30:46', NULL, NULL, 120, 0, 'Hosting Backup', NULL, '0.00', 7659, '2017-04-05 06:31:45', '2017-04-05 04:22:23'),
(331, 0, 1, 57, 352, '2017-04-04', '2017-04-05 13:27:29', NULL, NULL, 240, 0, '', NULL, '0.00', 12478, '2017-04-05 13:27:36', '2017-04-05 05:28:54'),
(332, 1, 1, 68, 353, '2017-04-05', '2017-04-05 06:17:01', NULL, NULL, 30, 0, '', NULL, '0.00', 1813, '2017-04-07 06:00:26', '2017-04-05 05:46:35'),
(333, 1, 1, 68, 319, '2017-04-04', '2017-04-05 06:24:53', NULL, NULL, 30, 0, '', NULL, '0.00', 1237, '2017-04-07 06:00:39', '2017-04-05 06:04:04'),
(334, 0, 1, 58, 354, '2017-04-05', '2017-04-05 10:07:27', NULL, NULL, 240, 0, '', NULL, '0.00', 14563, '2017-04-05 13:56:11', '2017-04-05 06:04:39'),
(335, 1, 1, 68, 355, '2017-04-05', '2017-04-05 09:00:17', NULL, NULL, 60, 0, '', NULL, '0.00', 3735, '2017-04-07 06:00:54', '2017-04-05 06:05:34'),
(336, 0, 1, 59, 363, '2017-04-05', '2017-04-05 08:28:28', NULL, NULL, 120, 0, '', NULL, '0.00', 8317, '2017-04-05 13:59:42', '2017-04-05 06:09:37'),
(337, 0, 0, 68, 365, '2017-04-03', '2017-04-05 09:20:57', NULL, NULL, 150, 0, '', NULL, '0.00', 11068, '2017-04-05 09:20:57', '2017-04-05 06:13:23'),
(338, 1, 1, 68, 366, '2017-04-05', '2017-04-05 09:27:14', NULL, NULL, 120, 0, '', NULL, '0.00', 7592, '2017-04-07 06:01:09', '2017-04-05 06:22:07'),
(339, 0, 1, 63, 367, '2017-03-20', '2017-04-05 09:09:35', NULL, NULL, 90, 0, '', NULL, '0.00', 3665, '2017-04-05 09:09:43', '2017-04-05 08:08:11'),
(340, 1, 1, 68, 368, '2017-04-04', '2017-04-05 10:24:29', NULL, NULL, 60, 0, '', NULL, '0.00', 4964, '2017-04-07 06:01:22', '2017-04-05 09:01:39'),
(341, 0, 1, 63, 369, '2017-03-20', '2017-04-05 10:44:03', NULL, NULL, 60, 0, '', NULL, '0.00', 5630, '2017-04-05 10:44:08', '2017-04-05 09:10:07'),
(342, 1, 1, 68, 365, '2017-04-05', '2017-04-05 11:40:25', NULL, NULL, 150, 0, '', NULL, '0.00', 8257, '2017-04-07 06:01:36', '2017-04-05 09:21:54'),
(343, 1, 1, 68, 362, '2017-04-05', '2017-04-05 14:29:34', NULL, NULL, 60, 0, '', NULL, '0.00', 4708, '2017-04-07 06:01:49', '2017-04-05 09:22:20'),
(344, 1, 1, 68, 371, '2017-04-05', '2017-04-05 13:42:11', NULL, NULL, 240, 0, '', NULL, '0.00', 14840, '2017-04-07 06:02:05', '2017-04-05 09:33:45'),
(345, 0, 0, 68, 370, '2017-04-05', '2017-04-05 12:50:52', NULL, NULL, 60, 0, '', NULL, '0.00', 4207, '2017-04-05 12:50:52', '2017-04-05 09:38:29'),
(346, 0, 1, 72, 296, '2017-04-04', '2017-04-05 14:17:16', NULL, NULL, 180, 1, '', NULL, '0.00', 16098, '2017-04-07 10:26:01', '2017-04-05 09:48:48'),
(347, 0, 1, 59, 275, '2017-04-05', '2017-04-05 13:59:19', NULL, NULL, 120, 0, '', NULL, '0.00', 14673, '2017-04-05 13:59:35', '2017-04-05 09:54:42'),
(348, 0, 0, 58, 357, '2017-04-05', '2017-04-05 13:56:09', NULL, NULL, 360, 0, '', NULL, '0.00', 9343, '2017-04-05 13:56:09', '2017-04-05 10:12:13'),
(349, 1, 1, 68, 319, '2017-04-05', '2017-04-05 10:57:37', NULL, NULL, 15, 0, '', NULL, '0.00', 1901, '2017-04-07 06:02:29', '2017-04-05 10:25:12'),
(350, 0, 1, 63, 398, '2017-03-20', '2017-04-05 12:44:48', NULL, NULL, 60, 0, 'Finally we fix the issue by crimping new RJ45 connector', NULL, '0.00', 5010, '2017-04-05 12:45:09', '2017-04-05 11:21:12'),
(352, 0, 1, 58, 243, '2017-03-30', '2017-04-05 14:02:09', NULL, NULL, 480, 1, 'crete certificate for multiple license and download', NULL, '0.00', 8194, '2017-04-05 14:02:18', '2017-04-05 11:45:30'),
(353, 0, 1, 63, 400, '2017-03-20', '2017-04-05 13:08:14', NULL, NULL, 90, 0, 'Agent Setup - JK for MyHub\r\nTask- HelpDesk\r\nSupport System tickets review', NULL, '0.00', 1392, '2017-04-05 13:08:22', '2017-04-05 11:53:03'),
(354, 1, 1, 68, 401, '2017-04-05', '2017-04-05 13:11:01', NULL, NULL, 60, 0, '', NULL, '0.00', 94, '2017-04-10 09:34:46', '2017-04-05 13:09:19'),
(355, 0, 0, 56, 202, '2017-02-08', '2017-04-06 05:39:03', NULL, NULL, 60, 0, '', NULL, '0.00', 3060, '2017-04-06 05:39:03', '2017-04-06 04:47:38'),
(356, 0, 1, 63, 402, '2017-03-20', '2017-04-06 09:36:45', NULL, NULL, 240, 0, '', NULL, '0.00', 16496, '2017-04-06 13:08:32', '2017-04-06 05:01:41'),
(357, 0, 0, 59, 405, '2017-04-05', '2017-04-10 06:11:28', NULL, NULL, 960, 0, '', NULL, '0.00', 289290, '2017-04-10 06:11:28', '2017-04-06 05:07:39'),
(358, 0, 1, 27, 286, '2017-04-06', NULL, NULL, NULL, 240, 0, '', NULL, NULL, NULL, '2017-04-06 13:44:55', '2017-04-06 05:08:53'),
(359, 0, 1, 58, 404, '2017-03-30', '2017-04-07 08:46:47', NULL, NULL, 480, 0, '', NULL, '0.00', 34334, '2017-04-07 08:47:14', '2017-04-06 05:31:24'),
(360, 1, 1, 68, 407, '2017-04-06', '2017-04-06 06:31:03', NULL, NULL, 30, 0, '', NULL, '0.00', 3072, '2017-04-07 06:05:13', '2017-04-06 05:38:57'),
(361, 1, 1, 68, 408, '2017-04-06', '2017-04-06 06:44:26', NULL, NULL, 60, 0, '', NULL, '0.00', 3760, '2017-04-07 06:05:30', '2017-04-06 05:41:29'),
(363, 1, 1, 68, 409, '2017-04-06', '2017-04-06 11:23:16', NULL, NULL, 240, 0, '', NULL, '0.00', 16297, '2017-04-07 06:04:54', '2017-04-06 05:45:19'),
(364, 1, 1, 68, 408, '2017-04-06', '2017-04-06 08:06:07', NULL, NULL, 60, 0, 'Deployed functionality at staging server .and cross check at server.', NULL, '0.00', 4694, '2017-04-07 06:04:38', '2017-04-06 06:46:00'),
(365, 1, 1, 68, 410, '2017-04-06', '2017-04-06 11:50:16', NULL, NULL, 180, 0, '', NULL, '0.00', 11357, '2017-04-07 06:03:52', '2017-04-06 06:47:44'),
(366, 1, 1, 68, 319, '2017-04-06', NULL, NULL, NULL, 60, 0, '', NULL, NULL, NULL, '2017-04-07 06:03:37', '2017-04-06 08:06:21'),
(367, 1, 1, 58, 412, '2017-04-06', NULL, NULL, NULL, 30, 0, '', NULL, NULL, NULL, '2017-04-07 06:16:24', '2017-04-06 08:11:41'),
(368, 0, 1, 58, 411, '2017-04-06', NULL, NULL, NULL, 45, 0, '', NULL, NULL, NULL, '2017-04-06 08:12:34', '2017-04-06 08:12:04'),
(369, 0, 1, 82, 413, '2017-04-06', NULL, NULL, NULL, 45, 0, '1.Enrollment of employees\r\n2.Created course topics\r\n3.Call with Team :- 15 minutes', NULL, NULL, NULL, '2017-04-06 08:24:33', '2017-04-06 08:22:53'),
(370, 0, 1, 58, 414, '2017-04-06', '2017-04-06 11:43:04', NULL, NULL, 120, 0, '', NULL, '0.00', 10323, '2017-04-10 08:12:59', '2017-04-06 08:50:57'),
(371, 0, 1, 27, 170, '2017-04-06', NULL, NULL, NULL, 240, 0, '', NULL, NULL, NULL, '2017-04-06 13:44:53', '2017-04-06 09:33:41'),
(372, 0, 1, 63, 403, '2017-03-20', '2017-04-06 10:40:34', NULL, NULL, 60, 0, '', NULL, '0.00', 3792, '2017-04-06 13:08:33', '2017-04-06 09:37:13'),
(373, 0, 0, 68, 370, '2017-04-06', NULL, NULL, NULL, 60, 0, '', NULL, NULL, NULL, '2017-04-06 10:06:03', '2017-04-06 10:06:03'),
(374, 0, 1, 63, 415, '2017-03-20', '2017-04-06 13:08:10', NULL, NULL, 150, 0, '', NULL, '0.00', 7353, '2017-04-06 13:08:34', '2017-04-06 10:43:53'),
(375, 0, 0, 56, 202, '2017-02-08', '2017-04-07 04:54:27', NULL, NULL, 360, 0, '', NULL, '0.00', 63480, '2017-04-07 04:55:18', '2017-04-06 11:16:20'),
(376, 1, 1, 68, 416, '2017-04-06', '2017-04-06 14:20:56', NULL, NULL, 180, 0, '', NULL, '0.00', 10354, '2017-04-07 06:03:13', '2017-04-06 11:27:22'),
(377, 1, 1, 68, 417, '2017-04-06', '2017-04-06 13:21:29', NULL, NULL, 60, 0, 'Need to Search Context', NULL, '0.00', 4076, '2017-04-07 06:02:54', '2017-04-06 12:13:23'),
(378, 0, 0, 62, 256, '2017-03-27', NULL, NULL, NULL, 240, 0, 'GDIZ', NULL, NULL, NULL, '2017-04-06 14:21:18', '2017-04-06 14:21:18'),
(379, 0, 0, 62, 258, '2017-03-27', NULL, NULL, NULL, 40, 0, 'Sheet update and adding data for analysis.', NULL, NULL, NULL, '2017-04-06 14:22:40', '2017-04-06 14:22:40'),
(380, 0, 1, 68, 424, '2017-04-07', '2017-04-07 12:11:25', NULL, NULL, 120, 0, '', NULL, '0.00', 9133, '2017-04-07 13:20:43', '2017-04-07 04:54:00'),
(381, 0, 0, 56, 202, '2017-02-08', '2017-04-07 06:27:53', NULL, NULL, 300, 0, '', NULL, '0.00', 5500, '2017-04-07 06:27:53', '2017-04-07 04:56:08'),
(382, 0, 1, 59, 425, '2017-04-05', '2017-04-07 06:10:52', NULL, NULL, 60, 0, '', NULL, '0.00', 3203, '2017-04-07 06:10:55', '2017-04-07 05:17:24'),
(383, 0, 0, 58, 406, '2017-04-05', '2017-04-11 08:20:42', NULL, NULL, 480, 0, '', NULL, '0.00', 149303, '2017-04-11 08:20:42', '2017-04-07 05:18:54'),
(384, 0, 1, 34, 44, '2017-04-03', '2017-04-07 13:27:27', NULL, NULL, 480, 1, '', NULL, '0.00', 27970, '2017-04-07 13:27:36', '2017-04-07 05:39:08'),
(386, 0, 1, 68, 429, '2017-04-07', '2017-04-07 06:21:43', NULL, NULL, 30, 0, '', NULL, '0.00', 2128, '2017-04-07 12:22:43', '2017-04-07 05:45:29'),
(387, 0, 1, 63, 431, '2017-03-20', '2017-04-10 09:29:20', NULL, NULL, 360, 0, '', NULL, '0.00', 13907, '2017-04-10 09:30:16', '2017-04-07 05:56:04'),
(388, 0, 1, 68, 430, '2017-04-07', '2017-04-07 10:32:36', NULL, NULL, 180, 0, '', NULL, '0.00', 10873, '2017-04-07 15:12:02', '2017-04-07 06:00:56'),
(389, 0, 1, 68, 432, '2017-04-07', '2017-04-07 14:52:42', NULL, NULL, 180, 0, '', NULL, '0.00', 11645, '2017-04-07 14:52:54', '2017-04-07 06:12:13'),
(390, 0, 0, 46, 426, '2017-02-08', '2017-04-07 12:50:09', NULL, NULL, 300, 0, '', NULL, '0.00', 22890, '2017-04-07 12:50:09', '2017-04-07 06:28:26'),
(391, 0, 1, 57, 352, '2017-04-07', '2017-04-07 11:36:01', NULL, NULL, 240, 0, '', NULL, '0.00', 12370, '2017-04-07 13:20:45', '2017-04-07 08:03:58'),
(392, 0, 1, 68, 435, '2017-04-07', '2017-04-07 10:11:14', NULL, NULL, 60, 0, '', NULL, '0.00', 3639, '2017-04-07 15:12:33', '2017-04-07 08:20:09'),
(393, 0, 0, 85, 436, '2017-04-04', '2017-04-10 05:13:39', NULL, NULL, 240, 1, '', NULL, '0.00', 241755, '2017-04-10 05:13:39', '2017-04-07 08:45:27'),
(394, 0, 1, 27, 170, '2017-04-07', NULL, NULL, NULL, 360, 0, '', NULL, NULL, NULL, '2017-04-07 13:54:53', '2017-04-07 08:48:07'),
(395, 0, 1, 58, 437, '2017-03-30', '2017-04-07 15:22:54', NULL, NULL, 360, 1, '', NULL, '0.00', 23278, '2017-04-07 15:23:00', '2017-04-07 08:54:54'),
(396, 0, 1, 68, 438, '2017-04-07', '2017-04-07 12:16:16', NULL, NULL, 120, 0, '', NULL, '0.00', 8118, '2017-04-07 14:53:02', '2017-04-07 09:05:05'),
(397, 0, 1, 27, 286, '2017-04-07', NULL, NULL, NULL, 120, 0, '', NULL, NULL, NULL, '2017-04-07 13:54:54', '2017-04-07 10:47:10'),
(398, 0, 0, 46, 427, '2017-03-28', '2017-04-10 08:39:32', NULL, NULL, 185, 1, 'Create design with responsive', NULL, '0.00', 246520, '2017-04-10 08:39:32', '2017-04-07 12:10:39'),
(399, 0, 0, 52, 418, '2017-03-28', NULL, NULL, NULL, 300, 1, '', NULL, NULL, NULL, '2017-04-07 12:13:10', '2017-04-07 12:13:10'),
(400, 0, 0, 52, 420, '2017-03-28', NULL, NULL, NULL, 60, 1, '', NULL, NULL, NULL, '2017-04-07 12:13:42', '2017-04-07 12:13:42'),
(401, 0, 0, 72, 295, '2017-04-04', '2017-04-10 05:42:39', NULL, NULL, 480, 1, '', NULL, '0.00', 3830, '2017-04-10 05:42:39', '2017-04-07 12:15:25'),
(402, 0, 1, 68, 442, '2017-04-07', '2017-04-07 14:34:35', NULL, NULL, 120, 0, '', NULL, '0.00', 7366, '2017-04-07 14:34:39', '2017-04-07 12:29:40'),
(403, 0, 1, 68, 443, '2017-04-07', '2017-04-07 14:34:51', NULL, NULL, 120, 0, '', NULL, '0.00', 7319, '2017-04-07 15:12:54', '2017-04-07 12:32:45'),
(406, 0, 0, 56, 202, '2017-02-08', '2017-04-10 12:42:56', NULL, NULL, 300, 0, '', NULL, '0.00', 16432, '2017-04-10 12:42:56', '2017-04-10 04:40:30'),
(407, 0, 1, 63, 448, '2017-03-20', '2017-04-10 08:25:30', NULL, NULL, 90, 0, '', NULL, '0.00', 10866, '2017-04-10 08:25:46', '2017-04-10 05:24:16'),
(408, 0, 0, 58, 414, '2017-04-10', NULL, NULL, NULL, 240, 0, '', NULL, NULL, NULL, '2017-04-10 05:32:04', '2017-04-10 05:32:04'),
(409, 0, 1, 68, 451, '2017-04-10', '2017-04-10 06:09:09', NULL, NULL, 30, 0, '', NULL, '0.00', 2033, '2017-04-11 05:37:03', '2017-04-10 05:35:04'),
(410, 0, 0, 58, 404, '2017-03-30', '2017-04-10 10:43:41', NULL, NULL, 960, 0, '', NULL, '0.00', 17890, '2017-04-10 10:43:41', '2017-04-10 05:45:26'),
(411, 0, 0, 72, 297, '2017-04-04', '2017-04-10 09:13:27', NULL, NULL, 180, 1, '', NULL, '0.00', 10323, '2017-04-10 09:13:27', '2017-04-10 05:49:07'),
(412, 0, 1, 68, 454, '2017-04-10', '2017-04-10 09:09:44', NULL, NULL, 180, 0, '', NULL, '0.00', 10826, '2017-04-11 05:37:09', '2017-04-10 06:04:29'),
(413, 0, 1, 68, 453, '2017-04-10', '2017-04-10 10:35:59', NULL, NULL, 240, 0, '', NULL, '0.00', 14649, '2017-04-11 05:48:43', '2017-04-10 06:09:02'),
(414, 0, 0, 59, 364, '2017-04-05', '2017-04-10 08:02:48', NULL, NULL, 120, 0, '', NULL, '0.00', 6680, '2017-04-10 08:02:48', '2017-04-10 06:11:22'),
(415, 0, 0, 69, 455, '2017-04-04', '2017-04-10 09:16:42', NULL, NULL, 240, 1, '', NULL, '0.00', 3158, '2017-04-10 09:16:42', '2017-04-10 08:23:59'),
(416, 0, 1, 27, 170, '2017-04-10', NULL, NULL, NULL, 300, 0, '', NULL, NULL, NULL, '2017-04-10 14:09:00', '2017-04-10 08:29:25'),
(418, 0, 1, 27, 286, '2017-04-10', NULL, NULL, NULL, 150, 0, '', NULL, NULL, NULL, '2017-04-10 14:09:02', '2017-04-10 08:29:51'),
(419, 0, 0, 55, 452, '2017-03-28', '2017-04-10 09:49:50', NULL, NULL, 180, 1, 'Search design and create ', NULL, '0.00', 4218, '2017-04-10 09:49:50', '2017-04-10 08:39:19'),
(421, 0, 1, 34, 44, '2017-04-03', NULL, NULL, NULL, 300, 1, '', NULL, NULL, NULL, '2017-04-10 09:09:31', '2017-04-10 09:09:28'),
(422, 0, 1, 72, 297, '2017-04-10', '2017-04-10 12:48:11', NULL, NULL, 180, 1, '', NULL, '0.00', 12854, '2017-04-10 12:48:14', '2017-04-10 09:13:50'),
(423, 0, 1, 69, 455, '2017-04-10', '2017-04-10 13:49:52', NULL, NULL, 240, 1, '', NULL, '0.00', 12850, '2017-04-10 14:11:12', '2017-04-10 09:17:07'),
(424, 0, 0, 86, 450, '2017-02-08', '2017-04-10 12:18:58', NULL, NULL, 180, 0, '', NULL, '0.00', 10579, '2017-04-10 12:18:58', '2017-04-10 09:22:19'),
(425, 0, 1, 76, 314, '2017-04-10', '2017-04-10 12:43:21', NULL, NULL, 480, 1, '', NULL, '0.00', 4806, '2017-04-10 13:50:59', '2017-04-10 09:29:15'),
(426, 0, 0, 63, 449, '2017-03-20', '2017-04-10 11:07:11', NULL, NULL, 180, 0, '', NULL, '0.00', 5821, '2017-04-10 11:07:11', '2017-04-10 09:30:02'),
(427, 0, 0, 63, 459, '2017-03-20', NULL, NULL, NULL, 61, 0, '', NULL, NULL, NULL, '2017-04-10 09:31:46', '2017-04-10 09:31:46'),
(428, 0, 0, 32, 462, '2017-03-28', '2017-04-10 11:33:30', NULL, NULL, 90, 1, '', NULL, '0.00', 6196, '2017-04-10 11:33:50', '2017-04-10 09:50:08'),
(429, 0, 0, 75, 325, '2017-04-10', '2017-04-11 06:26:33', NULL, NULL, 960, 1, '', NULL, '0.00', 73918, '2017-04-11 06:26:33', '2017-04-10 09:53:32'),
(430, 0, 0, 75, 327, '2017-04-10', NULL, NULL, NULL, 960, 1, '', NULL, NULL, NULL, '2017-04-10 09:53:56', '2017-04-10 09:53:56'),
(431, 0, 0, 75, 326, '2017-04-10', NULL, NULL, NULL, 960, 1, '', NULL, NULL, NULL, '2017-04-10 09:54:21', '2017-04-10 09:54:21'),
(432, 0, 0, 62, 259, '2017-04-07', NULL, NULL, NULL, 90, 0, 'SEO Report', NULL, NULL, NULL, '2017-04-10 09:56:39', '2017-04-10 09:56:39'),
(433, 0, 0, 62, 255, '2017-04-07', NULL, NULL, NULL, 120, 0, 'Ali Baba - Byers5k Freebies', NULL, NULL, NULL, '2017-04-10 09:57:35', '2017-04-10 09:57:35'),
(434, 1, 0, 62, 255, '2017-04-10', NULL, NULL, NULL, 120, 0, 'Ali Baba - Byers5k Sellers follow up and new seller search. ', NULL, NULL, NULL, '2017-04-10 11:34:12', '2017-04-10 09:58:44'),
(435, 0, 0, 62, 256, '2017-04-05', NULL, NULL, NULL, 150, 0, 'GDIZ', NULL, NULL, NULL, '2017-04-10 09:59:14', '2017-04-10 09:59:14'),
(436, 0, 1, 68, 464, '2017-04-10', '2017-04-10 13:28:52', NULL, NULL, 180, 0, '', NULL, '0.00', 11964, '2017-04-11 05:37:23', '2017-04-10 10:07:43'),
(437, 0, 1, 88, 465, '2017-04-10', '2017-04-11 05:22:08', NULL, NULL, 480, 0, '', NULL, '0.00', 69185, '2017-04-11 05:22:10', '2017-04-10 10:08:47'),
(438, 0, 1, 58, 404, '2017-04-10', '2017-04-10 14:25:08', NULL, NULL, 480, 0, '', NULL, '0.00', 13262, '2017-04-10 14:25:13', '2017-04-10 10:44:03'),
(439, 0, 1, 63, 459, '2017-04-10', '2017-04-10 12:23:56', NULL, NULL, 60, 0, '', NULL, '0.00', 4605, '2017-04-10 13:21:22', '2017-04-10 11:06:51'),
(440, 0, 1, 63, 448, '2017-04-10', '2017-04-10 13:21:16', NULL, NULL, 90, 0, '', NULL, '0.00', 3436, '2017-04-10 13:21:25', '2017-04-10 11:07:08'),
(441, 0, 0, 68, 472, '2017-04-03', NULL, NULL, NULL, 30, 0, '', NULL, NULL, NULL, '2017-04-10 11:25:29', '2017-04-10 11:25:29'),
(442, 0, 0, 58, 192, '2017-04-03', NULL, NULL, NULL, 60, 0, '', NULL, NULL, NULL, '2017-04-10 11:26:24', '2017-04-10 11:26:24'),
(443, 0, 1, 84, 434, '2017-04-03', NULL, NULL, NULL, 30, 0, '', NULL, NULL, NULL, '2017-04-10 11:27:56', '2017-04-10 11:27:10'),
(444, 0, 0, 32, 462, '2017-03-28', '2017-04-10 12:07:13', NULL, NULL, 50, 1, 'Replaced images.', NULL, '0.00', 1938, '2017-04-10 12:07:13', '2017-04-10 11:34:48'),
(445, 0, 0, 32, 462, '2017-03-28', '2017-04-10 13:04:47', NULL, NULL, 50, 1, 'replaced images', NULL, '0.00', 2228, '2017-04-10 13:04:47', '2017-04-10 11:36:24'),
(446, 0, 0, 74, 392, '2017-04-10', NULL, NULL, NULL, 120, 0, '1. Added  property "ScrubbingEnabled"  in myShowcase Application\r\n2. Added called play() when media_ended function.\r\n3. Performed Dev testing for it.', NULL, NULL, NULL, '2017-04-10 11:43:44', '2017-04-10 11:37:52'),
(447, 0, 0, 74, 382, '2017-04-10', NULL, NULL, NULL, 110, 0, '1. SliderLeftRightEffect: Updated left margin in  ConfigureUserInterface function so that it should look proper even we change the resolution.\r\n2. Performed Dev testing for it.', NULL, NULL, NULL, '2017-04-10 13:29:54', '2017-04-10 11:41:44'),
(448, 0, 0, 74, 375, '2017-04-10', NULL, NULL, NULL, 120, 0, '1. Updated business logic while closing application to kill the myShowcase process running in task manager even after application gets close.\r\n2. Created myShowcase installer.\r\n3. Dev tested of myShowcase installer.', NULL, NULL, NULL, '2017-04-10 12:14:30', '2017-04-10 12:14:30'),
(449, 0, 1, 72, 294, '2017-04-10', '2017-04-10 13:29:27', NULL, NULL, 240, 1, '', NULL, '0.00', 2448, '2017-04-11 05:06:06', '2017-04-10 12:48:35'),
(450, 0, 1, 89, 475, '2017-04-10', '2017-04-10 13:41:37', NULL, NULL, 10, 1, '', NULL, '0.00', 595, '2017-04-10 13:41:41', '2017-04-10 13:31:38'),
(452, 0, 1, 89, 476, '2017-04-10', '2017-04-11 05:47:08', NULL, NULL, 120, 1, 'Create form ', NULL, '0.00', 57617, '2017-04-11 05:50:34', '2017-04-10 13:46:47'),
(453, 0, 1, 74, 396, '2017-04-10', NULL, NULL, NULL, 480, 1, 'myShowcase WPF app development [Worked on Save content by original name - https://ignatiuz.freshdesk.com/helpdesk/tickets/2177 {Faced issue when we create duplicate Subcategories(Files not saved with original name)}].', NULL, NULL, NULL, '2017-04-10 13:49:55', '2017-04-10 13:49:44'),
(454, 0, 1, 32, 169, '2017-04-10', NULL, NULL, NULL, 30, 0, 'Test Updates on HMSDC website. ', NULL, NULL, NULL, '2017-04-10 14:09:04', '2017-04-10 14:08:12'),
(455, 0, 0, 56, 202, '2017-02-08', '2017-04-11 05:58:15', NULL, NULL, 300, 1, '', NULL, '0.00', 1200, '2017-04-11 05:58:15', '2017-04-11 04:41:09'),
(456, 0, 0, 59, 405, '2017-04-11', '2017-04-11 08:20:26', NULL, NULL, 120, 0, '', NULL, '0.00', 13133, '2017-04-11 08:20:26', '2017-04-11 04:41:20'),
(457, 0, 1, 72, 294, '2017-04-11', '2017-04-11 08:27:42', NULL, NULL, 180, 1, '', NULL, '0.00', 12022, '2017-04-11 08:27:45', '2017-04-11 05:06:40'),
(458, 0, 0, 88, 465, '2017-04-11', NULL, NULL, NULL, 480, 1, '', NULL, NULL, NULL, '2017-04-11 05:24:55', '2017-04-11 05:24:50'),
(459, 0, 0, 34, 44, '2017-04-03', NULL, NULL, NULL, 480, 1, '', NULL, NULL, NULL, '2017-04-11 05:29:03', '2017-04-11 05:29:03'),
(460, 0, 0, 68, 489, '2017-04-11', '2017-04-11 06:11:36', NULL, NULL, 30, 0, '', NULL, '0.00', 1803, '2017-04-11 06:11:36', '2017-04-11 05:40:25'),
(461, 0, 1, 89, 477, '2017-04-11', '2017-04-11 07:11:24', NULL, NULL, 90, 1, '', NULL, '0.00', 4316, '2017-04-11 07:11:28', '2017-04-11 05:51:44'),
(462, 0, 0, 68, 490, '2017-04-11', '2017-04-11 10:40:11', NULL, NULL, 240, 0, '', NULL, '0.00', 14261, '2017-04-11 10:40:11', '2017-04-11 05:52:12'),
(463, 0, 0, 89, 484, '2017-04-11', '2017-04-11 12:54:24', NULL, NULL, 480, 1, '', NULL, '0.00', 11386, '2017-04-11 12:54:24', '2017-04-11 05:52:59'),
(464, 0, 0, 68, 486, '2017-04-11', '2017-04-11 07:14:20', NULL, NULL, 60, 0, '', NULL, '0.00', 3761, '2017-04-11 07:14:20', '2017-04-11 06:11:28'),
(465, 0, 0, 68, 507, '2017-04-11', '2017-04-11 11:20:06', NULL, NULL, 240, 0, '', NULL, '0.00', 14591, '2017-04-11 11:20:44', '2017-04-11 07:16:49'),
(466, 0, 0, 58, 406, '2017-04-11', NULL, NULL, NULL, 480, 0, '', NULL, NULL, NULL, '2017-04-11 08:20:38', '2017-04-11 08:20:38'),
(467, 0, 0, 72, 298, '2017-04-11', '2017-04-11 10:41:19', NULL, NULL, 240, 1, '', NULL, '0.00', 7937, '2017-04-11 10:41:19', '2017-04-11 08:28:58'),
(468, 0, 0, 59, 364, '2017-04-11', NULL, NULL, NULL, 120, 0, '', NULL, NULL, NULL, '2017-04-11 08:56:49', '2017-04-11 08:56:49'),
(469, 0, 0, 58, 404, '2017-04-11', NULL, NULL, NULL, 480, 0, 'Deployment on production and database creation on production.', NULL, NULL, NULL, '2017-04-11 09:17:48', '2017-04-11 09:17:48'),
(470, 0, 0, 72, 518, '2017-04-11', '2017-04-11 12:35:16', NULL, NULL, 120, 1, '', NULL, '0.00', 6618, '2017-04-11 12:35:16', '2017-04-11 10:09:14'),
(471, 0, 0, 27, 170, '2017-04-11', NULL, NULL, NULL, 150, 0, '', NULL, NULL, NULL, '2017-04-11 11:26:11', '2017-04-11 11:26:11'),
(472, 0, 0, 27, 286, '2017-04-11', NULL, NULL, NULL, 240, 0, '', NULL, NULL, NULL, '2017-04-11 11:26:33', '2017-04-11 11:26:33'),
(473, 0, 0, 68, 520, '2017-04-11', NULL, NULL, NULL, 180, 0, '', NULL, NULL, NULL, '2017-04-11 11:26:33', '2017-04-11 11:26:33'),
(474, 0, 0, 68, 521, '2017-04-11', NULL, NULL, NULL, 150, 0, '', NULL, NULL, NULL, '2017-04-11 11:29:32', '2017-04-11 11:29:32'),
(475, 0, 0, 62, 255, '2017-04-05', NULL, NULL, NULL, 150, 0, 'Byers5k - Freebies(Followup and new search)', NULL, NULL, NULL, '2017-04-11 11:34:47', '2017-04-11 11:34:47');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `google_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `employe` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_team_id` int(10) NOT NULL DEFAULT '0',
  `hourly_rate` float(5,2) DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `google_id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`, `employe`, `users_team_id`, `hourly_rate`) VALUES
(44, NULL, 'Linux Admin', 'admin@admin.com', '$2y$10$098xVr3AdbpptAkhtYtUCOWYUEqiaVD/RBEL86W8W0qWDl6cd4DRC', 'qPbGVBYD6hwZvy0LNL0QR0VR7DEmGnvxkKwslvlDnUqcn2EWIi7eTngYZ18d', '2016-12-09 04:43:22', '2017-04-10 13:32:41', 'Admin', 0, 0.00),
(69, NULL, 'Jitendra Khatri', 'jitendra.khatri@ignatiuz.com', '$2y$10$qdJBxmVTek83p2MjgOzaBODADIML51wnmSeOfeRufNUR/YTCOoiiK', 'FHUEPZARoDimtlvTSRw3uk1ulC87spLJuCgk9g7jRwOVKW7qaN8gUjH3mHl0', '2017-01-11 15:05:34', '2017-04-03 09:26:37', 'Admin', 0, 0.00),
(70, NULL, 'Raveesh Katiyar', 'raveesh.katiyar@ignatiuz.com', '$2y$10$eE5T1ZmNCpBz8azqGdookOzFTHsDf84mCOfm6JSMZOiA68unwUwBG', 'sziIzEFC9a3G5ZHYJEQulSEMJ05KSXgdnglj1YPZ0TaqyyOVOMRTdMGYtORl', '2017-01-11 15:06:01', '2017-04-10 17:21:28', 'Lead', 27, 0.00),
(71, NULL, 'Deepesh Verma', 'deepesh.verma@ignatiuz.com', '$2y$10$p9nBHAWRShe.SbUaCLiqQePLecxjsYFEar1wZenDMYh2BYvkEZ.Mi', 'GUCCej2U73BRryfaVcq6pbJf6EUrcP0KPQe2NryKKEd5Ny3GE3TKEVuk4U3c', '2017-01-11 15:06:36', '2017-04-10 13:19:25', 'Admin', 0, 0.00),
(73, NULL, 'Yogendra kushwah', 'yogendra.kushwah@ignatiuz.com', '$2y$10$Z4qjLShdVOEmLaupwCuFkux0hJqHI4gGlPuesIVMVTM7H9WRsdz.K', 'yNaHUgiaxcD6FijBd5cu4sqgfRyNIfbTcl8BJKRyYZCQ9hEOHp6d6Gr4VMFi', '2017-01-13 13:54:27', '2017-04-11 15:26:37', 'QA Engineer', 18, 0.00),
(75, NULL, 'Ajay Thakare', 'ajay.thakare@ignatiuz.com', '$2y$10$PFKeKDDPHtr06figqT3yQemMIcNcKizSzK3eGeNJK40VVnY8oOPpK', 'XSjU7X7k0673Z1Gu6bErI664h6I2oRnL9m0ty2qC4tuwrpH4fc1swg5f4Pvc', '2017-01-16 15:03:11', '2017-01-21 12:00:26', 'Developer', 16, 0.00),
(81, NULL, 'Himanshu Goil', 'himanshu@ignatiuz.com', '$2y$10$L97ucICfMAiiLLjtz5uoSelZbRERo4zWFGHZ/G6tYL.pEKlb/zN/y', NULL, '2017-01-18 17:30:51', '2017-01-18 17:30:51', 'Admin', 0, 0.00),
(82, NULL, 'Raveesh ! ArdentInfotech', 'raveesh.katiyar@ardentinfotech.com', '$2y$10$U6Z2nIIwlYg4iKijoopUaOw4qd3BT/w7wFr1m5ZR.PDCYVSHQXJ7m', 'sYZSTS9bQhKR3oAVidZrZg6uME4WljvzKpMLgyO95dlV1ln9l804J1wbAwI6', '2017-01-18 17:40:59', '2017-01-18 17:48:18', 'Supervisor', 0, 0.00),
(85, NULL, 'Jitendra Sharma', 'jitendra.sharma@ignatiuz.com', '$2y$10$g/Jljqul43ynKDyfKXg0PesrTOo7cyRNJ8l3Un7tg.3BMid1kGUDi', 'OU5NZPn4iF8OmpHa2Q0jqwTdDIY8KJ6xLTyDmgKNkTYSSH47R0v8FAtNNEMo', '2017-01-19 14:08:47', '2017-03-31 14:24:31', 'Lead', 19, 0.00),
(86, NULL, 'Anish Lokre', 'anish.lokre@ignatiuz.com', '$2y$10$Z5L3nwVwg304pPzWFOBt.OpdIGJecVn8foECzV4BYfIm4C8ap.kgO', '4YHltc2GKRbGaSPGWT8C2SAKRMidO8XJAuMNyZcunhsOeki7rPDX5K0MfOVg', '2017-01-20 10:46:45', '2017-04-10 13:17:56', 'Lead', 18, 0.00),
(87, NULL, 'Rajesh Lohar', 'rajesh.lohar@ignatiuz.com', '$2y$10$auuhbXMAvOb5ougRmWKo3OMfAJ6mlTEnUnlZWv1YKNKRdpED3fwHa', 'pnGyOB68q7lZqk3QprZtsWjWdOtGKON1JBGeh3IPZhUyNlg3Zvas1AUdatYY', '2017-01-21 11:52:54', '2017-03-20 17:42:35', 'Lead', 15, 0.00),
(88, NULL, 'Sandeep Prajapat', 'sandeep.prajapat@ignatiuz.com', '$2y$10$2d5yra6rqHvE5R/OW.D.jOefNPKEEZdIa77eQCXMef8CB8J..usuW', 'sTFroARO6sBY9R71wRfWx7tUgB80NwbsJ1vplGPFz0WdnMd20jJOxnCsxqDP', '2017-01-21 11:58:14', '2017-04-03 12:18:24', 'Lead', 16, 0.00),
(89, NULL, 'Jyoti Sisodiya', 'jyoti.sisodiya@ignatiuz.com', '$2y$10$GyUAVilOT9UgX3H34ijOqeDKxkNU5igScjY2Xg4OYgcenSj3R8akC', 'dYrnNbMvsQWuoEXQfNYhrX7kc60z9Vp56mNozX3nfileOxmfgHamNBqTLdG9', '2017-01-21 11:59:01', '2017-04-10 14:33:26', 'Developer', 15, 0.00),
(90, NULL, 'Priyanka Gayakwad', 'priyanka.gayakwad@ignatiuz.com', '$2y$10$pkQIlxalAq.NLMdZ5mui9.mU.6XhUeUBpRpX9oPqrhDdbpxL2DDny', 'mSoFm5nvBM73sfPYcD291705Us7UjeskGbuM8k9qIiRqiDUq0IalOnIuSJbs', '2017-01-21 12:32:27', '2017-04-05 18:35:35', 'Developer', 15, 0.00),
(91, NULL, 'Bhavna Verma', 'bhavna.verma@ignatiuz.com', '$2y$10$ViQS0z11h2mWqRxim/MvJOiOdpZGRnJnqaQe9r0AXm35DGN155qr2', 'SOJIyqyJzFh7dZzoJpl7s9xXOnNeTgyLqjp30n2ebDZpszdUslhJX8M7I7WR', '2017-01-21 12:39:29', '2017-02-13 11:20:01', 'Developer', 19, 0.00),
(92, NULL, 'Sonam Gujarathi', 'sonam.gujarathi@ignatiuz.com', '$2y$10$ew5.I9YykUDK5odyVFJE..praYo5Wkdzob3jymukd7q2bhehyt9KS', 'UZv54FbpJ4ZMrhUg7kY9smwZscvdnkSSs2nsTSl8VZDxugBzP5x6AhZC1Pta', '2017-01-24 10:16:38', '2017-04-06 17:58:42', 'Developer', 15, 0.00),
(93, NULL, 'Pooja Ajugia', 'pooja.ajugia@ignatiuz.com', '$2y$10$/x0ax8c.ZaFL0zAULeJ7iOkhxM1t00EbKNwRPVlHUcCOtr2hlg7NC', 'rzdQlBLkZS7stbYqVXvWjNxVZ2EfUiOMgaijp3GRGNbb3dDGls25RvhsMkyU', '2017-01-24 10:31:04', '2017-04-10 14:36:36', 'Developer', 15, 0.00),
(97, NULL, 'Himanshu Mudgal', 'mudgal.himanshu@ignatiuz.com', '$2y$10$6jWlfUHTweUZbNKweM4bIeFF4jfIaaXxBHaLSIIjRbOSKnuiragnS', 'mqSA9Q5TpsKsuk9uTDTQUgLmxNBfERi45soMFTfF9nsiUHRDonVkdwtyooLJ', '2017-01-27 10:29:31', '2017-04-07 17:00:34', 'Developer', 19, 0.00),
(100, NULL, 'Yogesh Chouhan', 'yogesh.chouhan@ignatiuz.com', '$2y$10$0k52NYuxFTf4g0df3VHlDOaJpTB7jOLYjHu2MpogDuW/Yf.ale6MC', NULL, '2017-01-31 15:19:54', '2017-03-28 12:37:21', 'Developer', 26, 0.00),
(103, NULL, 'Rupali Namdeo', 'rupali.namdeo@ignatiuz.com', '$2y$10$aI6jcmYRPYQTTyxGTjK6COAOijoxHmO05OG2ajk0Vsfpc0ia4N7fm', 'X3qnTxHVKaSlM65xx1vNl3dGjnacXGIGLX4eR0QveaQNNASqBKKIiALal3vR', '2017-02-03 10:13:52', '2017-04-10 18:25:19', 'Developer', 15, 0.00),
(104, NULL, 'Rupal Chaudhary', 'Rupal.chaudhary@ardentinfotech.com', '$2y$10$wcnG/TvN9OcHUR9dorMlBuoPklG2Prpy7NaXx/Mtzeipcixith1XS', '8jPND45tBGPEMVHBa8eAJiJUzMAx5dOnqt7Is3oxgeaHZPYSsQVBrROrMutb', '2017-02-03 10:14:36', '2017-03-31 16:43:39', 'Developer', 22, 0.00),
(105, NULL, 'Anshul Soni', 'anshul.soni@ardentinfotech.com', '$2y$10$wE.9s.jlOv5cJlIwJpVTiOlrZ6Y8bOJUCUvLWvElrlPCxD6HK0uLy', NULL, '2017-02-03 10:15:13', '2017-02-07 10:40:17', 'Developer', 15, 0.00),
(106, NULL, 'Raksha Solanki', 'raksha.solanki@ardentinfotech.com', '$2y$10$7CsV6uXJSAkCTUyZ3U472.5q9pSpfD5YBqZsSu53VNTQ2uCSewA/6', 'tGLhUAuH7UuVOrg8vjM8OBBtkwUS2XbrV3tCjae4CmD91BmDUn9MzsUUpVA1', '2017-02-03 10:16:11', '2017-04-03 12:42:31', 'Developer', 30, 0.00),
(107, NULL, 'Resource Pool', 'people@ignatiuz.com', '$2y$10$6WQEdDXRZQos26cU1OjJS.x82oZM1hQxs6cBj7X6uSiZ4ofswxWti', NULL, '2017-02-03 10:32:28', '2017-02-03 10:32:44', 'Lead', 22, 0.00),
(109, NULL, 'Priyanka Saroch', 'priyanka.saroch@ignatiuz.com', '$2y$10$Y.OJoMY5XVQmC3oPxHOUP.BjQ/MFUDk/ckuF.PPeMMHOc29LEFn5C', 'qRx4pb70a4qJEyec6SAvgTFPERc4dOow89G5Kxrqk9Sq2Ah8uvImB1jQ3bny', '2017-02-09 17:29:53', '2017-04-10 15:29:22', 'QA Engineer', 18, 0.00),
(111, NULL, 'Rahul Barpha', 'rahul.barpha@ignatiuz.com', '$2y$10$5pe0K9MORT6j4IHweSdv.efmdL2xlkd.AYdHsJluJt0wvckAt9xVe', 'k6deTwiSHKmtWQgzFb1bfkSVibsTh4EWojHS63nkqEJwMhOMULKxXyInjlgC', '2017-03-16 13:32:11', '2017-04-11 13:59:15', 'Developer', 15, 0.00),
(112, NULL, 'Deepak Gour', 'deepak.gour@ignatiuz.com', '$2y$10$F1J2n.N0wdch1X3.zKmBiOm4JTPBWYamRatQv48tAdjCCOCXsRWnq', 'bzbrbtoQPz1b2mpQOpVQEYmkQwoixG9nfDFUhBtw5e9vopl9ygaGLpXyA8wz', '2017-03-16 14:16:50', '2017-03-16 16:02:21', 'Developer', 15, 0.00),
(113, NULL, 'Mithlesh Navlakhe', 'mithlesh.navlakhe@ignatiuz.com', '$2y$10$WSlO1RKeTJUxSYs6.KLY9ue7mzZOkjcQO6VXGZdXlDeivwS3dt.YW', 'Qi4vWMmj47Z6qjMsqWPPkOfWfhlZjZpBeo0iwWf5ucLhObNTrd45Qvv5vKrP', '2017-03-20 09:34:36', '2017-04-10 18:30:46', 'Lead', 29, 0.00),
(114, NULL, 'Ashish Kosti', 'ashish.kosti@ignatiuz.com', '$2y$10$eiNns5bR.sLj.WYd2i6n.edwvCjoinwajDcH/jcdiooQxvL6AdfcO', 'WCMPjqHE0FIuvnQTweY7TVg1RNhpRxjS32aHOKmcB5XYSMWxmZfNQdZA9ZRp', '2017-03-21 13:15:46', '2017-04-03 12:44:58', 'Developer', 22, 0.00),
(115, NULL, 'Amit Wadhwani', 'amit.wadhwani@ignatiuz.com', '$2y$10$gZRKgtYsZBeMTwpcb3x5/edrYC4Gu5NfGZ62fbNBtFHlIKQvOeSCW', NULL, '2017-03-24 09:48:59', '2017-03-24 09:48:59', 'Lead', 26, 0.00),
(116, NULL, 'Aakash Rajput', 'aakash.rajput@ignatiuz.com', '$2y$10$EUtPwzt74JsJca7CPil8p.3Db6RJLnLSUOO/fnmNJfy6o993QH0ku', 'wmuOxgzIXz3QSFr27RC7HEckqgGNzkI2yPKgwy0PNkNjWADKsTjw16PlkRvG', '2017-03-31 14:16:43', '2017-04-04 10:26:53', 'Developer', 15, 0.00),
(117, NULL, 'Nitin Rathore', 'nitin.rathore@ignatiuz.com', '$2y$10$xYru2G9DbfLBXcobj/unJudBHu/x7EXOgPXD8x9986Vx5etBoc/8O', 'g7ezDCV24Y8AjDSLpz1AI71oSccnt71Iu26qCvLRDL9O7NkICXYHWgvQ1bie', '2017-03-31 15:40:14', '2017-04-03 13:03:15', 'Developer', 16, 0.00),
(118, NULL, 'Ankit BIjoria', 'ankit.bijoria@ignatiuz.com', '$2y$10$JTW21V1SRHUI/b.ZKdyPNu4w051wUHlqrWDTzw8kgkhkX5LOGhqRK', NULL, '2017-03-31 15:43:35', '2017-03-31 15:43:35', 'Developer', 16, 0.00),
(119, NULL, 'Devanshu Kanik', 'devanshu.kanik@ardentinfotech.com', '$2y$10$MJscj9rlSdlETTjtCCitN.2c0VN0Z0iZRg6gDcCBquEPyZYDhjr6O', NULL, '2017-03-31 15:46:38', '2017-03-31 15:46:38', 'Developer', 15, 0.00),
(120, NULL, 'Lovkesh Patel', 'lovkesh.patel@ignatiuz.com', '$2y$10$yT8w4oRhFWdujM3fu.1P2uPKHT8TucLuNCPwMaq2/kG3op/gYMyK.', NULL, '2017-03-31 15:48:33', '2017-03-31 15:48:33', 'Developer', 15, 0.00),
(121, NULL, 'Deepti Goil', 'deepti@ignatiuz.com', '$2y$10$sR4R0zevYU3VwjJ7DK52e.480NIYa9cpzH4r9I6fyE3pAR/6SEVXC', NULL, '2017-03-31 15:52:18', '2017-03-31 15:52:18', 'Lead', 28, 0.00),
(122, NULL, 'Priyanka Sarkar', 'priyanka.sarkar@ignatiuz.com', '$2y$10$SdX79/HLxQ3o6Ocr5qsA5OHWP0uuX/Vh/GPrwnejr8UAIJrJRd1NC', '6e1JB1G1cVN1FEjh0JNvpdJ6KkXADyTvkK5fCFnG9jI9UUmHjFe9ZHYQpKJC', '2017-03-31 15:53:32', '2017-03-31 17:48:27', 'Developer', 28, 0.00),
(123, NULL, 'Ambrish Tiwari', 'ambrish.tiwari@ignatiuz.com', '$2y$10$ZwMJLe7qBxWAvsYysIiydekhwi2qLjq/wdkclw69QpZQ6d6pVcxYO', 'jqZUo0Yy7ZYgEpyVcQZbRHNYIeiWJePHwwNuiYJkAoc9fvlW38LuwkG77dfu', '2017-03-31 15:55:40', '2017-04-03 15:04:24', 'Developer', 15, 0.00),
(124, NULL, 'Rahul Rai', 'rahul.rai@ardentinfotech.com', '$2y$10$OKYY5Nxau4uUizQHccnFMuznND4FBFY6LyDrEG82837.DNkcIcGJu', NULL, '2017-03-31 15:57:21', '2017-03-31 15:57:21', 'Developer', 15, 0.00),
(125, NULL, 'Swapnil Nath', 'swapnil.nath@ardentinfotech.com', '$2y$10$wMTgikulIyY0DVUEXRBGzuXJYJzgTcRljd.eLaqVX4kxNFz2TPP32', 'nq63vF8QjSDJ7UGqRlUCNfXoirScB0FC7GLBbrc1Y1ovSFhodvDNxMneMQ3w', '2017-04-03 12:09:33', '2017-04-11 16:35:31', 'Developer', 29, 0.00),
(126, NULL, 'Mayur Dubey', 'mayur.dubey@ignatiuz.com', '$2y$10$bx/I360OcpXtpGmxwYgE5.89cWQQHxTbWZfb7NUmZSZ5XAvNoDkau', 'rYymnAXtLAs2lMkscSkqaxyO6uxpo6CLUVC7PWV7IYuef4l0pKaaLyXZBdEW', '2017-04-03 12:20:00', '2017-04-03 12:44:17', 'Lead', 30, 0.00),
(127, NULL, 'Ashwin Barfa', 'ashwin.barfa@ignatiuz.com', '$2y$10$nWXz9qDD00QB6NSxLg2yru11ovPD9O9RsYlDdPe9Obww5a9ykfA/e', '1Rjcsucg3VpEpDiMt0sqqlRuesccuHvw4HPBDT4UzYVN9UAnozsZGW7qzAO7', '2017-04-03 12:20:30', '2017-04-03 12:40:56', 'Lead', 30, 0.00),
(128, NULL, 'Prashant Jain', 'prashant.jain@ignatiuz.com', '$2y$10$InoltdFefZtfFg4.wqHEge8Hfym/v2xN.Qbwi/and8O/g8RYFbXQ6', NULL, '2017-04-03 12:20:54', '2017-04-03 12:20:54', 'Lead', 30, 0.00),
(129, NULL, 'Vijendra Verma', 'vijendra.verma@ignatiuz.com', '$2y$10$euqGNaW5V6RlurZAWAlG3euSfd630iA3MTYuW7cW2LKc9PcUhxYjS', 'FtA89G51NHPh8IsUj8HihO5kWEWtGtPdqIKRdb5eBZTVzCym1w1BW9BpLaSU', '2017-04-03 12:21:49', '2017-04-03 12:37:26', 'Developer', 30, 0.00),
(130, NULL, 'Manoj Patidar', 'manoj.patidar@ardentinfotech.com', '$2y$10$mrxHIv8ZEYpdYdkWD..tee/3ecGA9/35NDccejfWs4Ny0MFVfbdRO', NULL, '2017-04-03 12:22:23', '2017-04-03 12:22:23', 'Developer', 30, 0.00),
(131, NULL, 'Bhavya Joshi', 'bhavya.joshi@ardentinfotech.com', '$2y$10$.NMqo0lgrauXHJIB4t6PI.MECF4vRV0urqPUuqOB5zY6X9RSk0iKC', NULL, '2017-04-03 12:22:58', '2017-04-03 12:22:58', 'Developer', 30, 0.00),
(132, NULL, 'Abhay Dwivedi', 'abhay.dwivedi@ignatiuz.com', '$2y$10$Mh8LVMvEU2K5sC./aV5.7uWKQY0y94WPp1lVIPydMpRJVH1s6BcN.', NULL, '2017-04-03 12:23:36', '2017-04-03 12:23:36', 'Developer', 30, 0.00),
(133, NULL, 'Shivkumar Mourya', 'shivkumar.mourya@ardentinfotech.com', '$2y$10$UR1hYwpUJAOjhpOaarMJCuKu5wswNUOW0MMlTFnjAwmSm37yN.D6q', NULL, '2017-04-03 12:24:27', '2017-04-03 12:24:27', 'Developer', 30, 0.00),
(134, NULL, 'Kuldeep Singh Chouhan', 'kuldeep.chouhan@ardentinfotech.com', '$2y$10$TNEr8EoeK/u96ePF0emL.e/4N.g6EyrwFR3sVEC4imzOokLN9rMMG', NULL, '2017-04-03 12:30:25', '2017-04-03 12:30:25', 'Developer', 30, 0.00),
(135, NULL, 'Jayesh Nathani', 'jayesh.nathani@ardentinfotech.com', '$2y$10$psLa87gJSsMwi7jxIT7NMeysMSsZxShpvwT2YyeZnuXijomSzU77K', NULL, '2017-04-03 12:31:01', '2017-04-03 12:31:01', 'Developer', 30, 0.00),
(136, NULL, 'Pushpendra Singh Chouhan', 'pushpendra.chouhan@ardentinfotech.com', '$2y$10$hdSgrIenvVudogGA9nxRSuC6B.77aQS31DamHrB4RM2m7aN717XkO', NULL, '2017-04-03 12:31:46', '2017-04-03 12:31:46', 'Developer', 30, 0.00),
(137, NULL, 'Hrishabh Kushwah', 'hrishabh.kushwh@ignatiuz.com', '$2y$10$8OPGwiiaUtfFl/UeGi5IceqtbldeQgXlC8O5SyO6gj5ZxN2QPCKhm', NULL, '2017-04-03 12:40:53', '2017-04-03 12:40:53', 'Developer', 30, 0.00),
(138, NULL, 'Neha Bhandari', 'neha.bhandari@ardentinfotech.com', '$2y$10$gbOU5UEX2XXmSixdxSirJ.cw5CN50eiv3yo9YlqWYJmMXwI4bxA6O', NULL, '2017-04-03 12:41:27', '2017-04-03 12:41:27', 'Developer', 30, 0.00),
(139, NULL, 'Deep Dhanotiya', 'deep.dhanotiya@ardentinfotech.com', '$2y$10$5wOxhOXvJw2n1VCA3Oj3ieai9pWGhh7VGYgYC/e5qw4WpmV0J0/pm', NULL, '2017-04-03 12:43:50', '2017-04-03 12:43:50', 'Developer', 30, 0.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Clients`
--
ALTER TABLE `Clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `Project`
--
ALTER TABLE `Project`
  ADD PRIMARY KEY (`id`),
  ADD KEY `client_id` (`client_id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `company_id` (`company_id`,`project_id`),
  ADD KEY `project_id` (`project_id`);

--
-- Indexes for table `task_type`
--
ALTER TABLE `task_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `time_log`
--
ALTER TABLE `time_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `task_id` (`track_id`);

--
-- Indexes for table `time_track`
--
ALTER TABLE `time_track`
  ADD PRIMARY KEY (`id`),
  ADD KEY `task_id` (`task_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Clients`
--
ALTER TABLE `Clients`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `Project`
--
ALTER TABLE `Project`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;
--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=522;
--
-- AUTO_INCREMENT for table `task_type`
--
ALTER TABLE `task_type`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `time_log`
--
ALTER TABLE `time_log`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=568;
--
-- AUTO_INCREMENT for table `time_track`
--
ALTER TABLE `time_track`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=476;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=141;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `Project`
--
ALTER TABLE `Project`
  ADD CONSTRAINT `project_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `Clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tasks`
--
ALTER TABLE `tasks`
  ADD CONSTRAINT `tasks_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `Clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tasks_ibfk_2` FOREIGN KEY (`project_id`) REFERENCES `Project` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `time_log`
--
ALTER TABLE `time_log`
  ADD CONSTRAINT `time_log_ibfk_1` FOREIGN KEY (`track_id`) REFERENCES `time_track` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `time_track`
--
ALTER TABLE `time_track`
  ADD CONSTRAINT `time_track_ibfk_1` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
