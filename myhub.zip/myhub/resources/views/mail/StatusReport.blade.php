<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>
<body>
	<div class="message-body font-ariel font-grey">
		<p>Hi, </p>
		<p>My Today’s Status Report are as follows:- </p>
		<p>Today’s Tasks:- </p>
		<p><span>{!! $todayTask !!}</span></p>
		<div>
			<p>Thanks,<br>{{ $name }}</p>
		</div>
		<!-- <p>Please Note: This is auto generated email, Please do not respond to this email.</p> -->
	</div>

</body>
</html>
